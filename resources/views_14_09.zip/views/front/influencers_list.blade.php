@extends('layouts.app')
 
@section('title', $title)

@section('css')
    @parent
    

@endsection
 
@section('content')
	<section class="blog-list-area section-bg-padding">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                	 <h2 class="animate text-center">{{ $category->name}}</h2>
                        {!! $category->long_desc  !!}
                </div>
            </div>
        </div>
    </section>


    <!-- show influencers belongs to category -->
    <section class="photography-section pb-50">
    	<div class="container">
    		<h2 class="animate text-center">Top {{$category->name }} Influencers List</h2>
    		<div class="row">
    			
    			@forelse($category->influencers as $influ)
    			<div class="col-lg-3 col-md-6 col-sm-12 pt-30">
    				<div class="photographic-box-card">
    					<div class="row photography-card d-flex">
    						<div class="col-md-2 col-4 small-photography-image">
    							<img src="assets/img/client/instagram.png" class="img-fluid instagram-photo" alt="">
    						</div>
    						<div class="col-md-8 col-4 big-photography-image text-center">
    							<img src="assets/img/social-icon-image/inst.png" class="img-fluid instagram-photo-big" alt="">
    						</div>
    						<div class="col-md-2 col-4 three-dout">
    							<img src="assets/img/social-icon-image/dots.png" class="img-fluid three-dot" alt="">
    						</div>
    					</div>
    					<div class="col-md-12 photo-content-text">
    						<div class="photography-text text-center">
    							<h6>Instagram</h6>
    						</div>
    						<div class="check-circles text-center">
    							<img src="assets/img/social-icon-image/g-check.jpg" class="img-fluid check-cir" alt="">
    						</div>
    					</div>
    					<div class="col-md-12 photo-button d-flex">
    						<div class="btn-photo">
    							<a href="#" class="btn-instr">LifeStyle </a>
    						</div>
    						<div class="btn-photo">
    							<a href="#" class="btn-instr-s">Photography</a>
    						</div>

    					</div>
    					<div class="col-md-12 btn-photo-l">
    						<a href="#" class="btn-instr">Travel</a>
    					</div>
    					<hr>
    					<div class="row">

    						<div class="col-4">
    							<div class="footer-box-cont">
    								<h5>529.8M</h5>
    								<p>Followers</p>
    							</div>
    						</div>
    						<div class="col-4">
    							<div class="footer-box-cont-1">
    								<h5>7.2K</h5>
    								<p>Post</p>
    							</div>
    						</div>
    						<div class="col-4">
    							<div class="footer-box-cont-3">
    								<h5>0.103</h5>
    								<p>Eng</p>
    							</div>
    						</div>

    					</div>
    				</div>
    			</div>
    			@empty

    			<p>No Influencers Data Available!</p>

    			@endforelse
    		</div>
    	</div>
	</section>
@endsection

@section('scripts')
	@parent
	
@endsection