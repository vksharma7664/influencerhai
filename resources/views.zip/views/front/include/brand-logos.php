<div class="h2-logo-slider  get-bottom animate pt-20 pb-20">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="owl-carousel owl-theme" id="owl-carousel002">
                        <div class="single-h2-slick item">
                            <img src="{{ asset('front_assets/img/brand/cocospy.webp') }}" alt="Influencershai.com's Client' Brand Logo">
                        </div>
                        <div class="single-h2-slick item">
                            <img src="{{ asset('front_assets/img/brand/cryptohill.webp') }}" alt="Influencershai.com's Client' Brand Logo">
                        </div>
                        <div class="single-h2-slick item">
                            <img src="{{ asset('front_assets/img/brand/dUETSCHE BANK.webp') }}" alt="Influencershai.com's Client' Brand Logo">
                        </div>
                        <div class="single-h2-slick item">
                            <img src="{{ asset('front_assets/img/brand/ekhelo.webp') }}" alt="Influencershai.com's Client' Brand Logo">
                        </div>
                        <div class="single-h2-slick item">
                            <img src="{{ asset('front_assets/img/brand/gEARBEST.webp') }}" alt="Influencershai.com's Client' Brand Logo">
                        </div>
                        <div class="single-h2-slick item">
                            <img src="{{ asset('front_assets/img/brand/iqoption.webp') }}" alt="Influencershai.com's Client' Brand Logo">
                        </div>
                        <div class="single-h2-slick item">
                            <img src="{{ asset('front_assets/img/brand/Hi dictionary.webp') }}" alt="Influencershai.com's Client' Brand Logo">
                        </div>
                        
                        <div class="single-h2-slick item">
                            <img src="{{ asset('front_assets/img/brand/Taxal.webp') }}" alt="Influencershai.com's Client' Brand Logo">
                        </div>
                        <div class="single-h2-slick item">
                            <img src="{{ asset('front_assets/img/brand/VideoBuddy.webp') }}" alt="Influencershai.com's Client' Brand Logo">
                        </div>
                        <div class="single-h2-slick item">
                            <img src="{{ asset('front_assets/img/brand/SPORTS11.webp') }}" alt="Influencershai.com's Client' Brand Logo">
                        </div>
                        <div class="single-h2-slick item">
                            <img src="{{ asset('front_assets/i') }}mg/brand/Quvideo-typhograpgy-type-loogo.webp" alt="Influencershai.com's Client' Brand Logo">
                        </div>
                        <div class="single-h2-slick item">
                            <img src="{{ asset('front_assets/img/brand/zorro.webp') }}" alt="Influencershai.com's Client' Brand Logo">
                        </div>
                        <div class="single-h2-slick">
                            <img src="{{ asset('front_assets/img/brand/ZUPEE.webp') }}" alt="Influencershai.com's Client' Brand Logo">
                        </div>
                        <div class="single-h2-slick item">
                            <img src="{{ asset('front_assets/img/brand/yelo.webp') }}" alt="Influencershai.com's Client' Brand Logo">
                        </div>
                        <div class="single-h2-slick">
                            <img src="{{ asset('front_assets/img/brand/meesho.webp') }}" alt="Influencershai.com's Client' Brand Logo">
                        </div>
                        <div class="single-h2-slick item">
                            <img src="{{ asset('front_assets/img/brand/MOUNTING DREAM.webp') }}" alt="Influencershai.com's Client' Brand Logo">
                        </div>
                        <div class="single-h2-slick item">
                            <img src="{{ asset('front_assets/img/brand/myteam11.webp') }}" alt="Influencershai.com's Client' Brand Logo">
                        </div>
                        <div class="single-h2-slick item">
                            <img src="{{ asset('front_assets/img/brand/ONEAXCESS.webp') }}" alt="Influencershai.com's Client' Brand Logo">
                        </div>
                        <div class="single-h2-slick item">
                            <img src="{{ asset('front_assets/img/brand/picsart.webp') }}" alt="Influencershai.com's Client' Brand Logo">
                        </div>
                        <div class="single-h2-slick item">
                            <img src="{{ asset('front_assets/img/brand/Vidlike- hor---.webp') }}" alt="Influencershai.com's Client' Brand Logo">
                        </div>
                        <div class="single-h2-slick item">
                            <img src="{{ asset('front_assets/img/brand/wondershare.webp') }}" alt="Influencershai.com's Client' Brand Logo">
                        </div>
                        <div class="single-h2-slick item">
                            <img src="{{ asset('front_assets/img/brand/WOOLY.webp') }}" alt="Influencershai.com's Client' Brand Logo">
                        </div>
                        <div class="single-h2-slick item">
                            <img src="{{ asset('front_assets/img/brand/WOOLY-WITHOUT-BG.webp') }}" alt="Influencershai.com's Client' Brand Logo">
                        </div>
                        </div>
                </div>
            </div>
        </div>
    </div>