<!DOCTYPE html>
<html lang="en">
    <head>
        <title> @yield('title') </title>
         <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta http-equiv="X-UA-Compatible" content="ie=edge">

          <meta name="description" content="{{ $meta_details['meta_desc'] ?? ''}}">
          
          
          <meta property="og:type" content="website" />
          <meta property="og:locale" content="en_US" />
          <meta property="og:title" content="{{ $meta_details['meta_title'] ?? ''}}" />
          <meta property="og:url" content="{{ URL::current() }}" />
          <meta property="og:site_name" content="Influencer Marketing Agency India" />

        <!-- <title>Influencer</title> -->
        <link rel="stylesheet" href="{{ asset('front_assets/css/base-style.css') }}">
        <link rel="stylesheet" href="{{ asset('front_assets/css/style.css') }}">
        <!-- toastr  -->
        <link href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/2.0.1/css/toastr.css" rel="stylesheet" />
        <link rel="shortcut icon" href="{{ asset('front_assets/img/favicon.ico') }}" type="image/x-icon">
        @section('css')
           
           
                <style>
                    
                    .technology-content {
                        margin-top: 0px;
                    }
                    .slick-slide img {
                        display: block;
                        height: 135px;
                    }
                </style>
           
        @show

        @section('head-scripts')
            
            <!--Start of Tawk.to Script-->
            <script type="text/javascript">
            var Tawk_API=Tawk_API||{}, Tawk_LoadStart=new Date();
            (function(){
            var s1=document.createElement("script"),s0=document.getElementsByTagName("script")[0];
            s1.async=true;
            s1.src='https://embed.tawk.to/62f2ae8f54f06e12d88dc89c/1ga1vjpfn';
            s1.charset='UTF-8';
            s1.setAttribute('crossorigin','*');
            s0.parentNode.insertBefore(s1,s0);
            })();
            </script>
            <!--End of Tawk.to Script-->

            <!-- Google tag (gtag.js) -->
            <script async src="https://www.googletagmanager.com/gtag/js?id=G-C71ETW355L"></script>
            <script>
              window.dataLayer = window.dataLayer || [];
              function gtag(){dataLayer.push(arguments);}
              gtag('js', new Date());

              gtag('config', 'G-C71ETW355L');
            </script>
        @show




    </head>
    <body class="placeholder" data-scrollbar="#0a35dc">
        @section('header')
             <!--header area start here-->
                <header class="header-area sticky-blue stic">
                    <div class="container-fluid">
                        <div class="row">
                            <div class="d-flex justify-content-between align-items-center header-menu header-transparent">
                                <div id="rect" class="logo">
                                <a href="{{ url('/')}}" class="logo-demo">
                                    <img src="{{ asset('front_assets/img/logo2.jpeg') }}" class="img-fluid" alt="Influencerhai.com's website logo.">
                                </a>
                                </div>
                                <div class="pupko-menu d-flex align-items-center justify-content-between">
                                    <nav class="main-navbar pupko-nav-white">
                                        <ul>
                                            <li>
                                                <a href="{{ route('influencers.category') }}">Influencers</a>
                                            </li>
                                            <li>
                                                <a href="{{ route('about')}}">About Us</a>
                                            </li>
                                           
                                            
                                           
                                            <li><a href="{{ route('blog')}}">Blog</a>
                                            </li>
                                            <li><a href="{{ route('careers')}}">Careers</a></li>
                                        </ul>
                                    </nav>
                                    <a href="{{ route('contact')}}" class="btn btn-sm btn-light-red br-6 btn-shatter-white btn-animate">Get in Touch</a>
                                </div>
                                <!-- responsive bar -->
                                <div class="animate-bar white-bar">
                                    <div class="line1"></div>
                                    <div class="line2"></div>
                                    <div class="line3"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </header>
    <!--header area end here-->
        @show
 
        <!-- <div class="container"> -->
            @yield('content')
        <!-- </div> -->



        @section('footer')
            <!--footer area start here-->
            <footer class="footer-area relative pt-md-60 bg-blue2">
                <div class="footer-animation">
                    <img class="footer-ani1" src="{{ asset('front_assets/img/home2/footer-ani.png') }}" alt="">
                    <img class="footer-ani2" src="{{ asset('front_assets/img/home2/footer-ani.png') }}" alt="">
                </div>
                <div class="container">
                    <div class="row">
                      
                        <div class="footer-conent-area bdr-y-white py-50 width-100p px-15">
                            <div class="row">
                                <div class="col-lg-4 col-sm-6">
                                    <div class="company-menu comon-footer mb-md-50 animate get-bottom">
                                        <h3 class="pb-50 pb-sm-25 text-white animate">Our Company</h3>
                                        <ul class="animate get-bottom hover-pink-ftr">
                                            <li class="animate"><a href="{{ route('about')}}">About Us</a></li>
                                            <li class="animate"><a href="{{ route('contact')}}">Contact</a></li>
                                            <li class="animate"><a href="{{ route('terms')}}">Terms & Conditions</a></li>
                                            <li class="animate"><a href="{{ route('privacy')}}">Privacy Policy</a></li>
                                            <li class="animate"><a href="{{ route('careers')}}">Careers</a></li>
                                        </ul>
                                    </div>
                                </div>
                                <div class="col-lg-4 col-sm-6">
                                    <div class="company-menu comon-footer mb-md-50 animate get-bottom">
                                        <h3 class="pb-50 pb-sm-25 text-white text-capital animate">feature</h3>
                                        <ul class="animate get-bottom hover-pink-ftr">
                                            <li class="animate"><a href="{{ route('influencers.category')}}">Influencers</a></li>
                                            <li class="animate"><a href="{{ route('influencer')}}">I am Influencer</a></li>
                                            <li class="animate"><a href="{{ route('brand')}}">I am Brands</a></li>
                                            <li class="animate"><a href="#">Press Release</a></li>
                                            <li class="animate"><a href="{{ route('blog')}}">Latest Blogs</a></li>
                                        </ul>
                                    </div>
                                </div>
                                
                                <div class="col-lg-4 col-sm-6">
                                    <div class="company-menu animate get-bottom">
                                        <h3 class="pb-50 pb-sm-25 text-white text-capital animate">Enquiry</h3>
                                        <ul class="animate get-bottom">
                                            <li class="pb-10 text-regular text-gray animate">feel free to  get in touch with via email</li>
                                            <li class="pb-20 animate"><a class="text-regular text-white text-sbold" href="#">contact@influencerhai.com</a></li>
                                            <li class="pb-10 text-regular text-gray animate">Address: E-46, Sector-3, Noida, UP, INDIA</li>
                                            <li>
                                                <ul class="d-flex flex-wrap align-items-center animate get-bottom">
                                                    <li><a class="text-20 text-white social-round mr-15 bg-icon icon-animation-purple icon-animation" href="https://m.facebook.com/101901749266288/" target="_blank"><i class="icofont-facebook"></i></a></li>
                                                    <li><a class="text-20 text-white social-round mr-15 bg-icon icon-animation-purple icon-animation" target="_blank" href="https://twitter.com/Influencerhai?s=20&t=NTIEYjxvqO8Jyb8pHrC1DA"><i class="icofont-twitter"></i></a></li>
                                                    <li><a class="text-20 text-white social-round mr-15 bg-icon icon-animation-purple icon-animation" target="_blank" href="https://instagram.com/influencerhai?igshid=YmMyMTA2M2Y="><i class="icofont-instagram"></i></a></li>
                                                    <li><a class="text-20 text-white social-round bg-icon icon-animation-purple icon-animation" target="_blank" href="https://www.linkedin.com/mwlite/company/influencerhai"><i class="icofont-linkedin"></i></a></li>

                                                </ul>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-12">
                            <div class="copy-right h2-cr text-center d-flex justify-content-between align-items-center animate get-top">
                                <a href="#" class="logo-demo logo-footer-image">
                                    Influencer Hai
                                </a>
                                <p class="text-gray"> Influencer Hai 2022. All rights reserved.</p>
                            </div>
                        </div>
                    </div>
                </div>
            </footer>
            <!--footer area end here-->
        @show

        @section('scripts')

              <!-- DEFAULT JQUERY SCRIPT HERE
            ================================================== -->
            <script src="{{ asset('front_assets/js/default/jquery-3.3.1.min.js') }}"></script>
            <script src="{{ asset('front_assets/js/default/popper.js') }}"></script>
            <script src="{{ asset('front_assets/js/default/bootstrap.min.js') }}"></script>
            <script src="{{ asset('front_assets/js/default/jquery-ui.min.js') }}"></script>
            <script src="{{ asset('front_assets/js/default/jquery-migrate-1.4.1.min.js') }}"></script>

            <!-- ALL ANIMATION SCRIPT CALL HERE 
            ====================================-->
            <!-- animation plugin script -->
            <script src="{{ asset('front_assets/js/plugin/animation-js/gsap.min.js') }}"></script>
            <script src="{{ asset('front_assets/js/plugin/animation-js/scroll-tigger.js') }}"></script>
            <script src="{{ asset('front_assets/js/plugin/animation-js/scroll-magic.js') }}"></script>
            <script src="{{ asset('front_assets/js/plugin/animation-js/nicescroll.min.js') }}"></script>
            <!--<script src="assets/js/plugin/animation-js/aos.js"></script>-->

             <!-- ALL PLUGIN SCRIPT CALL HERE 
            ====================================-->
            <!--skick script-->
            <script src="{{ asset('front_assets/js/plugin/slick.min.js') }}"></script>

            <!--Owl script-->
            <script src="{{ asset('front_assets/js/plugin/owl.carousel.min.js') }}"></script>
            <script src="{{ asset('front_assets/js/plugin/owl-custom.js') }}"></script>

            <!--Waypoint script-->
            <!-- <script src="assets/js/plugin/jquery.waypoints.min.js"></script> -->

            <!--Counterup script-->
            <!-- <script src="assets/js/plugin/jquery.counterup.min.js"></script> -->

            <!--Youtube overlay script-->
            <!-- <script src="assets/js/plugin/youtube-overlay.js"></script>  -->

            <!--swiper script-->
             <!-- <script src="assets/js/plugin/swiper.min.js"></script> -->
             
            <!--Parallax script-->
            <!-- <script src="assets/js/plugin/simpleParallax.min.js"></script> -->

            <!-- Nice Select -->
            <script src="{{ asset('front_assets/js/plugin/nice-select.min.js') }}"></script>
            <!-- Elevatezoom  script-->
            <script src="{{ asset('front_assets/js/plugin/jquery.elevatezoom.js') }}"></script>


            <!--isotope script-->
            <script src="{{ asset('front_assets/js/plugin/isotop-pakage-min.js') }}"></script>
            <script src="{{ asset('front_assets/js/plugin/image-loaded.min.js') }}"></script>

            <!-- CUSTOM SCRIPT CALL HERE 
            ====================================-->
            <script src="{{ asset('front_assets/js/tl-custom.js') }}"></script>
            <!--<script src="assets/js/mouse-event.js"></script>-->
            <script src="{{ asset('front_assets/js/scrollTrigger.js') }}"></script>
            <script src="{{ asset('front_assets/js/scripts.js') }}"></script>
            <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.5/dist/umd/popper.min.js" integrity="sha384-Xe+8cL9oJa6tN/veChSP7q+mnSPaj5Bcu9mPX5F5xIGE0DVittaqT5lorf0EI7Vk" crossorigin="anonymous"></script>
            <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/js/bootstrap.min.js" integrity="sha384-ODmDIVzN+pFdexxHEHFBQH3/9/vQ9uori45z4JjnFsRydbmQbmL5t1tQ0culUzyK" crossorigin="anonymous"></script>



            <script>
           $(document).ready(function() {
          //toggle the component with class accordion_body
          $(".accordion_head").click(function() {
            if ($('.accordion_body').is(':visible')) {
              $(".accordion_body").slideUp(300);
              $(".plusminus").text('+');
            }
            if ($(this).next(".accordion_body").is(':visible')) {
              $(this).next(".accordion_body").slideUp(300);
              $(this).children(".plusminus").text('+');
            } else {
              $(this).next(".accordion_body").slideDown(300);
              $(this).children(".plusminus").text('-');
            }
          });
        });
            </script>


        <script>
            $('#owl-carousel002').owlCarousel({
            loop:true,
            margin:10,
            nav:true,
            autoplay:true,
            autoplayTimeout:1000,
            responsive:{
                0:{
                    items:1
                },
                600:{
                    items:3
                },
                1000:{
                    items:6
                }
            }
        })
        </script>
        
        <script type='text/javascript' src="{{ asset('front-asset/js/flying-pages.mina305.js?ver=2.4.2') }}" id='flying-pages-js' defer></script>
          <!-- toastr js  -->
        <script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/2.0.1/js/toastr.js"></script>

        <script>
            $(document).ready(function() {
                toastr.options.timeOut = 10000;
                @if (Session::has('error'))
                    toastr.error('{{ Session::get('error') }}');
                @elseif(Session::has('success'))
                    toastr.success('{{ Session::get('success') }}');
                @endif
            });

        </script>
        
        @show

    </body>
</html>