@extends('admin/layout/layout')
@section('page_title','Dashboard')
@section('dash_right_in','in')
@section('container')
<!-- begin PAGE TITLE ROW -->
<div class="row">
    <div class="col-lg-12">
        <div class="page-title">
            <h1>@yield('page_title')
            </h1>
            
        </div>
    </div>
</div>
<!-- /.row -->






@endsection