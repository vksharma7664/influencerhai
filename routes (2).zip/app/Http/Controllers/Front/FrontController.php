<?php

namespace App\Http\Controllers\Front;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Models\Brand_query;
use App\Models\Influencer_query;
use Storage;


class FrontController extends Controller
{
    //
    public function index(){
        $data['categories']=DB::table('categories')->limit(9)->get();
        return view('front.homepage', ['data' => $data['categories']]);
    }


    public function InfluencerCategory()
    {
        return view('front.influencers_category', ['title' => 'Influencer Category -']);
    }

    public function InfluencerList()
    {
        return view('front.influencers_list', ['title' => 'Influencer List -']);
    }

    public function ForBrand()
    {
        return view('front.for_brand', ['title' => 'Brands -']);
    }

    public function ForBrandStore(Request $request)
    {
        // dd($request->all());
        $request->validate([
                'email'=>'required',
                'name'=>'required',
                'number'=>'required|digits:10',
                'message'=>'required',
                'designation'=>'required',
                'company_name'=>'required',
                'budget'=>'required',
            ]);

        Brand_query::create($request->all());
         $request->session()->flash('success','Your query has been submitted.');
            return redirect()->back();
    }

    public function ForInfluencer()
    {
        return view('front.for_influencer', ['title' => 'Influencer -']);
    }

    public function ForInfluencerStore(Request $request)
    {
        // dd($request->all());
         $request->validate([
                'email'=>'required',
                'name'=>'required',
                'number'=>'required|digits:10',
                'w_number'=>'required|digits:10',
                'gender'=>'required',
                'age'=>'required',
                // 'city'=>'required',
                // 'state'=>'required',
            ]);

        Influencer_query::create($request->all());
         $request->session()->flash('success','Your query has been submitted.');
            return redirect()->back();
    }

    public function About()
    {
        return view('front.about', ['title' => 'About Us -']);
    }

    public function Contact()
    {
        return view('front.contact', ['title' => 'Contact -']);
    }

    public function submitContact(Request $request)
    {
        // dd($request->all());
        $request->validate([
                'email'=>'required',
                'name'=>'required',
                'number'=>'required',
                'message'=>'required',
            ]);
        $data=array(
               'name'=>$request['name'],
               'email'=>$request['email'],
               'number'=>$request['number'],
               'message'=>$request['message'],
               'type'=>'contact',
               'created_at'=>date('Y-m-d h:i:s'),
            );
        DB::table('contactus')->insertGetId($data);
        // return view('front.contact', ['title' => 'Contact -']);
        $request->session()->flash('success','Your query has been submitted.');
            return redirect()->back();
    }

    public function Careers()
    {
         $career_jobs=DB::table('career_jobs')->where('status',1)->orderBy('id','desc')->get();
        return view('front.careers', ['title' => 'Careers -', 'career_jobs' => $career_jobs]);
    }

    public function CareersApply($title, $id)
    {
        $job =DB::table('career_jobs')->where('id',$id)->first();
        return view('front.careers_apply', ['title' => 'Careers -', 'job'=> $job]);
    }

    public function CareersApplyStore(Request $request, $id)
    {
        // $request->dd();
            $request->validate([
                'name'=>'required',
                'email'=>'required',
                'number'=>'required',
                'qualification'=>'required',
                'resume'=>'required|max:10000|mimes:doc,docx,pdf',
                'position'=>'required',
                'reason_to_hire'=>'required'
            ]);
            $data=array(
               'name'=>$request['name'],
               'email'=>$request['email'],
               'number'=>$request['number'],
               'qualification'=>$request['qualification'],
               'position'=>$request['position'],
               'experience'=>$request['experience'],
               'reason_to_hire'=>$request['reason_to_hire'],
               'updated_at'=>date('Y-m-d h:i:s'),
               'created_at'=>date('Y-m-d h:i:s'),
               'resume'=>''
            );
            if($request->hasFile('resume')) //image check Aviable Or | Not
                {
                    
                    $file = $request->file('resume');
                    $imageName=time().$file->getClientOriginalName();
                    $filePath = 'career_jobs_apply/' . $imageName;
                    Storage::disk('s3')->put($filePath, file_get_contents($file));
                    $data['resume']=env('AWS_BASEURL_IMAGE').'career_jobs_apply/'.$imageName;
                }
            DB::table('career_jobs_applies')->insert($data);
            $request->session()->flash('success','Your job has been applied.');
            return redirect()->back();
    }

    public function Privacy()
    {
        return view('front.privacy', ['title' => 'Privacy Policy-']);
    }

    public function Terms()
    {
        return view('front.terms', ['title' => 'Terms & Conditions -']);
    }

    public function Blog()
    {
        $blogs=DB::table('posts')->join('post_categories', 'posts.post_cat_id', '=', 'post_categories.id') ->select('posts.*', 'post_categories.name as cname')->orderBy('id', 'desc')->paginate(10);
        return view('front.blog', ['title' => 'Blog -', 'blogs' => $blogs]);
    }

    

    public function BlogDetails($title)
    {
        $blog=DB::table('posts')->join('post_categories', 'posts.post_cat_id', '=', 'post_categories.id') ->select('posts.*', 'post_categories.name as cname')->where('slug',$title)->first();

        $recent_blogs=DB::table('posts')->join('post_categories', 'posts.post_cat_id', '=', 'post_categories.id') ->select('posts.*', 'post_categories.name as cname')->where('slug','!=',$title)->orderBy('id', 'desc')->limit(5)->get();

        $categories=DB::table('post_categories')->orderBy('id', 'desc')->get();

        $meta = [];
        $meta['meta_title']     = $blog->meta_title;
        $meta['meta_desc']      = $blog->meta_desc;

        if($blog == null )  return abort(404);
        return view('front.blog_details', ['title' => $blog->title, 'blog' => $blog, 'meta_details' => $meta, 'categories'=>$categories, 'recent_blogs'=> $recent_blogs]);

    }

    public function PressRelease()
    {
        return view('front.press_release', ['title' => 'Press Release -']);
    }

    public function startCampaign()
    {
        return view('front.start_campaign', ['title' => 'Campaign -']);
    }

    public function postCampaign(Request $request)
    {
         // dd($request->all());
        $request->validate([
                'email'=>'required',
                'name'=>'required',
                'phone'=>'required',
                'message'=>'required',
                'website'=>'required',
            ]);
        $data=array(
               'name'=>$request['name'],
               'email'=>$request['email'],
               'number'=>$request['phone'],
               'message'=>$request['message'],
               'website'=>$request['website'],
               'type'=>'landing',
               'created_at'=>date('Y-m-d h:i:s'),
            );
        DB::table('contactus')->insertGetId($data);
        // return view('front.contact', ['title' => 'Contact -']);
        $request->session()->flash('success','Your query has been submitted.');
            return redirect()->route('home');
    }
}
