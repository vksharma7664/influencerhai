<?php

namespace App\Http\Controllers\admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Storage;
class PostCategoryController extends Controller
{
    function listing()
        {
            $data['result']=DB::table('post_categories')->get();
            return view('admin/post/add_new_category',$data);
        }
    function submit(Request $request)
        {
            $request->validate([
                'name'=>'required',
                'image'=>'required',
            ]);
            $data=array(
               'name'=>$request['name'],
               'updated_at'=>date('Y-m-d h:i:s'),
               'created_at'=>date('Y-m-d h:i:s'),
               'image'=>'Default_cat.png'
            );
            if($request->hasFile('image')) //image check Aviable Or | Not
                {
                    $image=$request->file('image');
                    $ext=$image->extension();
                    $file=time().'.'.$ext;
                    // $image->storeAs('/public/blog/category',$file);
                    $image->move(public_path().'/uploads/blog/category',$file);
                    $data['image']=$file;
                    // $file = $request->file('image');
                    // $imageName=time().$file->getClientOriginalName();
                    // $filePath = 'blog/post/' . $imageName;
                    // Storage::disk('s3')->put($filePath, file_get_contents($file));
                    // $data['image']= env('AWS_BASEURL_IMAGE').'blog/post/'.$imageName;
                }
            DB::table('post_categories')->insert($data);
            $request->session()->flash('msg','Data Saved Successfully');
            return redirect('admin/post/add-new-category');
        }
    function edit(Request $request,$id)
        {
            $data['result']=DB::table('post_categories')->where('id',$id)->get();
            return view('admin/post/edit_category',$data);
        }
    function update(Request $request,$id)
        {
            $request->validate([
                'name'=>'required',
            ]);
            $data=array(
               'name'=>$request['name'],
               'updated_at'=>date('Y-m-d h:i:s'),
               
            );
            if($request->hasFile('image')) //image check Aviable Or | Not
                {
                    $image=$request->file('image');
                    $ext=$image->extension();
                    $file=time().'.'.$ext;
                    // $image->storeAs('/public/blog/category',$file);
                    $image->move(public_path().'/uploads/blog/category',$file);
                    $data['image']=$file;
                    // $file = $request->file('image');
                    // $imageName=time().$file->getClientOriginalName();
                    // $filePath = 'blog/post/' . $imageName;
                    // Storage::disk('s3')->put($filePath, file_get_contents($file));
                    // $data['image']= env('AWS_BASEURL_IMAGE').'blog/post/'.$imageName;
                }
            DB::table('post_categories')->where('id',$id)->update($data);
            $request->session()->flash('msg','Data Updated Successfully');
            return redirect('admin/post/add-new-category');
        }
    function delete(Request $request,$id)
        {
            // return;
            // DB::table('post_categories')->where('id',$id)->delete();
            $request->session()->flash('msg','Data Deleted Successfully');
            return redirect('admin/post/add-new-category');
        }
}
