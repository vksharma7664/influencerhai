@extends('layouts.app')
 
@section('title', $title)

@section('css')
    @parent
    

@endsection
 
@section('content')
     <main class="influencer" style="background-color: #f2f1fd;">

        <section class="desktop-space">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <div class="h2-we-make-heading heading-content spmo get-bottom animate">
                            <div class="section-title animate">
                                <h2 class="pb-10">Top Creators In India</h2>
                            </div>
                        </div>
                    </div>
                </div>
             
                         <div class="row mobile-hidden">
                            <div class="col-lg-3 col-md-4 col-sm-6 mb-sm-50 get-bottom animate" style="opacity: 1; visibility: inherit; transform: translate(0px, 0px);">
                                <div class="top-content-icon-text">
                                    <div class="row">
                                        <div class="col-md-4">
                                            <div class="img-solical-icons">
                                                <img src="{{ asset('front_assets/img/Icon-1.png') }}" class="img-fluid img-aspiring" alt="">
                                            </div>
                                        </div>
                                        <div class="col-md-8">
                                            <div class="aspiring-para">
                                                <p>Aspiring <br> Influencers</p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="h4-single-team ">
                                    <div class="h4-team-img team-images relative">
                                        <img src="{{ asset('front_assets/img/home4/team1.jpg') }}" alt="">
                                        <!-- <div class="h4-team-social">
                                            <ul class="d-flex">
                                                <li><a href=""><i class="icofont-facebook"></i></a></li>
                                                <li><a href=""><i class="icofont-instagram"></i></a></li>
                                                <li><a href=""><i class="icofont-twitter"></i></a></li>
                                                <li><a href=""><i class="icofont-youtube"></i></a></li>
                                            </ul>
                                        </div> -->
                                    </div>
                                    <div class="h4-team-cont cont-pw get-bottom animate" style="opacity: 1; visibility: inherit; transform: translate(0px, 0px);">
                                     <div class="influencer-para-content">
                                        
                                      <p> People who want to start out but don’t know how to </p>       
                                     </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-3 col-md-4 col-sm-6 mb-sm-50 get-bottom animate" style="opacity: 1; visibility: inherit; transform: translate(0px, 0px);">
                                <div class="top-content-icon-text">
                                    <div class="row">
                                        <div class="col-md-4">
                                            <div class="img-solical-icons">
                                                <img src="{{ asset('front_assets/img/Icon-2.png') }}" class="img-fluid img-aspiring" alt="">
                                            </div>
                                        </div>
                                        <div class="col-md-8">
                                            <div class="aspiring-para">
                                                <p>Budding <br> Influencers</p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="h4-single-team team-single-section">
                                    <div class="h4-team-img team-images relative">
                                        <img src="{{ asset('front_assets/img/home4/team2.jpg') }}" alt="">
                                        <!-- <div class="h4-team-social">
                                            <ul class="d-flex">
                                                <li><a href=""><i class="icofont-facebook"></i></a></li>
                                                <li><a href=""><i class="icofont-instagram"></i></a></li>
                                                <li><a href=""><i class="icofont-twitter"></i></a></li>
                                                <li><a href=""><i class="icofont-youtube"></i></a></li>
                                            </ul>
                                        </div> -->
                                    </div>
                                    <div class="h4-team-cont cont-pw get-bottom animate" style="opacity: 1; visibility: inherit; transform: translate(0px, 0px);">
                                        <div class="influencer-para-content">
                                            <p>
                                                People who have just started but want to create</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-3 col-md-4 col-sm-6 get-bottom animate" style="opacity: 1; visibility: inherit; transform: translate(0px, 0px);">
                                <div class="top-content-icon-text">
                                    <div class="row">
                                        <div class="col-md-4">
                                            <div class="img-solical-icons">
                                                <img src="{{ asset('front_assets/img/Icon-3.png') }}" class="img-fluid img-aspiring" alt="">
                                            </div>
                                        </div>
                                        <div class="col-md-8">
                                            <div class="aspiring-para">
                                                <p>Micro <br>  Influencers</p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="h4-single-team  team-single-section">
                                    <div class="h4-team-img relative">
                                        <img src="{{ asset('front_assets/img/home4/team3.jpg') }}" alt="">
                                        <!-- <div class="h4-team-social">
                                            <ul class="d-flex">
                                                <li><a href=""><i class="icofont-facebook"></i></a></li>
                                                <li><a href=""><i class="icofont-instagram"></i></a></li>
                                                <li><a href=""><i class="icofont-twitter"></i></a></li>
                                                <li><a href=""><i class="icofont-youtube"></i></a></li>
                                            </ul>
                                        </div> -->
                                    </div>
                                    <div class="h4-team-cont cont-pw get-bottom animate" style="opacity: 1; visibility: inherit; transform: translate(0px, 0px);">
                                        <div class="influencer-para-content">
                                        <p>
                                        Established influencers who want to monetize their</p>
                                      </div>
                                    </div>
                                </div>

                                
                            </div>

                            <div class="col-lg-3 col-md-4 col-sm-6 get-bottom animate" style="opacity: 1; visibility: inherit; transform: translate(0px, 0px);">
                                <div class="top-content-icon-text">
                                    <div class="row">
                                        <div class="col-md-4">
                                            <div class="img-solical-icons">
                                                <img src="{{ asset('front_assets/img/Icon-3.png') }}" class="img-fluid img-aspiring" alt="">
                                            </div>
                                        </div>
                                        <div class="col-md-8">
                                            <div class="aspiring-para">
                                                <p>Celebrity <br> Influencers</p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="h4-single-team team-single-section">
                                    <div class="h4-team-img relative">
                                        <img src="{{ asset('front_assets/img/home4/team4.jpg') }}" alt="">
                                        <!-- <div class="h4-team-social">
                                            <ul class="d-flex">
                                                <li><a href=""><i class="icofont-facebook"></i></a></li>
                                                <li><a href=""><i class="icofont-instagram"></i></a></li>
                                                <li><a href=""><i class="icofont-twitter"></i></a></li>
                                                <li><a href=""><i class="icofont-youtube"></i></a></li>
                                            </ul>
                                        </div> -->
                                    </div>
                                    <div class="h4-team-cont cont-pw get-bottom animate" style="opacity: 1; visibility: inherit; transform: translate(0px, 0px);">
                                        <div class="influencer-para-content">
                                        <p>
                                        Established influencers who want to monetize</p>
                                      </div>
                                    </div>
                                </div>

                                
                            </div>
                        </div>
                        <div class="row mobile-slider">
                            <div class="owl-carousel owl-theme">
                            <div class="col-md-3 item mb-sm-50 get-bottom animate" style="opacity: 1; visibility: inherit; transform: translate(0px, 0px);">
                                <div class="top-content-icon-text">
                                    <div class="row">
                                        <div class="col-md-4">
                                            <div class="img-solical-icons">
                                                <img src="{{ asset('front_assets/img/Icon-1.png') }}" class="img-fluid img-aspiring" alt="">
                                            </div>
                                        </div>
                                        <div class="col-md-8">
                                            <div class="aspiring-para">
                                                <div class="influen-text">Aspiring</div>
                                                <div class="influen-text-2">Influencers</div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="h4-single-team team-single-section">
                                    <div class="h4-team-img team-images relative">
                                        <img src="{{ asset('front_assets/img/home4/team1.jpg') }}" alt="">
                                        <div class="h4-team-social">
                                            <ul class="d-flex">
                                                <li><a href=""><i class="icofont-facebook"></i></a></li>
                                                <li><a href=""><i class="icofont-instagram"></i></a></li>
                                                <li><a href=""><i class="icofont-twitter"></i></a></li>
                                                <li><a href=""><i class="icofont-youtube"></i></a></li>
                                            </ul>
                                        </div>
                                    </div>
                                    <div class="h4-team-cont cont-pw get-bottom animate" style="opacity: 1; visibility: inherit; transform: translate(0px, 0px);">
                                     <div class="influencer-para-content">
                                        
                                      <p> People who want to start out but don’t know how to </p>       
                                     </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-3 item mb-sm-50 get-bottom animate" style="opacity: 1; visibility: inherit; transform: translate(0px, 0px);">
                                <div class="top-content-icon-text">
                                    <div class="row">
                                        <div class="col-md-4">
                                            <div class="img-solical-icons">
                                                <img src="{{ asset('front_assets/img/Icon-2.png') }}" class="img-fluid img-aspiring" alt="">
                                            </div>
                                        </div>
                                        <div class="col-md-8">
                                            <div class="aspiring-para">
                                                <div class="influen-text">Aspiring</div>
                                                <div class="influen-text-2">Influencers</div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="h4-single-team team-single-section">
                                    <div class="h4-team-img team-images relative">
                                        <img src="{{ asset('front_assets/img/home4/team2.jpg') }}" alt="">
                                        <div class="h4-team-social">
                                            <ul class="d-flex">
                                                <li><a href=""><i class="icofont-facebook"></i></a></li>
                                                <li><a href=""><i class="icofont-instagram"></i></a></li>
                                                <li><a href=""><i class="icofont-twitter"></i></a></li>
                                                <li><a href=""><i class="icofont-youtube"></i></a></li>
                                            </ul>
                                        </div>
                                    </div>
                                    <div class="h4-team-cont cont-pw get-bottom animate" style="opacity: 1; visibility: inherit; transform: translate(0px, 0px);">
                                        <div class="influencer-para-content">
                                            <p>
                                                People who have just started but want to create</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-3 item get-bottom animate" style="opacity: 1; visibility: inherit; transform: translate(0px, 0px);">
                                <div class="top-content-icon-text">
                                    <div class="row">
                                        <div class="col-md-4">
                                            <div class="img-solical-icons">
                                                <img src="{{ asset('front_assets/img/Icon-3.png') }}" class="img-fluid img-aspiring" alt="">
                                            </div>
                                        </div>
                                        <div class="col-md-8">
                                            <div class="aspiring-para">
                                                <div class="influen-text">Aspiring</div>
                                                <div class="influen-text-2">Influencers</div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="h4-single-team team-single-section">
                                    <div class="h4-team-img relative">
                                        <img src="{{ asset('front_assets/img/home4/team3.jpg') }}" alt="">
                                        <div class="h4-team-social">
                                            <ul class="d-flex">
                                                <li><a href=""><i class="icofont-facebook"></i></a></li>
                                                <li><a href=""><i class="icofont-instagram"></i></a></li>
                                                <li><a href=""><i class="icofont-twitter"></i></a></li>
                                                <li><a href=""><i class="icofont-youtube"></i></a></li>
                                            </ul>
                                        </div>
                                    </div>
                                    <div class="h4-team-cont cont-pw get-bottom animate" style="opacity: 1; visibility: inherit; transform: translate(0px, 0px);">
                                        <div class="influencer-para-content">
                                        <p>
                                        Established influencers who want to monetize their</p>
                                      </div>
                                    </div>
                                </div>

                                
                            </div>
                            <div class="col-md-3 item get-bottom animate" style="opacity: 1; visibility: inherit; transform: translate(0px, 0px);">
                                <div class="top-content-icon-text">
                                    <div class="row">
                                        <div class="col-md-4">
                                            <div class="img-solical-icons">
                                                <img src="{{ asset('front_assets/img/Icon-3.png') }}" class="img-fluid img-aspiring" alt="">
                                            </div>
                                        </div>
                                        <div class="col-md-8">
                                            <div class="aspiring-para">
                                                <div class="influen-text">Aspiring</div>
                                                <div class="influen-text-2">Influencers</div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="h4-single-team team-single-section">
                                    <div class="h4-team-img relative">
                                        <img src="{{ asset('front_assets/img/home4/team4.jpg') }}" alt="">
                                        <div class="h4-team-social">
                                            <ul class="d-flex">
                                                <li><a href=""><i class="icofont-facebook"></i></a></li>
                                                <li><a href=""><i class="icofont-instagram"></i></a></li>
                                                <li><a href=""><i class="icofont-twitter"></i></a></li>
                                                <li><a href=""><i class="icofont-youtube"></i></a></li>
                                            </ul>
                                        </div>
                                    </div>
                                    <div class="h4-team-cont cont-pw get-bottom animate" style="opacity: 1; visibility: inherit; transform: translate(0px, 0px);">
                                        <div class="influencer-para-content">
                                        <p>
                                        Established influencers who want to monetize</p>
                                      </div>
                                    </div>
                                </div>

                                
                            </div>
                           </div>

                        </div>
                   
                      
                </div>
            </div>
        </section>
       
       
        <section class="desktop-space pb-50">
            <div class="container">
                <div class="row">
                    <div class="col-xl-12">
                        <div class="row">
                            <div class="col-lg-3 col-md-3 col-sm-6 col-6 mx-auto mb-md-30 bottom-content get-bottom animate">
                                <div class="working-card card-box case-card animate">
                                    <div class="comon-card-icon circle-cord-icon m-auto d-center svg-50 svg-blue animate">
                                        <img src="{{ asset('front_assets/img/svg/grid.png') }}" alt="">
                                    </div>
                                    <h3 class="pt-25 animate">All</h3>
                                </div>
                            </div>
                            <div class="col-lg-3 col-md-3 col-sm-6 col-6 mx-auto mb-md-30 bottom-content get-bottom animate">
                                <div class="working-card card-box case-card relative animate">
                                    <div class="comon-card-icon circle-cord-icon  m-auto d-center svg-50 svg-blue animate">
                                        <img src="{{ asset('front_assets/img/svg/makeover.png') }}" alt=""> 
                                    </div>
                                    <h3 class="pt-25 animate">Beauty</h3>
                                </div>
                            </div>
                            <div class="col-lg-3 col-md-3 col-sm-6 col-6 mx-auto get-bottom bottom-content animate">
                                <div class="working-card card-box case-card relative animate">
                                    <div class="comon-card-icon circle-cord-icon  m-auto d-center svg-50 svg-blue animate">
                                        <img src="{{ asset('front_assets/img/svg/open-book.png') }}" alt=""> 
                                    </div>
                                    <h3 class="pt-25 animate">Books</h3>
                                </div>
                            </div>
                            <div class="col-lg-3 col-md-3 col-sm-6 col-6 mx-auto get-bottom bottom-content animate">
                                <div class="working-card card-box case-card relative animate">
                                    <div class="comon-card-icon circle-cord-icon  m-auto d-center svg-50 svg-blue animate">
                                        <img src="{{ asset('front_assets/img/svg/parents.png') }}" alt=""> 
                                    </div>
                                    <h3 class="pt-25 animate">Couple</h3>
                                </div>
                            </div>
                            <div class="col-lg-3 col-md-3 col-sm-6 col-6 mx-auto get-bottom bottom-content animate">
                                <div class="working-card card-box case-card relative animate">
                                    <div class="comon-card-icon circle-cord-icon  m-auto d-center svg-50 svg-blue animate">
                                        <img src="{{ asset('front_assets/img/svg/mortarboard.png') }}" alt=""> 
                                    </div>
                                    <h3 class="pt-25 animate">Education</h3>
                                </div>
                            </div>
                            <div class="col-lg-3 col-md-3 col-sm-6 col-6 mx-auto get-bottom bottom-content animate">
                                <div class="working-card card-box case-card relative animate">
                                    <div class="comon-card-icon circle-cord-icon  m-auto d-center svg-50 svg-blue animate">
                                        <img src="{{ asset('front_assets/img/svg/dancer.png') }}" alt=""> 
                                    </div>
                                    <h3 class="pt-25 animate">Entertainments</h3>
                                </div>
                            </div>
                            <div class="col-lg-3 col-md-3 col-sm-6 col-6 mx-auto get-bottom bottom-content animate">
                                <div class="working-card card-box case-card relative animate">
                                    <div class="comon-card-icon circle-cord-icon  m-auto d-center svg-50 svg-blue animate">
                                        <img src="{{ asset('front_assets/img/svg/woman.png') }}" alt=""> 
                                    </div>
                                    <h3 class="pt-25 animate">Fitness</h3>
                                </div>
                            </div>
                            <div class="col-lg-3 col-md-3 col-sm-6 col-6 mx-auto get-bottom bottom-content animate">
                                <div class="working-card card-box case-card relative animate">
                                    <div class="comon-card-icon circle-cord-icon m-auto d-center svg-50 svg-blue animate">
                                        <img src="{{ asset('front_assets/img/svg/dish.png') }}" alt=""> 
                                    </div>
                                    <h3 class="pt-25 animate">Food</h3>
                                </div>
                            </div>
                            <div class="col-lg-3 col-md-3 col-sm-6 col-6 mx-auto get-bottom bottom-content animate">
                                <div class="working-card card-box case-card relative animate">
                                    <div class="comon-card-icon circle-cord-icon m-auto d-center svg-50 svg-blue animate">
                                        <img src="{{ asset('front_assets/img/svg/healthy-lifestyle-logo.png') }}" alt=""> 
                                    </div>
                                    <h3 class="pt-25 animate">Lifestyle</h3>
                                </div>
                            </div>
                            <div class="col-lg-3 col-md-3 col-sm-6 col-6 mx-auto get-bottom bottom-content animate">
                                <div class="working-card card-box case-card relative animate">
                                    <div class="comon-card-icon circle-cord-icon m-auto d-center svg-50 svg-blue animate">
                                        <img src="{{ asset('front_assets/img/svg/family.png') }}" alt=""> 
                                    </div>
                                    <h3 class="pt-25 animate">Parenting</h3>
                                </div>
                            </div>
                            <div class="col-lg-3 col-md-3 col-sm-6 col-6 mx-auto get-bottom bottom-content animate">
                                <div class="working-card card-box case-card relative animate">
                                    <div class="comon-card-icon circle-cord-icon m-auto d-center svg-50 svg-blue animate">
                                        <img src="{{ asset('front_assets/img/svg/mom.png') }}" alt=""> 
                                    </div>
                                    <h3 class="pt-25 animate">Mom</h3>
                                </div>
                            </div>
                            <div class="col-lg-3 col-md-3 col-sm-6 col-6 mx-auto get-bottom bottom-content animate">
                                <div class="working-card card-box case-card relative animate">
                                    <div class="comon-card-icon circle-cord-icon m-auto d-center svg-50 svg-blue animate">
                                        <img src="{{ asset('front_assets/img/svg/dancer.png') }}" alt=""> 
                                    </div>
                                    <h3 class="pt-25 animate">Men's Fashion</h3>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

    </main>
@endsection

@section('scripts')
	@parent
	
@endsection