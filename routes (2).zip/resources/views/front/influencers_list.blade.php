@extends('layouts.app')
 
@section('title', $title)

@section('css')
    @parent
    

@endsection
 
@section('content')

@endsection

@section('scripts')
	@parent
	
@endsection