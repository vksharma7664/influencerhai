@extends('layouts.app')
 
@section('title', $title)

@section('css')
    @parent
    

@endsection
 
@section('content')
   <section class="career-list">
        <div class="container">
            <div class="row">
                <div class="col-md-12 pt-30 pb-50"> 
                    <div class="career-list-text text-center">
                        <h2>Career</h2>
                    </div>
                </div>
            </div>
            <div class="row pb-100 pt-50 mobile-respo">
                @forelse ($career_jobs as $job)
                <div class="col-md-6 space-mobile-devic">
                    <div class="content-career-box">
                        <div class="row">
                            <div class="col-md-6">
                                <img src="{{ $job->image }}" class="img-fluid" alt="">
                            </div>
                            <div class="col-md-6">
                                <div class="career-all-content">
                                <div class="content-box-caree pt-2">
                                    <h6>{{ strtoupper($job->title) }}</h6>
                                    <p>{{ substr($job->short_desc, 0, 50)  }}...</p>
                                </div>
                                 <div class="exprence-text  pt-3">
                                    <h6>Experience:  <span class="year-span">{{ $job->experience }}</span></h6>
                                 </div>
                                 <div class="exprence-text  pt-3">
                                    <h6>Location:  <span class="year-span">{{ $job->location }}</span></h6>
                                 </div>

                                 <div class="btn-carrer-devel text-center pt-4">
                                    <a href="{{ route('careers.apply', [\Illuminate\Support\Str::slug(strtolower($job->title) , '-'),$job->id]) }}" class="btn btn-sm btn-light-red br-6 btn-shatter-white btn-animate">Apply Now</a>
                                 </div>
                                 </div>
                            </div>
                        </div>
                    </div>
                </div>
                @empty
                NO JOBS AVAILABLE
                @endforelse
                <!-- <div class="col-md-6 space-mobile-devic">
                    <div class="content-career-box">
                        <div class="row">
                            <div class="col-md-6">
                                <img src="{{ asset('front_assets/img/case-studies/Case-details.png') }}" class="img-fluid" alt="">
                            </div>
                            <div class="col-md-6">
                                <div class="career-all-content">
                                <div class="content-box-caree pt-2">
                                    <h6>SOCIAL MEDIA MANAGER</h6>
                                    <p>Someone who could single-handedly nail the aesthetics, be witty and quirky</p>
                                </div>
                                 <div class="exprence-text text-center pt-3">
                                    <h6>Experience:  <span class="year-span">1-3 Years</span></h6>
                                 </div>
                                 <div class="btn-carrer-devel text-center pt-4">
                                    <a href="career-details.html" class="btn btn-sm btn-light-red br-6 btn-shatter-white btn-animate">Apply Now</a>
                                 </div>
                                 </div>
                            </div>
                        </div>
                    </div>
                </div> -->
            </div>
        </div>
    </section>


     <section class="h4-team-area section-bg-padding bg-gray">
        <div class="section-title get-bottom animate" style="opacity: 1; visibility: inherit; transform: translate(0px, 0px);">
            <h2 class="pb-50 text-center"> Our Executive Team</h2>
        </div>
        <div class="container">
            <div class="row">
                <div class="col-md-4 mb-sm-50 get-bottom animate" style="opacity: 1; visibility: inherit; transform: translate(0px, 0px);">
                    <div class="h4-single-team">
                        <div class="h4-team-img relative">
                            <img src="{{ asset('front_assets/img/executive/default.png') }}" alt="">
                            <div class="h4-team-social">
                                <ul class="d-flex">
                                    <li><a href=""><i class="icofont-facebook"></i></a></li>
                                    <li><a href=""><i class="icofont-behance"></i></a></li>
                                    <li><a href=""><i class="icofont-twitter"></i></a></li>
                                    <li><a href=""><i class="icofont-dribbble"></i></a></li>
                                </ul>
                            </div>
                        </div>
                        <div class="h4-team-cont text-center get-bottom animate" style="opacity: 1; visibility: inherit; transform: translate(0px, 0px);">
                            <div class="card-title animate melon-hover" style="opacity: 1; visibility: inherit; transform: translate(0px, 0px);">
                                <h3 class="pb-10"><a href="">Gaurav Kumar</a></h3>
                            </div>
                            <p class="animate" style="opacity: 1; visibility: inherit; transform: translate(0px, 0px);">Owner &amp; CEO</p>
                        </div>
                    </div>
                </div>
                
                <div class="col-md-4 mb-sm-50 get-bottom animate" style="opacity: 1; visibility: inherit; transform: translate(0px, 0px);">
                    <div class="h4-single-team">
                        <div class="h4-team-img relative">
                            <img src="{{ asset('front_assets/img/executive/amarjeet.png') }}" alt="">
                            <div class="h4-team-social">
                                <ul class="d-flex">
                                    <li><a href=""><i class="icofont-facebook"></i></a></li>
                                    <li><a href=""><i class="icofont-behance"></i></a></li>
                                    <li><a href=""><i class="icofont-twitter"></i></a></li>
                                    <li><a href=""><i class="icofont-dribbble"></i></a></li>
                                </ul>
                            </div>
                        </div>
                        <div class="h4-team-cont text-center get-bottom animate" style="opacity: 1; visibility: inherit; transform: translate(0px, 0px);">
                            <div class="card-title animate melon-hover" style="opacity: 1; visibility: inherit; transform: translate(0px, 0px);">
                                <h3 class="pb-10"><a href="">Amarjeet Singh</a></h3>
                            </div>
                            <p class="animate" style="opacity: 1; visibility: inherit; transform: translate(0px, 0px);">Marketing Head</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-4 get-bottom animate" style="opacity: 1; visibility: inherit; transform: translate(0px, 0px);">
                    <div class="h4-single-team">
                        <div class="h4-team-img relative">
                            <img src="{{ asset('front_assets/img/executive/manish.png') }}" alt="">
                            <div class="h4-team-social">
                                <ul class="d-flex">
                                    <li><a href=""><i class="icofont-facebook"></i></a></li>
                                    <li><a href=""><i class="icofont-behance"></i></a></li>
                                    <li><a href=""><i class="icofont-twitter"></i></a></li>
                                    <li><a href=""><i class="icofont-dribbble"></i></a></li>
                                </ul>
                            </div>
                        </div>
                        <div class="h4-team-cont text-center get-bottom animate" style="opacity: 1; visibility: inherit; transform: translate(0px, 0px);">
                            <div class="card-title animate melon-hover" style="opacity: 1; visibility: inherit; transform: translate(0px, 0px);">
                                <h3 class="pb-10"><a href="">Manish Mannu</a></h3>
                            </div>
                            <p class="animate" style="opacity: 1; visibility: inherit; transform: translate(0px, 0px);">Business Development Executive</p>
                        </div>
                    </div>
                </div>

                <div class="col-md-4 get-bottom animate" style="opacity: 1; visibility: inherit; transform: translate(0px, 0px);">
                    <div class="h4-single-team">
                        <div class="h4-team-img relative">
                            <img src="{{ asset('front_assets/img/executive/siddhi.png') }}" alt="">
                            <div class="h4-team-social">
                                <ul class="d-flex">
                                    <li><a href=""><i class="icofont-facebook"></i></a></li>
                                    <li><a href=""><i class="icofont-behance"></i></a></li>
                                    <li><a href=""><i class="icofont-twitter"></i></a></li>
                                    <li><a href=""><i class="icofont-dribbble"></i></a></li>
                                </ul>
                            </div>
                        </div>
                        <div class="h4-team-cont text-center get-bottom animate" style="opacity: 1; visibility: inherit; transform: translate(0px, 0px);">
                            <div class="card-title animate melon-hover" style="opacity: 1; visibility: inherit; transform: translate(0px, 0px);">
                                <h3 class="pb-10"><a href="">Siddhi</a></h3>
                            </div>
                            <p class="animate" style="opacity: 1; visibility: inherit; transform: translate(0px, 0px);">Influencer Marketing Executive</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-4 mb-sm-50 get-bottom animate" style="opacity: 1; visibility: inherit; transform: translate(0px, 0px);">
                    <div class="h4-single-team">
                        <div class="h4-team-img relative">
                            <img src="{{ asset('front_assets/img/executive/default.png') }}" alt="">
                            <div class="h4-team-social">
                                <ul class="d-flex">
                                    <li><a href=""><i class="icofont-facebook"></i></a></li>
                                    <li><a href=""><i class="icofont-behance"></i></a></li>
                                    <li><a href=""><i class="icofont-twitter"></i></a></li>
                                    <li><a href=""><i class="icofont-dribbble"></i></a></li>
                                </ul>
                            </div>
                        </div>
                        <div class="h4-team-cont text-center get-bottom animate" style="opacity: 1; visibility: inherit; transform: translate(0px, 0px);">
                            <div class="card-title animate melon-hover" style="opacity: 1; visibility: inherit; transform: translate(0px, 0px);">
                                <h3 class="pb-10"><a href="">Vikesh Sharma</a></h3>
                            </div>
                            <p class="animate" style="opacity: 1; visibility: inherit; transform: translate(0px, 0px);">Celebrity and PR Manager</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-4 get-bottom animate" style="opacity: 1; visibility: inherit; transform: translate(0px, 0px);">
                    <div class="h4-single-team">
                        <div class="h4-team-img relative">
                            <img src="{{ asset('front_assets/img/executive/yogesh.png') }}" alt="">
                            <div class="h4-team-social">
                                <ul class="d-flex">
                                    <li><a href=""><i class="icofont-facebook"></i></a></li>
                                    <li><a href=""><i class="icofont-behance"></i></a></li>
                                    <li><a href=""><i class="icofont-twitter"></i></a></li>
                                    <li><a href=""><i class="icofont-dribbble"></i></a></li>
                                </ul>
                            </div>
                        </div>
                        <div class="h4-team-cont text-center get-bottom animate" style="opacity: 1; visibility: inherit; transform: translate(0px, 0px);">
                            <div class="card-title animate melon-hover" style="opacity: 1; visibility: inherit; transform: translate(0px, 0px);">
                                <h3 class="pb-10"><a href="">Yogesh Sharma</a></h3>
                            </div>
                            <p class="animate" style="opacity: 1; visibility: inherit; transform: translate(0px, 0px);">Influencer Marketing Executive</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-4 get-bottom animate" style="opacity: 1; visibility: inherit; transform: translate(0px, 0px);">
                    <div class="h4-single-team">
                        <div class="h4-team-img relative">
                            <img src="{{ asset('front_assets/img/executive/subham.png') }}" alt="">
                            <div class="h4-team-social">
                                <ul class="d-flex">
                                    <li><a href=""><i class="icofont-facebook"></i></a></li>
                                    <li><a href=""><i class="icofont-behance"></i></a></li>
                                    <li><a href=""><i class="icofont-twitter"></i></a></li>
                                    <li><a href=""><i class="icofont-dribbble"></i></a></li>
                                </ul>
                            </div>
                        </div>
                        <div class="h4-team-cont text-center get-bottom animate" style="opacity: 1; visibility: inherit; transform: translate(0px, 0px);">
                            <div class="card-title animate melon-hover" style="opacity: 1; visibility: inherit; transform: translate(0px, 0px);">
                                <h3 class="pb-10"><a href="">Shubham Rawat</a></h3>
                            </div>
                            <p class="animate" style="opacity: 1; visibility: inherit; transform: translate(0px, 0px);">Business Development Executive</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-4 get-bottom animate" style="opacity: 1; visibility: inherit; transform: translate(0px, 0px);">
                    <div class="h4-single-team">
                        <div class="h4-team-img relative">
                            <img src="{{ asset('front_assets/img/executive/default.png') }}" alt="">
                            <div class="h4-team-social">
                                <ul class="d-flex">
                                    <li><a href=""><i class="icofont-facebook"></i></a></li>
                                    <li><a href=""><i class="icofont-behance"></i></a></li>
                                    <li><a href=""><i class="icofont-twitter"></i></a></li>
                                    <li><a href=""><i class="icofont-dribbble"></i></a></li>
                                </ul>
                            </div>
                        </div>
                        <div class="h4-team-cont text-center get-bottom animate" style="opacity: 1; visibility: inherit; transform: translate(0px, 0px);">
                            <div class="card-title animate melon-hover" style="opacity: 1; visibility: inherit; transform: translate(0px, 0px);">
                                <h3 class="pb-10"><a href="">Rahul Kumar</a></h3>
                            </div>
                            <p class="animate" style="opacity: 1; visibility: inherit; transform: translate(0px, 0px);">Content Writer</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-4 get-bottom animate" style="opacity: 1; visibility: inherit; transform: translate(0px, 0px);">
                    <div class="h4-single-team">
                        <div class="h4-team-img relative">
                            <img src="{{ asset('front_assets/img/executive/himanshu.png') }}" alt="">
                            <div class="h4-team-social">
                                <ul class="d-flex">
                                    <li><a href=""><i class="icofont-facebook"></i></a></li>
                                    <li><a href=""><i class="icofont-behance"></i></a></li>
                                    <li><a href=""><i class="icofont-twitter"></i></a></li>
                                    <li><a href=""><i class="icofont-dribbble"></i></a></li>
                                </ul>
                            </div>
                        </div>
                        <div class="h4-team-cont text-center get-bottom animate" style="opacity: 1; visibility: inherit; transform: translate(0px, 0px);">
                            <div class="card-title animate melon-hover" style="opacity: 1; visibility: inherit; transform: translate(0px, 0px);">
                                <h3 class="pb-10"><a href="">Himanshu Dhuoon</a></h3>
                            </div>
                            <p class="animate" style="opacity: 1; visibility: inherit; transform: translate(0px, 0px);">Celebrity and PR Manager</p>
                        </div>
                    </div>
                </div>
                <!-- <div class="col-md-4 get-bottom animate" style="opacity: 1; visibility: inherit; transform: translate(0px, 0px);">
                    <div class="h4-single-team">
                        <div class="h4-team-img relative">
                            <img src="{{ asset('front_assets/img/executive/default.png') }}" alt="">
                            <div class="h4-team-social">
                                <ul class="d-flex">
                                    <li><a href=""><i class="icofont-facebook"></i></a></li>
                                    <li><a href=""><i class="icofont-behance"></i></a></li>
                                    <li><a href=""><i class="icofont-twitter"></i></a></li>
                                    <li><a href=""><i class="icofont-dribbble"></i></a></li>
                                </ul>
                            </div>
                        </div>
                        <div class="h4-team-cont text-center get-bottom animate" style="opacity: 1; visibility: inherit; transform: translate(0px, 0px);">
                            <div class="card-title animate melon-hover" style="opacity: 1; visibility: inherit; transform: translate(0px, 0px);">
                                <h3 class="pb-10"><a href="">Anuj Raj</a></h3>
                            </div>
                            <p class="animate" style="opacity: 1; visibility: inherit; transform: translate(0px, 0px);">Content Writer</p>
                        </div>
                    </div>
                </div> -->
            </div>
        </div>
    </section>
@endsection

@section('scripts')
	@parent
	
@endsection