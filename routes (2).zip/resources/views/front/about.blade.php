@extends('layouts.app')
 
@section('title', $title)

@section('css')
    @parent
    

@endsection


 
@section('content')
    <!-- <section class="about-we-are relative pt-100 pt-md-60 pb-50 pb-md-30">
        <img class="we-are-bg" src="{{ asset('front_assets/img/About-Us.png') }}" alt="">
        <div class="we-are-img md-order-2">
            <div class="we-are-banner-img">
                <img src="{{ asset('front_assets/img/home2/we-are/banner.png') }}" alt="">
            </div>
            <div class="we-are-animation">
                <img src="{{ asset('front_assets/img/home2/we-are/like.png') }}" alt="" class="h2-like">
                <img src="{{ asset('front_assets/img/home2/we-are/heart.png') }}" alt="" class="h2-heart">
                <img src="{{ asset('front_assets/img/home2/we-are/message.png') }}" alt="" class="h2-message">
                <img src="{{ asset('front_assets/img/home2/we-are/square.png') }}" alt="" class="h2-square">
                <img src="{{ asset('front_assets/img/home2/we-are/circle.png') }}" alt="" class="moving-circle">
                <img src="{{ asset('front_assets/img/home2/we-are/circle2.png') }}" alt="" class="moving-circle-right">
            </div>
        </div>
        <div class="container md-order-1">
            <div class="row justify-content-end">
                <div class="col-lg-6">
                    <div class="we-are-content get-bottom animate">
                        <div class="section-title animate">
                            <h2 class="pb-20">We Are influencer</h2>
                        </div>
                        <p class="pb-50 animate">Budding Influencers, is an influencer marketing platform, creating a chain of internet creators and consumers through scaling businesses. To curate the right influencers for the right brand to reach the audience is the prime task we lean on working towards.</p>
                        <div class="animate">
                            <button class="btn btn-sm btn-purple br-6">Read More</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section> -->
    <!--h2-we-are area end here-->

    <section class="section-padding">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="h2-we-make-heading heading-content pb-50 get-bottom animate">
                        <div class="section-title animate">
                            <h2 class="pb-10">About Us</h2>
                        </div>
                    </div>
                </div>
                <hr>
                <div class="col-md-12">
                    <div class="privacy-content">
                        
                        <p>Influencer Hai - A data-driven team of designer & creators transforming relationships between brands, influencers, and their audiences.</p>
                        <p class="mt-3">Influencer Hai is a leading influencer marketing firm that connects major brands with passionate, socially engaged audiences through social media influencers. Our goal is to establish relationships with new talent and assist brands in telling stories that matter. We firmly believe in a human-first approach to talent identification and high-touch service in addition to our dependable data and technology.</p>
                        <p class="mt-3">We complement brand marketing strategies with strong campaigns to guarantee high-quality engagement for the brand. Our user-friendly platform makes it simple for brands to create influencer marketing campaigns, collaborate with specific influencers, set marketing budgets, and track progress.</p>
                        <p class="mt-3">We also connect businesses with content curators across the country to maintain the competitiveness of their brand. We support businesses of all sizes in using social insights to generate more revenue. Our sponsored content campaigns captivate consumers, advance brand engagement and exposure, while increasing product sales. </p>
                       
                    </div>
                </div>
            </div>
        
        </div>
    </section>


    <section class="about-award pt-5- pt-md-60 pb-20 pb-md-30 pt-50 pb-50" style="background-color: #eef1fa">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-lg-6">
                    <div class="about-award-content get-bottom animate">
                        <div class="section-title animate">
                            <h2 class="pb-20">Our Mission</h2>
                        </div>
                        <p class="animate">Influencer Hai aspires to create a dynamic workplace where every individual can prosper and have a fulfilling career. Our mission is to unite a generation of digital creators and build strong relationships with our clients to create a diverse workplace that caters to everyone's needs.</p>
                    </div>
                </div>
                <div class="col-lg-6">
                    <div class="get-bottom animate">
                       <h2 class="pb-20">Our Vision</h2>
                       <p class="animate">As the #1 influencer marketing business in India, Influencer Hai wants to be a one-stop agency for brands and influencers. With the use of successful strategies, our goal is to make influencer marketing the most productive and sought-after path in the marketing landscape for businesses. We deploy storytelling, which we passionately believe has the power to lead effective brand communication.</p>
                    </div>
                </div>
            </div>
           
        </div>
    </section>

    <section class="counter-effect">
        <div class="container">
            <div class="row counter mt-50 pt-md-30 pb-50 mb-md-30">
                <div class="col-lg-3 col-6 get-bottom animate">
                    <div class="single-counter-two d-flex align-items-center justify-content-center">
                        <div class="h2-counter-icon  d-center svg-50 svg-grdnt-purple mr-15">
                           <img src="{{ asset('front_assets/img/svg/smile.svg') }}" alt="">
                        </div>
                        <div class="comon-counter-content text-center">
                            <span class="h2-cn1">3580</span>
                            <p>Food</p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-6 get-bottom animate">
                    <div class="single-counter-two d-flex align-items-center justify-content-center">
                        <div class="h2-counter-icon  d-center svg-50 svg-grdnt-purple mr-15">
                            <img src="{{ asset('front_assets/img/svg/user-cup.svg') }}" alt="">
                        </div>
                        <div class="comon-counter-content text-center">
                            <span class="h2-cn2">3580</span>
                            <p>Education</p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-6 get-bottom animate">
                    <div class="single-counter-two d-flex align-items-center justify-content-center">
                        <div class="h2-counter-icon d-center svg-50 svg-grdnt-purple mr-15">
                            <img src="{{ asset('front_assets/img/svg/tea-cup.svg') }}" alt="">
                        </div>
                        <div class="comon-counter-content text-center">
                            <span class="h2-cn3">1587</span>
                            <p>Mom</p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-6 get-bottom animate">
                    <div class="single-counter-two d-flex align-items-center justify-content-center">
                        <div class="h2-counter-icon d-center svg-50 svg-grdnt-purple mr-15">
                            <img src="{{ asset('front_assets/img/svg/layers.svg') }}" alt="">
                        </div>
                        <div class="comon-counter-content text-center">
                            <span class="h2-cn4">2548</span>
                            <p>Health</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

<!-- our executive -->

   <section class="h4-team-area section-bg-padding bg-gray">
        <div class="section-title get-bottom animate" style="opacity: 1; visibility: inherit; transform: translate(0px, 0px);">
            <h2 class="pb-50 text-center"> Our Executive Team</h2>
        </div>
        <div class="container">
            <div class="row">
                <div class="col-md-4 mb-sm-50 get-bottom animate" style="opacity: 1; visibility: inherit; transform: translate(0px, 0px);">
                    <div class="h4-single-team">
                        <div class="h4-team-img relative">
                            <img src="{{ asset('front_assets/img/executive/default.png') }}" alt="">
                            <div class="h4-team-social">
                                <ul class="d-flex">
                                    <li><a href=""><i class="icofont-facebook"></i></a></li>
                                    <li><a href=""><i class="icofont-behance"></i></a></li>
                                    <li><a href=""><i class="icofont-twitter"></i></a></li>
                                    <li><a href=""><i class="icofont-dribbble"></i></a></li>
                                </ul>
                            </div>
                        </div>
                        <div class="h4-team-cont text-center get-bottom animate" style="opacity: 1; visibility: inherit; transform: translate(0px, 0px);">
                            <div class="card-title animate melon-hover" style="opacity: 1; visibility: inherit; transform: translate(0px, 0px);">
                                <h3 class="pb-10"><a href="">Gaurav Kumar</a></h3>
                            </div>
                            <p class="animate" style="opacity: 1; visibility: inherit; transform: translate(0px, 0px);">Owner &amp; CEO</p>
                        </div>
                    </div>
                </div>
                
                <div class="col-md-4 mb-sm-50 get-bottom animate" style="opacity: 1; visibility: inherit; transform: translate(0px, 0px);">
                    <div class="h4-single-team">
                        <div class="h4-team-img relative">
                            <img src="{{ asset('front_assets/img/executive/amarjeet.png') }}" alt="">
                            <div class="h4-team-social">
                                <ul class="d-flex">
                                    <li><a href=""><i class="icofont-facebook"></i></a></li>
                                    <li><a href=""><i class="icofont-behance"></i></a></li>
                                    <li><a href=""><i class="icofont-twitter"></i></a></li>
                                    <li><a href=""><i class="icofont-dribbble"></i></a></li>
                                </ul>
                            </div>
                        </div>
                        <div class="h4-team-cont text-center get-bottom animate" style="opacity: 1; visibility: inherit; transform: translate(0px, 0px);">
                            <div class="card-title animate melon-hover" style="opacity: 1; visibility: inherit; transform: translate(0px, 0px);">
                                <h3 class="pb-10"><a href="">Amarjeet Singh</a></h3>
                            </div>
                            <p class="animate" style="opacity: 1; visibility: inherit; transform: translate(0px, 0px);">Marketing Head</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-4 get-bottom animate" style="opacity: 1; visibility: inherit; transform: translate(0px, 0px);">
                    <div class="h4-single-team">
                        <div class="h4-team-img relative">
                            <img src="{{ asset('front_assets/img/executive/manish.png') }}" alt="">
                            <div class="h4-team-social">
                                <ul class="d-flex">
                                    <li><a href=""><i class="icofont-facebook"></i></a></li>
                                    <li><a href=""><i class="icofont-behance"></i></a></li>
                                    <li><a href=""><i class="icofont-twitter"></i></a></li>
                                    <li><a href=""><i class="icofont-dribbble"></i></a></li>
                                </ul>
                            </div>
                        </div>
                        <div class="h4-team-cont text-center get-bottom animate" style="opacity: 1; visibility: inherit; transform: translate(0px, 0px);">
                            <div class="card-title animate melon-hover" style="opacity: 1; visibility: inherit; transform: translate(0px, 0px);">
                                <h3 class="pb-10"><a href="">Manish Mannu</a></h3>
                            </div>
                            <p class="animate" style="opacity: 1; visibility: inherit; transform: translate(0px, 0px);">Business Development Executive</p>
                        </div>
                    </div>
                </div>

                <div class="col-md-4 get-bottom animate" style="opacity: 1; visibility: inherit; transform: translate(0px, 0px);">
                    <div class="h4-single-team">
                        <div class="h4-team-img relative">
                            <img src="{{ asset('front_assets/img/executive/siddhi.png') }}" alt="">
                            <div class="h4-team-social">
                                <ul class="d-flex">
                                    <li><a href=""><i class="icofont-facebook"></i></a></li>
                                    <li><a href=""><i class="icofont-behance"></i></a></li>
                                    <li><a href=""><i class="icofont-twitter"></i></a></li>
                                    <li><a href=""><i class="icofont-dribbble"></i></a></li>
                                </ul>
                            </div>
                        </div>
                        <div class="h4-team-cont text-center get-bottom animate" style="opacity: 1; visibility: inherit; transform: translate(0px, 0px);">
                            <div class="card-title animate melon-hover" style="opacity: 1; visibility: inherit; transform: translate(0px, 0px);">
                                <h3 class="pb-10"><a href="">Siddhi</a></h3>
                            </div>
                            <p class="animate" style="opacity: 1; visibility: inherit; transform: translate(0px, 0px);">Influencer Marketing Executive</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-4 mb-sm-50 get-bottom animate" style="opacity: 1; visibility: inherit; transform: translate(0px, 0px);">
                    <div class="h4-single-team">
                        <div class="h4-team-img relative">
                            <img src="{{ asset('front_assets/img/executive/default.png') }}" alt="">
                            <div class="h4-team-social">
                                <ul class="d-flex">
                                    <li><a href=""><i class="icofont-facebook"></i></a></li>
                                    <li><a href=""><i class="icofont-behance"></i></a></li>
                                    <li><a href=""><i class="icofont-twitter"></i></a></li>
                                    <li><a href=""><i class="icofont-dribbble"></i></a></li>
                                </ul>
                            </div>
                        </div>
                        <div class="h4-team-cont text-center get-bottom animate" style="opacity: 1; visibility: inherit; transform: translate(0px, 0px);">
                            <div class="card-title animate melon-hover" style="opacity: 1; visibility: inherit; transform: translate(0px, 0px);">
                                <h3 class="pb-10"><a href="">Vikesh Sharma</a></h3>
                            </div>
                            <p class="animate" style="opacity: 1; visibility: inherit; transform: translate(0px, 0px);">Celebrity and PR Manager</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-4 get-bottom animate" style="opacity: 1; visibility: inherit; transform: translate(0px, 0px);">
                    <div class="h4-single-team">
                        <div class="h4-team-img relative">
                            <img src="{{ asset('front_assets/img/executive/yogesh.png') }}" alt="">
                            <div class="h4-team-social">
                                <ul class="d-flex">
                                    <li><a href=""><i class="icofont-facebook"></i></a></li>
                                    <li><a href=""><i class="icofont-behance"></i></a></li>
                                    <li><a href=""><i class="icofont-twitter"></i></a></li>
                                    <li><a href=""><i class="icofont-dribbble"></i></a></li>
                                </ul>
                            </div>
                        </div>
                        <div class="h4-team-cont text-center get-bottom animate" style="opacity: 1; visibility: inherit; transform: translate(0px, 0px);">
                            <div class="card-title animate melon-hover" style="opacity: 1; visibility: inherit; transform: translate(0px, 0px);">
                                <h3 class="pb-10"><a href="">Yogesh Sharma</a></h3>
                            </div>
                            <p class="animate" style="opacity: 1; visibility: inherit; transform: translate(0px, 0px);">Influencer Marketing Executive</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-4 get-bottom animate" style="opacity: 1; visibility: inherit; transform: translate(0px, 0px);">
                    <div class="h4-single-team">
                        <div class="h4-team-img relative">
                            <img src="{{ asset('front_assets/img/executive/subham.png') }}" alt="">
                            <div class="h4-team-social">
                                <ul class="d-flex">
                                    <li><a href=""><i class="icofont-facebook"></i></a></li>
                                    <li><a href=""><i class="icofont-behance"></i></a></li>
                                    <li><a href=""><i class="icofont-twitter"></i></a></li>
                                    <li><a href=""><i class="icofont-dribbble"></i></a></li>
                                </ul>
                            </div>
                        </div>
                        <div class="h4-team-cont text-center get-bottom animate" style="opacity: 1; visibility: inherit; transform: translate(0px, 0px);">
                            <div class="card-title animate melon-hover" style="opacity: 1; visibility: inherit; transform: translate(0px, 0px);">
                                <h3 class="pb-10"><a href="">Shubham Rawat</a></h3>
                            </div>
                            <p class="animate" style="opacity: 1; visibility: inherit; transform: translate(0px, 0px);">Business Development Executive</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-4 get-bottom animate" style="opacity: 1; visibility: inherit; transform: translate(0px, 0px);">
                    <div class="h4-single-team">
                        <div class="h4-team-img relative">
                            <img src="{{ asset('front_assets/img/executive/default.png') }}" alt="">
                            <div class="h4-team-social">
                                <ul class="d-flex">
                                    <li><a href=""><i class="icofont-facebook"></i></a></li>
                                    <li><a href=""><i class="icofont-behance"></i></a></li>
                                    <li><a href=""><i class="icofont-twitter"></i></a></li>
                                    <li><a href=""><i class="icofont-dribbble"></i></a></li>
                                </ul>
                            </div>
                        </div>
                        <div class="h4-team-cont text-center get-bottom animate" style="opacity: 1; visibility: inherit; transform: translate(0px, 0px);">
                            <div class="card-title animate melon-hover" style="opacity: 1; visibility: inherit; transform: translate(0px, 0px);">
                                <h3 class="pb-10"><a href="">Rahul Kumar</a></h3>
                            </div>
                            <p class="animate" style="opacity: 1; visibility: inherit; transform: translate(0px, 0px);">Content Writer</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-4 get-bottom animate" style="opacity: 1; visibility: inherit; transform: translate(0px, 0px);">
                    <div class="h4-single-team">
                        <div class="h4-team-img relative">
                            <img src="{{ asset('front_assets/img/executive/himanshu.png') }}" alt="">
                            <div class="h4-team-social">
                                <ul class="d-flex">
                                    <li><a href=""><i class="icofont-facebook"></i></a></li>
                                    <li><a href=""><i class="icofont-behance"></i></a></li>
                                    <li><a href=""><i class="icofont-twitter"></i></a></li>
                                    <li><a href=""><i class="icofont-dribbble"></i></a></li>
                                </ul>
                            </div>
                        </div>
                        <div class="h4-team-cont text-center get-bottom animate" style="opacity: 1; visibility: inherit; transform: translate(0px, 0px);">
                            <div class="card-title animate melon-hover" style="opacity: 1; visibility: inherit; transform: translate(0px, 0px);">
                                <h3 class="pb-10"><a href="">Himanshu Dhuoon</a></h3>
                            </div>
                            <p class="animate" style="opacity: 1; visibility: inherit; transform: translate(0px, 0px);">Celebrity and PR Manager</p>
                        </div>
                    </div>
                </div>
                <!-- <div class="col-md-4 get-bottom animate" style="opacity: 1; visibility: inherit; transform: translate(0px, 0px);">
                    <div class="h4-single-team">
                        <div class="h4-team-img relative">
                            <img src="{{ asset('front_assets/img/executive/default.png') }}" alt="">
                            <div class="h4-team-social">
                                <ul class="d-flex">
                                    <li><a href=""><i class="icofont-facebook"></i></a></li>
                                    <li><a href=""><i class="icofont-behance"></i></a></li>
                                    <li><a href=""><i class="icofont-twitter"></i></a></li>
                                    <li><a href=""><i class="icofont-dribbble"></i></a></li>
                                </ul>
                            </div>
                        </div>
                        <div class="h4-team-cont text-center get-bottom animate" style="opacity: 1; visibility: inherit; transform: translate(0px, 0px);">
                            <div class="card-title animate melon-hover" style="opacity: 1; visibility: inherit; transform: translate(0px, 0px);">
                                <h3 class="pb-10"><a href="">Anuj Raj</a></h3>
                            </div>
                            <p class="animate" style="opacity: 1; visibility: inherit; transform: translate(0px, 0px);">Content Writer</p>
                        </div>
                    </div>
                </div> -->
            </div>
        </div>
    </section>


    <!--our-clients area start here-->
    <section class="our-clients pt-10 pt-md-60 pb-50 pb-md-30">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-md-6">
                    <div class="clients-heading get-bottom animate">
                        <h2 class="pb-50 mx-width-80p">Some Feedback From Our Clients</h2>
                    </div>
                    <div class="clients-owl-nav d-flex align-items-center get-left animate">
                        <div class="co-prev co-comon mr-20">
                            <i class="icofont-long-arrow-right rotate-180 d-block"></i>
                        </div>
                        <div class="co-next co-comon">
                            <i class="icofont-long-arrow-right"></i>
                        </div>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="clients-owl-area owl-carousel" data-carousel-items="1">
                        <div class="single-cowl-wrap">
                            <div class="relative black-shadow single-client-owl radious-10">
                                <div class="client-owl-img black-shadow">
                                    <img src="{{ asset('front_assets/img/home1/client.png') }}" alt="">
                                </div>
                                <div class="get-bottom animate">
                                    <p class="pb-40 animate">I truly admire everything the Influencer Hai team has done for us. They truly deserve praise for the manner they handled our campaigns and for their dedication. We are happy to have Influencer Hai as a partner. Looking forward to more collaborations</p>
                                    <h3 class="pb-5 animate">Gravine Adwards</h3>
                                    <p class="animate">influencer</p>
                                </div>
                            </div>
                        </div>
                        <div class="single-cowl-wrap">
                            <div class="single-client-owl relative black-shadow radious-10">
                                <div class="client-owl-img black-shadow">
                                    <img src="{{ asset('front_assets/img/home1/client.png') }}" alt="">
                                </div>
                                <div class="get-bottom animate">
                                    <p class="pb-40 animate"> Our efforts to use influencer marketing to grow our business in India were massively assisted by the Influencer Hai team. They were able to locate extremely talented creators across a variety of industries, and they were in charge of the whole process from start to finish. The team is professional and dependable in all aspects. Without a doubt, this is a company I'll keep working with.</p>
                                    <h3 class="pb-5 animate">Gravine Adwards</h3>
                                    <p class="animate">influencer</p>
                                </div>
                            </div>
                        </div>
                        <div class="single-cowl-wrap">
                            <div class="single-client-owl relative black-shadow radious-10">
                                <div class="client-owl-img black-shadow">
                                    <img src="{{ asset('front_assets/img/home1/client.png') }}" alt="">
                                </div>
                                <div class="get-bottom animate">
                                    <p class="pb-40 animate">Influencerhai.com, is an influencer marketing platform, creating a chain of internet creators and consumers through scaling businesses</p>
                                    <h3 class="pb-5 animate">Gravine Adwards</h3>
                                    <p class="animate">influencer</p>
                                </div>
                            </div>
                        </div>
                        <div class="single-cowl-wrap">
                            <div class="single-client-owl relative black-shadow radious-10">
                                <div class="client-owl-img black-shadow">
                                    <img src="{{ asset('front_assets/img/home1/client.png') }}" alt="">
                                </div>
                                <div class="get-bottom animate">
                                    <p class="pb-40 animate">I have worked with the Influencer Hai crew on numerous occasions. The crew is knowledgeable, motivated, and skilled in the use of influencer marketing, and the outcomes we achieved speak highly of their expertise. Influencer hai is  your best bet if you want to use influencer marketing strategy to engage your customers. </p>
                                    <h3 class="pb-5 animate">Gravine Adwards</h3>
                                    <p class="animate">influencer</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--our-clients area end here-->

     <!--h2-logo slider start here-->
   <div class="h2-logo-slider  get-bottom animate pt-20 pb-20">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="owl-carousel owl-theme" id="owl-carousel002">
                        <div class="single-h2-slick item">
                            <img src="{{ asset('front_assets/img/brand/cocospy.jpg') }}" alt="">
                        </div>
                        <div class="single-h2-slick item">
                            <img src="{{ asset('front_assets/img/brand/cryptohill.jpg') }}" alt="">
                        </div>
                        <div class="single-h2-slick item">
                            <img src="{{ asset('front_assets/img/brand/dUETSCHE BANK.jpg') }}" alt="">
                        </div>
                        <div class="single-h2-slick item">
                            <img src="{{ asset('front_assets/img/brand/ekhelo.jpg') }}" alt="">
                        </div>
                        <div class="single-h2-slick item">
                            <img src="{{ asset('front_assets/img/brand/gEARBEST.jpg') }}" alt="">
                        </div>
                        <div class="single-h2-slick item">
                            <img src="{{ asset('front_assets/img/brand/iqoption.jpg') }}" alt="">
                        </div>
                        <div class="single-h2-slick item">
                            <img src="{{ asset('front_assets/img/brand/Hi dictionary.jpg') }}" alt="">
                        </div>
                        
                        <div class="single-h2-slick item">
                            <img src="{{ asset('front_assets/img/brand/Taxal.jpg') }}" alt="">
                        </div>
                        <div class="single-h2-slick item">
                            <img src="{{ asset('front_assets/img/brand/VideoBuddy.jpg') }}" alt="">
                        </div>
                        <div class="single-h2-slick item">
                            <img src="{{ asset('front_assets/img/brand/SPORTS11.jpg') }}" alt="">
                        </div>
                        <div class="single-h2-slick item">
                            <img src="{{ asset('front_assets/i') }}mg/brand/Quvideo-typhograpgy-type-loogo.jpg" alt="">
                        </div>
                        <div class="single-h2-slick item">
                            <img src="{{ asset('front_assets/img/brand/zorro.jpg') }}" alt="">
                        </div>
                        <div class="single-h2-slick">
                            <img src="{{ asset('front_assets/img/brand/ZUPEE.jpg') }}" alt="">
                        </div>
                        <div class="single-h2-slick item">
                            <img src="{{ asset('front_assets/img/brand/yelo.jpg') }}" alt="">
                        </div>
                        <div class="single-h2-slick">
                            <img src="{{ asset('front_assets/img/brand/meesho.jpg') }}" alt="">
                        </div>
                        <div class="single-h2-slick item">
                            <img src="{{ asset('front_assets/img/brand/MOUNTING DREAM.jpg') }}" alt="">
                        </div>
                        <div class="single-h2-slick item">
                            <img src="{{ asset('front_assets/img/brand/myteam11.jpg') }}" alt="">
                        </div>
                        <div class="single-h2-slick item">
                            <img src="{{ asset('front_assets/img/brand/ONEAXCESS.jpg') }}" alt="">
                        </div>
                        <div class="single-h2-slick item">
                            <img src="{{ asset('front_assets/img/brand/picsart.jpg') }}" alt="">
                        </div>
                        <div class="single-h2-slick item">
                            <img src="{{ asset('front_assets/img/brand/Vidlike- hor---.jpg') }}" alt="">
                        </div>
                        <div class="single-h2-slick item">
                            <img src="{{ asset('front_assets/img/brand/wondershare.jpg') }}" alt="">
                        </div>
                        <div class="single-h2-slick item">
                            <img src="{{ asset('front_assets/img/brand/WOOLY.jpg') }}" alt="">
                        </div>
                        <div class="single-h2-slick item">
                            <img src="{{ asset('front_assets/img/brand/WOOLY-WITHOUT-BG.jpg') }}" alt="">
                        </div>
                        </div>
                </div>
            </div>
        </div>
    </div>
    <!--h2-logo slider end here-->
@endsection

@section('scripts')
	@parent
	
@endsection