<!DOCTYPE html>
    <head>
        <title>@yield('title') Influencers Hub</title>
        <style type="text/css">img.wp-smiley,img.emoji{display:inline!important;border:none!important;box-shadow:none!important;height:1em!important;width:1em!important;margin:0 .07em!important;vertical-align:-.1em!important;background:none!important;padding:0!important}</style>
        @section('css')
            <link rel='stylesheet' id='wp-block-library-css' href="{{ asset('front-asset/css/style.mincfaa.css?ver=5.7.6') }}" type='text/css' media='all' />
            <link rel='stylesheet' id='wpfront-scroll-top-css' href="{{ asset('front-asset/css/wpfront-scroll-top.min4c56.css?ver=2.0.2') }}" type='text/css' media='all' />
            <link rel='stylesheet' id='hello-elementor-css' href="{{ asset('front-asset/css/style.min254d.css?ver=2.3.1') }}" type='text/css' media='all' />
            <link rel='stylesheet' id='hello-elementor-theme-style-css' href="{{ asset('front-asset/css/theme.min254d.css?ver=2.3.1') }}" type='text/css' media='all' />
            <link rel='stylesheet' id='elementor-icons-css' href="{{ asset('front-asset/css/elementor-icons.min21f9.css?ver=5.11.0') }}" type='text/css' media='all' />
            <link rel='stylesheet' id='elementor-animations-css' href="{{ asset('front-asset/css/animations.minaeb9.css?ver=3.1.4') }}" type='text/css' media='all' />
            <link rel='stylesheet' id='elementor-frontend-legacy-css' href="{{ asset('front-asset/css/frontend-legacy.minaeb9.css?ver=3.1.4') }}" type='text/css' media='all' />
            <link rel='stylesheet' id='elementor-frontend-css' href="{{ asset('front-asset/css/frontend.minaeb9.css?ver=3.1.4') }}" type='text/css' media='all' />
            <link rel='stylesheet' id='elementor-post-833-css' href="{{ asset('front-asset/css/post-833bfd9.css?ver=1615651984') }}" type='text/css' media='all' />
            <link rel='stylesheet' id='elementor-pro-css' href="{{ asset('front-asset/css/frontend.minb12b.css?ver=3.1.1') }}" type='text/css' media='all' />
            <link rel='stylesheet' id='uael-frontend-css' href="{{ asset('front-asset/css/uael-frontend.min35d0.css?ver=1.12.1') }}" type='text/css' media='all' />
            <link rel='stylesheet' id='she-header-style-css' href="{{ asset('front-asset/css/she-header-style370e.css?ver=1.4.3') }}" type='text/css' media='all' />
            <link rel='stylesheet' id='elementor-post-2361-css' href="{{ asset('front-asset/css/post-236187df.css?ver=1619283153') }}" type='text/css' media='all' />
            <link rel='stylesheet' id='elementor-post-6-css' href="{{ asset('front-asset/css/post-6bfd9.css?ver=1615651984') }}" type='text/css' media='all' />
            <link rel='stylesheet' id='elementor-post-75-css' href="{{ asset('front-asset/css/post-75bfd9.css?ver=1615651984') }}" type='text/css' media='all' />
            <link rel='stylesheet' id='notificationx-css' href="{{ asset('front-asset/css/notificationx-public.min2c00.css?ver=1.9.2') }}" type='text/css' media='all' />
            <link rel='stylesheet' id='google-fonts-1-css' href='https://fonts.googleapis.com/css?family=Roboto%3A100%2C100italic%2C200%2C200italic%2C300%2C300italic%2C400%2C400italic%2C500%2C500italic%2C600%2C600italic%2C700%2C700italic%2C800%2C800italic%2C900%2C900italic%7CRoboto+Slab%3A100%2C100italic%2C200%2C200italic%2C300%2C300italic%2C400%2C400italic%2C500%2C500italic%2C600%2C600italic%2C700%2C700italic%2C800%2C800italic%2C900%2C900italic%7COpen+Sans%3A100%2C100italic%2C200%2C200italic%2C300%2C300italic%2C400%2C400italic%2C500%2C500italic%2C600%2C600italic%2C700%2C700italic%2C800%2C800italic%2C900%2C900italic%7CRubik%3A100%2C100italic%2C200%2C200italic%2C300%2C300italic%2C400%2C400italic%2C500%2C500italic%2C600%2C600italic%2C700%2C700italic%2C800%2C800italic%2C900%2C900italic%7CLato%3A100%2C100italic%2C200%2C200italic%2C300%2C300italic%2C400%2C400italic%2C500%2C500italic%2C600%2C600italic%2C700%2C700italic%2C800%2C800italic%2C900%2C900italic%7CMontserrat%3A100%2C100italic%2C200%2C200italic%2C300%2C300italic%2C400%2C400italic%2C500%2C500italic%2C600%2C600italic%2C700%2C700italic%2C800%2C800italic%2C900%2C900italic%7CWork+Sans%3A100%2C100italic%2C200%2C200italic%2C300%2C300italic%2C400%2C400italic%2C500%2C500italic%2C600%2C600italic%2C700%2C700italic%2C800%2C800italic%2C900%2C900italic&#038;ver=5.7.6' type='text/css' media='all' />
            <link rel='stylesheet' id='google-earlyaccess-2-css' href="{{ asset('front-asset/css/opensanshebrewcfaa.css?ver=5.7.6') }}" type='text/css' media='all' />
            <link rel='stylesheet' id='elementor-icons-shared-0-css' href="{{ asset('front-asset/css/font-awesome/fontawesome.min9e0b.css?ver=5.15.1') }}" type='text/css' media='all' />
            <link rel='stylesheet' id='elementor-icons-fa-solid-css' href="{{ asset('front-asset/css/font-awesome/solid.min9e0b.css?ver=5.15.1') }}" type='text/css' media='all' />
            <link rel='stylesheet' id='elementor-icons-fa-brands-css' href="{{ asset('front-asset/css/font-awesome/brands.min9e0b.css?ver=5.15.1') }}" type='text/css' media='all' />
            
            
            
           
   
            <style>.no-js img.lazyload{display:none}figure.wp-block-image img.lazyloading{min-width:150px}.lazyload,.lazyloading{opacity:0}.lazyloaded{opacity:1;transition:opacity 400ms;transition-delay:0ms}</style>
            <link rel="icon" href="wp-content/uploads/2019/09/cropped-fav-32x32.png" sizes="32x32" />
            <link rel="icon" href="wp-content/uploads/2019/09/cropped-fav-192x192.png" sizes="192x192" />
            <link rel="apple-touch-icon" href="wp-content/uploads/2019/09/cropped-fav-180x180.png" />
            <meta name="msapplication-TileImage" content="https://letsinfluence.io/wp-content/uploads/2019/09/cropped-fav-270x270.png" />
           
            <style type="text/css" id="wp-custom-css">#bitnami-banner{display:none}</style> 
        @show

        @section('head-scripts')
            <script type='text/javascript' src="{{ asset('front-asset/js/jquery/jquery.min9d52.js?ver=3.5.1') }}" id='jquery-core-js'></script>
            <!-- <script type='text/javascript' src="{{ asset('front-asset/js/jquery/jquery-migrate.mind617.js?ver=3.3.2') }}" id='jquery-migrate-js'></script> -->
            <script async src="https://www.googletagmanager.com/gtag/js?id=UA-153140031-1"></script>
            <script>window.dataLayer=window.dataLayer||[];function gtag(){dataLayer.push(arguments);}gtag('js',new Date());gtag('config','UA-153140031-1');</script>


            <script async src="https://www.googletagmanager.com/gtag/js?id=UA-166296653-1"></script>
            <script>window.dataLayer=window.dataLayer||[];function gtag(){dataLayer.push(arguments);}gtag('js',new Date());gtag('config','UA-166296653-1');</script>
            <script>document.documentElement.className=document.documentElement.className.replace('no-js','js');</script>
            <script type="text/javascript">var notificationx={nonce:'23324e99cf',ajaxurl:'https://letsinfluence.io/wp-admin/admin-ajax.php',notificatons:[],global_notifications:[],conversions:[],comments:[],reviews:[],stats:[],form:[],pro_ext:[],};</script>

        @show




    </head>
    <body>
        @section('header')
            <div data-elementor-type="header" data-elementor-id="6" class="elementor elementor-6 elementor-location-header" data-elementor-settings="[]">
                <div class="elementor-section-wrap">
                    <section class="elementor-section elementor-top-section elementor-element elementor-element-e75cc15 elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="e75cc15" data-element_type="section" id="logohide" data-settings="{&quot;background_background&quot;:&quot;classic&quot;,&quot;sticky&quot;:&quot;top&quot;,&quot;sticky_on&quot;:[&quot;desktop&quot;,&quot;tablet&quot;,&quot;mobile&quot;],&quot;sticky_offset&quot;:0,&quot;sticky_effects_offset&quot;:0}">
                        <div class="elementor-container elementor-column-gap-default">
                            <div class="elementor-row">
                                <div class="elementor-column elementor-col-50 elementor-top-column elementor-element elementor-element-a55e552" data-id="a55e552" data-element_type="column">
                                    <div class="elementor-column-wrap elementor-element-populated">
                                        <div class="elementor-widget-wrap">
                                            <div class="elementor-element elementor-element-5d07cae elementor-widget elementor-widget-image" data-id="5d07cae" data-element_type="widget" id="logohide" data-widget_type="image.default">
                                                <div class="elementor-widget-container">
                                                    <div class="elementor-image">
                                                        <a href="{{ route('home') }}" data-wpel-link="internal">
                                                            <img width="1229" height="209" src="{{ asset('front-asset/img/logo/influencers-hub1.png') }}" loading="lazy" >
                                                            <!-- <img width="1229" height="209" alt="" loading="lazy" data-srcset="https://letsinfluence.io/wp-content/uploads/2019/09/logotop.png 1229w, https://letsinfluence.io/wp-content/uploads/2019/09/logotop-300x51.png 300w, https://letsinfluence.io/wp-content/uploads/2019/09/logotop-768x131.png 768w, https://letsinfluence.io/wp-content/uploads/2019/09/logotop-1024x174.png 1024w" data-src="https://letsinfluence.io/wp-content/uploads/2019/09/logotop.png" data-sizes="(max-width: 1229px) 100vw, 1229px" class="attachment-full size-full lazyload" src="data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==" /><noscript><img width="1229" height="209" src="wp-content/uploads/2019/09/logotop.png" class="attachment-full size-full" alt="" loading="lazy" srcset="https://letsinfluence.io/wp-content/uploads/2019/09/logotop.png 1229w, https://letsinfluence.io/wp-content/uploads/2019/09/logotop-300x51.png 300w, https://letsinfluence.io/wp-content/uploads/2019/09/logotop-768x131.png 768w, https://letsinfluence.io/wp-content/uploads/2019/09/logotop-1024x174.png 1024w" sizes="(max-width: 1229px) 100vw, 1229px"/></noscript> </a> -->
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="elementor-column elementor-col-50 elementor-top-column elementor-element elementor-element-eda04ab" data-id="eda04ab" data-element_type="column">
                                        <div class="elementor-column-wrap elementor-element-populated">
                                            <div class="elementor-widget-wrap">
                                                <div class="elementor-element elementor-element-cb3e62c elementor-nav-menu__align-right elementor-nav-menu--stretch elementor-nav-menu--indicator-classic elementor-nav-menu--dropdown-tablet elementor-nav-menu__text-align-aside elementor-nav-menu--toggle elementor-nav-menu--burger elementor-widget elementor-widget-nav-menu" data-id="cb3e62c" data-element_type="widget" data-settings="{&quot;full_width&quot;:&quot;stretch&quot;,&quot;layout&quot;:&quot;horizontal&quot;,&quot;toggle&quot;:&quot;burger&quot;}" data-widget_type="nav-menu.default">
                                                    <div class="elementor-widget-container">
                                                        <nav role="navigation" class="elementor-nav-menu--main elementor-nav-menu__container elementor-nav-menu--layout-horizontal e--pointer-none"><ul id="menu-1-cb3e62c" class="elementor-nav-menu"><li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-home current-menu-item page_item page-item-2361 current_page_item menu-item-3040"><a href="{{ route('home') }}" aria-current="page" class="elementor-item elementor-item-active" data-wpel-link="internal"><i>HOME</i></a></li>
                                                            <li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-3039"><a href="{{ route('about') }}" class="elementor-item" data-wpel-link="internal"><i>ABOUT US</i></a></li>
                                                            <li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-3038"><a href="{{ route('blog') }}" class="elementor-item" data-wpel-link="internal"><i>BLOG</i></a></li>
                                                            <li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-3036"><a href="{{ route('contact') }}" class="elementor-item" data-wpel-link="internal"><i>Get In Touch</i></a></li>
                                                        </ul></nav>
                                                        <div class="elementor-menu-toggle" role="button" tabindex="0" aria-label="Menu Toggle" aria-expanded="false">
                                                            <i class="eicon-menu-bar" aria-hidden="true"></i>
                                                            <span class="elementor-screen-only">Menu</span>
                                                        </div>
                                                        <nav class="elementor-nav-menu--dropdown elementor-nav-menu__container" role="navigation" aria-hidden="true"><ul id="menu-2-cb3e62c" class="elementor-nav-menu"><li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-home current-menu-item page_item page-item-2361 current_page_item menu-item-3040"><a href="{{ route('home') }}" aria-current="page" class="elementor-item elementor-item-active" data-wpel-link="internal"><i>HOME</i></a></li>
                                                            <li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-3039"><a href="{{ route('about') }}" class="elementor-item" data-wpel-link="internal"><i>ABOUT US</i></a></li>
                                                            <li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-3038"><a href="{{ route('blog') }}" class="elementor-item" data-wpel-link="internal"><i>BLOG</i></a></li>
                                                            <li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-3036"><a href="{{ route('contact') }}" class="elementor-item" data-wpel-link="internal"><i>Get In Touch</i></a></li>
                                                        </ul></nav>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                        </div>
                    </section>
                    
                </div>
            </div>
        @show
 
        <div class="container">
            @yield('content')
        </div>



        @section('footer')
        <div data-elementor-type="footer" data-elementor-id="75" class="elementor elementor-75 elementor-location-footer" data-elementor-settings="[]">
            <div class="elementor-section-wrap">
                <section class="elementor-section elementor-top-section elementor-element elementor-element-65053038 elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="65053038" data-element_type="section" data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
                    <div class="elementor-container elementor-column-gap-default">
                        <div class="elementor-row">
                            <div class="elementor-column elementor-col-25 elementor-top-column elementor-element elementor-element-4485db5c" data-id="4485db5c" data-element_type="column">
                                <div class="elementor-column-wrap elementor-element-populated">
                                    <div class="elementor-widget-wrap">
                                    <div class="elementor-element elementor-element-b93ba23 elementor-widget elementor-widget-heading" data-id="b93ba23" data-element_type="widget" data-widget_type="heading.default">
                                    <div class="elementor-widget-container">
                                        <h2 class="elementor-heading-title elementor-size-default">About</h2> </div>
                            </div>
                            <div class="elementor-element elementor-element-203f4921 elementor-widget elementor-widget-text-editor" data-id="203f4921" data-element_type="widget" data-widget_type="text-editor.default">
                                <div class="elementor-widget-container">
                                    <div class="elementor-text-editor elementor-clearfix"><p>Letsinfluence.io is a platform connecting brands and influencers. We enable brands to reach the right audiences by matching them with the right influencers resulting in massive growth. We help social media enthusiasts and creators to sell branded content and in the process become a brand themselves.</p></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="elementor-column elementor-col-25 elementor-top-column elementor-element elementor-element-94b9098" data-id="94b9098" data-element_type="column">
                    <div class="elementor-column-wrap elementor-element-populated">
                        <div class="elementor-widget-wrap">
                            <div class="elementor-element elementor-element-3abe091 elementor-widget elementor-widget-heading" data-id="3abe091" data-element_type="widget" data-widget_type="heading.default">
                                <div class="elementor-widget-container">
                                    <h2 class="elementor-heading-title elementor-size-default">Quick Links</h2> </div>
                                </div>
                                <div class="elementor-element elementor-element-c31ed4d elementor-align-left elementor-mobile-align-left elementor-icon-list--layout-traditional elementor-list-item-link-full_width elementor-widget elementor-widget-icon-list" data-id="c31ed4d" data-element_type="widget" data-widget_type="icon-list.default">
                                    <div class="elementor-widget-container">
                                        <ul class="elementor-icon-list-items">
                                            <li class="elementor-icon-list-item">
                                                <a href="{{ route('influencer') }}" data-wpel-link="internal"> <span class="elementor-icon-list-text">For Influencer </span>
                                                </a>
                                            </li>
                                            <li class="elementor-icon-list-item">
                                                <a href="{{ route('brand') }}" data-wpel-link="internal"> <span class="elementor-icon-list-text">For Brand</span>
                                                </a>
                                            </li>
                                            <li class="elementor-icon-list-item">
                                                <a href="{{ route('about') }}" data-wpel-link="internal"> <span class="elementor-icon-list-text">About</span>
                                                </a>
                                            </li>
                                            <li class="elementor-icon-list-item">
                                                <a href="{{ route('blog') }}" data-wpel-link="internal"> <span class="elementor-icon-list-text">Blog</span>
                                                </a>
                                            </li>
                                            <li class="elementor-icon-list-item">
                                                <a href="{{ route('home') }}" data-wpel-link="internal"> <span class="elementor-icon-list-text">Contact</span>
                                                </a>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="elementor-column elementor-col-25 elementor-top-column elementor-element elementor-element-6d0a2a0" data-id="6d0a2a0" data-element_type="column">
                        <div class="elementor-column-wrap elementor-element-populated">
                            <div class="elementor-widget-wrap">
                                <div class="elementor-element elementor-element-425a49c elementor-widget elementor-widget-heading" data-id="425a49c" data-element_type="widget" data-widget_type="heading.default">
                                    <div class="elementor-widget-container">
                                        <h2 class="elementor-heading-title elementor-size-default">Company</h2> </div>
                                    </div>
                                    <div class="elementor-element elementor-element-7733c5d elementor-align-left elementor-mobile-align-left elementor-icon-list--layout-traditional elementor-list-item-link-full_width elementor-widget elementor-widget-icon-list" data-id="7733c5d" data-element_type="widget" data-widget_type="icon-list.default">
                                        <div class="elementor-widget-container">
                                            <ul class="elementor-icon-list-items">
                                                <li class="elementor-icon-list-item">
                                                    <a href="{{ route('influencer') }}" data-wpel-link="internal"> <span class="elementor-icon-list-text">For Influencer </span>
                                                    </a>
                                                </li>
                                                <li class="elementor-icon-list-item">
                                                    <a href="{{ route('brand') }}" data-wpel-link="internal"> <span class="elementor-icon-list-text">For Brand</span>
                                                    </a>
                                                </li>
                                                <li class="elementor-icon-list-item">
                                                    <a href="{{ route('about') }}" data-wpel-link="internal"> <span class="elementor-icon-list-text">About</span>
                                                    </a>
                                                </li>
                                                <li class="elementor-icon-list-item">
                                                    <a href="{{ route('blog') }}" data-wpel-link="internal"> <span class="elementor-icon-list-text">Blog</span>
                                                    </a>
                                                </li>
                                                <li class="elementor-icon-list-item">
                                                    <a href="{{ route('contact') }}" data-wpel-link="internal"> <span class="elementor-icon-list-text">Contact</span>
                                                    </a>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="elementor-column elementor-col-25 elementor-top-column elementor-element elementor-element-377ee867" data-id="377ee867" data-element_type="column">
                            <div class="elementor-column-wrap elementor-element-populated">
                                <div class="elementor-widget-wrap">
                                    <div class="elementor-element elementor-element-8e0bd37 elementor-widget elementor-widget-image" data-id="8e0bd37" data-element_type="widget" data-widget_type="image.default">
                                        <div class="elementor-widget-container">
                                            <div class="elementor-image">
                                                <!-- <img width="800" height="136" alt="" loading="lazy" data-srcset="https://letsinfluence.io/wp-content/uploads/2019/09/on_dark_bg___2-2-1024x174.png 1024w, https://letsinfluence.io/wp-content/uploads/2019/09/on_dark_bg___2-2-300x51.png 300w, https://letsinfluence.io/wp-content/uploads/2019/09/on_dark_bg___2-2-768x131.png 768w, https://letsinfluence.io/wp-content/uploads/2019/09/on_dark_bg___2-2.png 1229w" data-src="https://letsinfluence.io/wp-content/uploads/2019/09/on_dark_bg___2-2-1024x174.png" data-sizes="(max-width: 800px) 100vw, 800px" class="attachment-large size-large lazyload" src="data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==" /><noscript><img width="800" height="136" src="wp-content/uploads/2019/09/on_dark_bg___2-2-1024x174.png" class="attachment-large size-large" alt="" loading="lazy" srcset="https://letsinfluence.io/wp-content/uploads/2019/09/on_dark_bg___2-2-1024x174.png 1024w, https://letsinfluence.io/wp-content/uploads/2019/09/on_dark_bg___2-2-300x51.png 300w, https://letsinfluence.io/wp-content/uploads/2019/09/on_dark_bg___2-2-768x131.png 768w, https://letsinfluence.io/wp-content/uploads/2019/09/on_dark_bg___2-2.png 1229w" sizes="(max-width: 800px) 100vw, 800px"/></noscript>  -->
                                                 <img width="1229" height="209" src="{{ asset('front-asset/img/logo/influencers-hub.png') }}">
                                            </div>
                                            </div>
                                        </div>
                                        <div class="elementor-element elementor-element-5f18138 elementor-align-left elementor-mobile-align-left elementor-icon-list--layout-traditional elementor-list-item-link-full_width elementor-widget elementor-widget-icon-list" data-id="5f18138" data-element_type="widget" data-widget_type="icon-list.default">
                                            <div class="elementor-widget-container">
                                                <ul class="elementor-icon-list-items">
                                                    <li class="elementor-icon-list-item">
                                                        <a href="http://..//influencer" data-wpel-link="external" rel="nofollow external noopener noreferrer"> <span class="elementor-icon-list-text">Terms of Services</span>
                                                        </a>
                                                    </li>
                                                    <li class="elementor-icon-list-item">
                                                        <a href="http://..//contact" data-wpel-link="external" rel="nofollow external noopener noreferrer"> <span class="elementor-icon-list-text">Privacy Policy</span>
                                                        </a>
                                                    </li>
                                                </ul>
                                            </div>
                                        </div>
                                        <div class="elementor-element elementor-element-4ba0024 elementor-shape-circle e-grid-align-left elementor-grid-0 elementor-widget elementor-widget-social-icons" data-id="4ba0024" data-element_type="widget" data-widget_type="social-icons.default">
                                            <div class="elementor-widget-container">
                                                <div class="elementor-social-icons-wrapper elementor-grid">
                                                    <div class="elementor-grid-item">
                                                        <a class="elementor-icon elementor-social-icon elementor-social-icon-facebook elementor-repeater-item-d834224" href="https://www.facebook.com/letsinfluence.io/" target="_blank" data-wpel-link="external" rel="nofollow external noopener noreferrer">
                                                            <span class="elementor-screen-only">Facebook</span>
                                                            <i class="fab fa-facebook"></i> </a>
                                                        </div>
                                                        <div class="elementor-grid-item">
                                                            <a class="elementor-icon elementor-social-icon elementor-social-icon-linkedin elementor-repeater-item-d82f4eb" href="https://www.linkedin.com/in/let-sinfluence-india-066161190/" target="_blank" data-wpel-link="external" rel="nofollow external noopener noreferrer">
                                                                <span class="elementor-screen-only">Linkedin</span>
                                                                <i class="fab fa-linkedin"></i> </a>
                                                            </div>
                                                            <div class="elementor-grid-item">
                                                                <a class="elementor-icon elementor-social-icon elementor-social-icon-instagram elementor-repeater-item-e9f7c69" href="https://www.instagram.com/letsinfluence.io/" target="_blank" data-wpel-link="external" rel="nofollow external noopener noreferrer">
                                                                    <span class="elementor-screen-only">Instagram</span>
                                                                    <i class="fab fa-instagram"></i> </a>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </section>
            <footer class="elementor-section elementor-top-section elementor-element elementor-element-5f4e285 elementor-section-height-min-height elementor-section-content-middle elementor-section-boxed elementor-section-height-default elementor-section-items-middle" data-id="5f4e285" data-element_type="section" data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
                <div class="elementor-container elementor-column-gap-default">
                    <div class="elementor-row">
                        <div class="elementor-column elementor-col-50 elementor-top-column elementor-element elementor-element-177861a3" data-id="177861a3" data-element_type="column">
                            <div class="elementor-column-wrap elementor-element-populated">
                                <div class="elementor-widget-wrap">
                                    <div class="elementor-element elementor-element-522553c7 elementor-widget elementor-widget-heading" data-id="522553c7" data-element_type="widget" data-widget_type="heading.default">
                                        <div class="elementor-widget-container">
                                            <h3 class="elementor-heading-title elementor-size-default">© All rights reserved</h3> </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="elementor-column elementor-col-50 elementor-top-column elementor-element elementor-element-da2f0ef" data-id="da2f0ef" data-element_type="column">
                                <div class="elementor-column-wrap elementor-element-populated">
                                    <div class="elementor-widget-wrap">
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </footer>
            </div>
        </div>
        @show

        @section('scripts')

        <div id="wpfront-scroll-top-container">
            <img alt="" data-src="https://letsinfluence.io/wp-content/plugins/wpfront-scroll-top/images/icons/116.png" class="lazyload" src="data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==" /><noscript><img src="wp-content/plugins/wpfront-scroll-top/images/icons/116.png" alt=""/></noscript> 
        </div>
        <script type="text/javascript">function wpfront_scroll_top_init(){if(typeof wpfront_scroll_top=="function"&&typeof jQuery!=="undefined"){wpfront_scroll_top({"scroll_offset":100,"button_width":30,"button_height":30,"button_opacity":0.8,"button_fade_duration":200,"scroll_duration":400,"location":1,"marginX":20,"marginY":20,"hide_iframe":false,"auto_hide":false,"auto_hide_after":2,"button_action":"top","button_action_element_selector":"","button_action_container_selector":"html, body","button_action_element_offset":0});}else{setTimeout(wpfront_scroll_top_init,100);}}wpfront_scroll_top_init();</script><script type='text/javascript' id='flying-pages-js-before'>window.FPConfig={delay:0,ignoreKeywords:["\/wp-admin","#\/wp-login.php","\/cart","add-to-cart","logout","#","?",".png",".jpeg",".jpg",".gif",".svg"],maxRPS:0,hoverDelay:50};</script>
        <script type='text/javascript' src="{{ asset('front-asset/js/flying-pages.mina305.js?ver=2.4.2') }}" id='flying-pages-js' defer></script>
        <script type='text/javascript' src="{{ asset('front-asset/js/wpfront-scroll-top.min4c56.js?ver=2.0.2') }}" id='wpfront-scroll-top-js'></script>
        <script type='text/javascript' src="{{ asset('front-asset/js/smush-lazy-load.mincd70.js?ver=3.8.3') }}" id='smush-lazy-load-js'></script>
        <script type='text/javascript' src="{{ asset('front-asset/js/Cookies2c00.js?ver=1.9.2') }}" id='notificationx-cookie-js'></script>
        <script type='text/javascript' id='notificationx-js-extra'>//<![CDATA[
        var NotificationX={"ajaxurl":"https:\/\/letsinfluence.io\/wp-admin\/admin-ajax.php"};
        //]]></script>
        <script type='text/javascript' src="{{ asset('front-asset/js/notificationx-public2c00.js?ver=1.9.2') }}" id='notificationx-js'></script>
        <script type='text/javascript' src="{{ asset('front-asset/js/wp-embed.mincfaa.js?ver=5.7.6') }}" id='wp-embed-js'></script>
        <script type='text/javascript' src="{{ asset('front-asset/js/jquery.smartmenus.minf269.js?ver=1.0.1') }}" id='smartmenus-js'></script>
        <script type='text/javascript' src="{{ asset('front-asset/js/imagesloaded.mineda1.js?ver=4.1.4') }}" id='imagesloaded-js'></script>
        <script type='text/javascript' src="{{ asset('front-asset/js/webpack-pro.runtime.minb12b.js?ver=3.1.1') }}" id='elementor-pro-webpack-runtime-js'></script>
        <script type='text/javascript' src="{{ asset('front-asset/js/webpack.runtime.minaeb9.js?ver=3.1.4') }}" id='elementor-webpack-runtime-js'></script>
        <script type='text/javascript' src="{{ asset('front-asset/js/frontend-modules.minaeb9.js?ver=3.1.4') }}" id='elementor-frontend-modules-js'></script>
        <script type='text/javascript' src="{{ asset('front-asset/js/jquery.sticky.minb12b.js?ver=3.1.1') }}" id='elementor-sticky-js'></script>
        <script type='text/javascript' id='elementor-pro-frontend-js-before'>var ElementorProFrontendConfig={"ajaxurl":"https:\/\/letsinfluence.io\/wp-admin\/admin-ajax.php","nonce":"77762379cc","urls":{"assets":"https:\/\/letsinfluence.io\/wp-content\/plugins\/elementor-pro\/assets\/"},"i18n":{"toc_no_headings_found":"No headings were found on this page."},"shareButtonsNetworks":{"facebook":{"title":"Facebook","has_counter":true},"twitter":{"title":"Twitter"},"google":{"title":"Google+","has_counter":true},"linkedin":{"title":"LinkedIn","has_counter":true},"pinterest":{"title":"Pinterest","has_counter":true},"reddit":{"title":"Reddit","has_counter":true},"vk":{"title":"VK","has_counter":true},"odnoklassniki":{"title":"OK","has_counter":true},"tumblr":{"title":"Tumblr"},"digg":{"title":"Digg"},"skype":{"title":"Skype"},"stumbleupon":{"title":"StumbleUpon","has_counter":true},"mix":{"title":"Mix"},"telegram":{"title":"Telegram"},"pocket":{"title":"Pocket","has_counter":true},"xing":{"title":"XING","has_counter":true},"whatsapp":{"title":"WhatsApp"},"email":{"title":"Email"},"print":{"title":"Print"}},"facebook_sdk":{"lang":"en_US","app_id":""},"lottie":{"defaultAnimationUrl":"https:\/\/letsinfluence.io\/wp-content\/plugins\/elementor-pro\/modules\/lottie\/assets\/animations\/default.json"}};</script>
        <script type='text/javascript' src="{{ asset('front-asset/js/frontend.minb12b.js?ver=3.1.1') }}"  id='elementor-pro-frontend-js'></script>
        <script type='text/javascript' src="{{ asset('front-asset/js/core.min35d0.js?ver=1.12.1') }}"  id='jquery-ui-core-js'></script>
        <script type='text/javascript' src="{{ asset('front-asset/js/dialog.mina288.js?ver=4.8.1') }}"  id='elementor-dialog-js'></script>
        <script type='text/javascript' src="{{ asset('front-asset/js/waypoints.min05da.js?ver=4.0.2') }}"  id='elementor-waypoints-js'></script>
        <script type='text/javascript' src="{{ asset('front-asset/js/share-link.minaeb9.js?ver=3.1.4') }}"  id='share-link-js'></script>
        <script type='text/javascript' src="{{ asset('front-asset/js/swiper.min48f5.js?ver=5.3.6') }}"  id='swiper-js'></script>
        <script type='text/javascript' id='elementor-frontend-js-before'>var elementorFrontendConfig={"environmentMode":{"edit":false,"wpPreview":false,"isScriptDebug":false,"isImprovedAssetsLoading":false},"i18n":{"shareOnFacebook":"Share on Facebook","shareOnTwitter":"Share on Twitter","pinIt":"Pin it","download":"Download","downloadImage":"Download image","fullscreen":"Fullscreen","zoom":"Zoom","share":"Share","playVideo":"Play Video","previous":"Previous","next":"Next","close":"Close"},"is_rtl":false,"breakpoints":{"xs":0,"sm":480,"md":768,"lg":1025,"xl":1440,"xxl":1600},"version":"3.1.4","is_static":false,"experimentalFeatures":[],"urls":{"assets":"https:\/\/letsinfluence.io\/wp-content\/plugins\/elementor\/assets\/"},"settings":{"page":[],"editorPreferences":[]},"kit":{"global_image_lightbox":"yes","lightbox_enable_counter":"yes","lightbox_enable_fullscreen":"yes","lightbox_enable_zoom":"yes","lightbox_enable_share":"yes","lightbox_title_src":"title","lightbox_description_src":"description"},"post":{"id":2361,"title":"Lets%20Influence%20%E2%80%93%20Influencer%20Marketing%20Agency%20India","excerpt":"","featuredImage":false}};</script>
        <script type='text/javascript' src="{{ asset('front-asset/js/frontend.minaeb9.js?ver=3.1.4') }}" id='elementor-frontend-js'></script>
        <script type='text/javascript' src="{{ asset('front-asset/js/preloaded-elements-handlers.minb12b.js?ver=3.1.1') }}" id='pro-preloaded-elements-handlers-js'></script>
        <script type='text/javascript' src="{{ asset('front-asset/js/preloaded-elements-handlers.minaeb9.js?ver=3.1.4') }}" id='preloaded-elements-handlers-js'></script>
        <div id="bitnami-banner" data-banner-id="1ea0f"> <style>#bitnami-banner{z-index:100000;height:80px;padding:0;width:120px;background:transparent;position:fixed;right:0;bottom:0;border:0 solid #ededed}#bitnami-banner .bitnami-corner-image-div{position:fixed;right:0;bottom:0;border:0;z-index:100001;height:110px}#bitnami-banner .bitnami-corner-image-div .bitnami-corner-image{position:fixed;right:0;bottom:0;border:0;z-index:100001;height:110px}#bitnami-close-banner-button{height:12px;width:12px;z-index:10000000000;position:fixed;right:5px;bottom:65px;display:none;cursor:pointer}</style> <img id="bitnami-close-banner-button" src="bitnami/images/close.png" /> <div class="bitnami-corner-image-div"> <a href="bitnami/index.html" target="_blank"> <img class="bitnami-corner-image" alt="Bitnami" src="bitnami/images/corner-logo.png" /> </a> </div> 
            <script type="text/javascript" src="{{ asset('front-asset/js/banner.js') }}"></script> 
        </div>
        @show

    </body>
</html>