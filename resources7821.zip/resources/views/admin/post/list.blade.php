@extends('admin/layout/layout')
@section('page_title','Show All Post')
@section('post_right_in','in')
@section('container')
<!-- begin PAGE TITLE ROW -->
<div class="row">
    <div class="col-lg-12">
        <div class="page-title">
            <h1>@yield('page_title')
            </h1>
            <ol class="breadcrumb">
                <li><i class="fa fa-home"></i>  <a href="">Home</a></li>
                <li class="">Post</li>
                <li class="active">@yield('page_title')</li>
            </ol>
        </div>
    </div>
</div>
<!-- /.row -->
<!-- end PAGE TITLE ROW -->
<div class="row">
    <div class="col-lg-12">
    <p class="text-center text-red">{{session('msg')}}</p>
                        <div class="portlet portlet-default">
                            <div class="portlet-heading">
                                <div class="portlet-title">
                                    <h4> @yield('page_title')</h4>
                                </div>
                                <div class="clearfix"></div>
                            </div>
                            <div class="portlet-body">
                                <div class="table-responsive">
                                    <table id="example-table" class="table table-striped table-bordered table-hover table-green">
                                        <thead>
                                            <tr>
                                                <th>SR. No.</th>
                                                <th>Image</th>                                                
                                                <th>Category Name</th>
                                                <th>Name</th>
                                                <th>Title</th>
                                                <th>URL</th>
                                                <th>Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                       <?php $sr=1; ?>
                                        @foreach($result as $list)
                                            <tr>
                                                <td width="5%">{{$sr}}</td>
                                                <td width="10%">
                                                    <!-- <img src="{{env('WEB_SITE_STORAGE_IMAGE').'post/'.$list->image}}" width="60"> -->
                                                    <img src="{{env('AWS_BASEURL_IMAGE').'blog/post/'.$list->image}}" width="60">
                                                </td>
                                                <td>{{$list->cname}}</td>
                                                <td>{{$list->name}}</td>
                                                <td>{{$list->seo_title}}</td>
                                                <td>{{$list->seo_url}}</td>
                                                <td width="10%">
                                                    <a class="btn btn-warning btn-xs" href="{{url('admin/post/edit') }}/{{$list->id}}">Edit</a> | 
                                                    <a class="btn btn-danger btn-xs" href="{{url('admin/post/delete') }}/{{$list->id}}">Delete</a>
                                                </td>
                                            </tr>
                                       <?php $sr++; ?>
                                        @endforeach
                                        </tbody>
                                    </table>
                                </div>
                                <!-- /.table-responsive -->
                            </div>
                            <!-- /.portlet-body -->
                        </div>
                        <!-- /.portlet -->

                    </div>
</div>





@endsection