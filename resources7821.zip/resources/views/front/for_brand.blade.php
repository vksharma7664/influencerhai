@extends('layouts.app')
 
@section('title', $title)

@section('css')
    @parent
    
<link rel='stylesheet' id='elementor-post-2669-css' href="{{ asset('front-asset/css/post-2669e694.css?ver=1619288468') }}" type='text/css' media='all' />
@endsection
 
@section('content')
<div data-elementor-type="wp-page" data-elementor-id="2669" class="elementor elementor-2669" >
<div class="elementor-inner">
<div class="elementor-section-wrap">
<section class="elementor-section elementor-top-section elementor-element elementor-element-d958903 elementor-section-height-min-height elementor-section-boxed elementor-section-height-default elementor-section-items-middle" data-id="d958903" data-element_type="section" data-settings="{&quot;background_background&quot;:&quot;video&quot;}">
<div class="elementor-background-overlay"></div>
<div class="elementor-container elementor-column-gap-default">
<div class="elementor-row">
<div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-0b1fd25 animated-slow elementor-invisible" data-id="0b1fd25" data-element_type="column" data-settings="{&quot;background_background&quot;:&quot;classic&quot;,&quot;animation&quot;:&quot;fadeInUp&quot;}">
<div class="elementor-column-wrap elementor-element-populated">
<div class="elementor-widget-wrap">
<div class="elementor-element elementor-element-f4e9e24 elementor-widget elementor-widget-spacer" data-id="f4e9e24" data-element_type="widget" data-widget_type="spacer.default">
<div class="elementor-widget-container">
 <div class="elementor-spacer">
<div class="elementor-spacer-inner"></div>
</div>
</div>
</div>
<div class="elementor-element elementor-element-20dc83b elementor-widget elementor-widget-heading" data-id="20dc83b" data-element_type="widget" data-widget_type="heading.default">
<div class="elementor-widget-container">
<h2 class="elementor-heading-title elementor-size-default"><i>Influence the right <br>audience.</i></h2> </div>
</div>
<div class="elementor-element elementor-element-99bae69 elementor-widget elementor-widget-text-editor" data-id="99bae69" data-element_type="widget" data-widget_type="text-editor.default">
<div class="elementor-widget-container">
<div class="elementor-text-editor elementor-clearfix"><h4><em><strong>Run a campaign through our influencers</strong></em></h4><p> </p><h4 dir="auto"><em><strong>What are you looking for?</strong></em></h4></div>
</div>
</div>
<section class="elementor-section elementor-inner-section elementor-element elementor-element-8a1d738 elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="8a1d738" data-element_type="section">
<div class="elementor-container elementor-column-gap-default">
<div class="elementor-row">
<div class="elementor-column elementor-col-50 elementor-inner-column elementor-element elementor-element-c63bb01" data-id="c63bb01" data-element_type="column">
<div class="elementor-column-wrap elementor-element-populated">
<div class="elementor-widget-wrap">
<section class="elementor-section elementor-inner-section elementor-element elementor-element-ccc974a elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="ccc974a" data-element_type="section" data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
<div class="elementor-container elementor-column-gap-default">
<div class="elementor-row">
<div class="elementor-column elementor-col-100 elementor-inner-column elementor-element elementor-element-c0c4999" data-id="c0c4999" data-element_type="column">
<div class="elementor-column-wrap elementor-element-populated">
<div class="elementor-widget-wrap">
<div class="elementor-element elementor-element-19e7be2 elementor-widget elementor-widget-image" data-id="19e7be2" data-element_type="widget" data-widget_type="image.default">
<div class="elementor-widget-container">
<div class="elementor-image">
<img width="800" height="534" alt="" loading="lazy" data-srcset="https://letsinfluence.io/wp-content/uploads/2021/01/Influencer-marketing-1024x683.jpg 1024w, https://letsinfluence.io/wp-content/uploads/2021/01/Influencer-marketing-300x200.jpg 300w, https://letsinfluence.io/wp-content/uploads/2021/01/Influencer-marketing-768x512.jpg 768w" data-src="https://letsinfluence.io/wp-content/uploads/2021/01/Influencer-marketing-1024x683.jpg" data-sizes="(max-width: 800px) 100vw, 800px" class="attachment-large size-large lazyload" src="data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==" /><noscript><img width="800" height="534" src="../wp-content/uploads/2021/01/Influencer-marketing-1024x683.jpg" class="attachment-large size-large" alt="" loading="lazy" srcset="https://letsinfluence.io/wp-content/uploads/2021/01/Influencer-marketing-1024x683.jpg 1024w, https://letsinfluence.io/wp-content/uploads/2021/01/Influencer-marketing-300x200.jpg 300w, https://letsinfluence.io/wp-content/uploads/2021/01/Influencer-marketing-768x512.jpg 768w" sizes="(max-width: 800px) 100vw, 800px"/></noscript> </div>
</div>
</div>
<div class="elementor-element elementor-element-05723bb elementor-widget elementor-widget-text-editor" data-id="05723bb" data-element_type="widget" data-widget_type="text-editor.default">
<div class="elementor-widget-container">
<div class="elementor-text-editor elementor-clearfix"><p><em>Influencer Marketing</em></p></div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</section>
</div>
</div>
</div>
<div class="elementor-column elementor-col-50 elementor-inner-column elementor-element elementor-element-6ff243c" data-id="6ff243c" data-element_type="column">
<div class="elementor-column-wrap elementor-element-populated">
<div class="elementor-widget-wrap">
<section class="elementor-section elementor-inner-section elementor-element elementor-element-67fced0 elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="67fced0" data-element_type="section" data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
<div class="elementor-container elementor-column-gap-default">
<div class="elementor-row">
<div class="elementor-column elementor-col-100 elementor-inner-column elementor-element elementor-element-2273e25" data-id="2273e25" data-element_type="column">
<div class="elementor-column-wrap elementor-element-populated">
<div class="elementor-widget-wrap">
<div class="elementor-element elementor-element-905a7da elementor-widget elementor-widget-image" data-id="905a7da" data-element_type="widget" data-widget_type="image.default">
<div class="elementor-widget-container">
<div class="elementor-image">
<img width="800" height="534" alt="" loading="lazy" data-srcset="https://letsinfluence.io/wp-content/uploads/2021/01/Celebrity-endorsement-1024x683.jpg 1024w, https://letsinfluence.io/wp-content/uploads/2021/01/Celebrity-endorsement-300x200.jpg 300w, https://letsinfluence.io/wp-content/uploads/2021/01/Celebrity-endorsement-768x512.jpg 768w" data-src="https://letsinfluence.io/wp-content/uploads/2021/01/Celebrity-endorsement-1024x683.jpg" data-sizes="(max-width: 800px) 100vw, 800px" class="attachment-large size-large lazyload" src="data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==" /><noscript><img width="800" height="534" src="../wp-content/uploads/2021/01/Celebrity-endorsement-1024x683.jpg" class="attachment-large size-large" alt="" loading="lazy" srcset="https://letsinfluence.io/wp-content/uploads/2021/01/Celebrity-endorsement-1024x683.jpg 1024w, https://letsinfluence.io/wp-content/uploads/2021/01/Celebrity-endorsement-300x200.jpg 300w, https://letsinfluence.io/wp-content/uploads/2021/01/Celebrity-endorsement-768x512.jpg 768w" sizes="(max-width: 800px) 100vw, 800px"/></noscript> </div>
</div>
</div>
<div class="elementor-element elementor-element-a59a222 elementor-widget elementor-widget-text-editor" data-id="a59a222" data-element_type="widget" data-widget_type="text-editor.default">
<div class="elementor-widget-container">
<div class="elementor-text-editor elementor-clearfix"><p><em>Celebrity Endorsements</em></p></div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</section>
</div>
</div>
</div>
</div>
</div>
</section>
<section class="elementor-section elementor-inner-section elementor-element elementor-element-fef2f78 elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="fef2f78" data-element_type="section">
<div class="elementor-container elementor-column-gap-default">
<div class="elementor-row">
<div class="elementor-column elementor-col-50 elementor-inner-column elementor-element elementor-element-c9fa423" data-id="c9fa423" data-element_type="column">
<div class="elementor-column-wrap elementor-element-populated">
<div class="elementor-widget-wrap">
<section class="elementor-section elementor-inner-section elementor-element elementor-element-c3046de elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="c3046de" data-element_type="section" data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
<div class="elementor-container elementor-column-gap-default">
<div class="elementor-row">
<div class="elementor-column elementor-col-100 elementor-inner-column elementor-element elementor-element-1cf0a62" data-id="1cf0a62" data-element_type="column">
<div class="elementor-column-wrap elementor-element-populated">
<div class="elementor-widget-wrap">
<div class="elementor-element elementor-element-22a771f elementor-widget elementor-widget-image" data-id="22a771f" data-element_type="widget" data-widget_type="image.default">
<div class="elementor-widget-container">
<div class="elementor-image">
<img width="800" height="534" alt="" loading="lazy" data-srcset="https://letsinfluence.io/wp-content/uploads/2021/01/Movie_webseries-integration-1024x683.jpg 1024w, https://letsinfluence.io/wp-content/uploads/2021/01/Movie_webseries-integration-300x200.jpg 300w, https://letsinfluence.io/wp-content/uploads/2021/01/Movie_webseries-integration-768x512.jpg 768w" data-src="https://letsinfluence.io/wp-content/uploads/2021/01/Movie_webseries-integration-1024x683.jpg" data-sizes="(max-width: 800px) 100vw, 800px" class="attachment-large size-large lazyload" src="data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==" /><noscript><img width="800" height="534" src="../wp-content/uploads/2021/01/Movie_webseries-integration-1024x683.jpg" class="attachment-large size-large" alt="" loading="lazy" srcset="https://letsinfluence.io/wp-content/uploads/2021/01/Movie_webseries-integration-1024x683.jpg 1024w, https://letsinfluence.io/wp-content/uploads/2021/01/Movie_webseries-integration-300x200.jpg 300w, https://letsinfluence.io/wp-content/uploads/2021/01/Movie_webseries-integration-768x512.jpg 768w" sizes="(max-width: 800px) 100vw, 800px"/></noscript> </div>
</div>
</div>
<div class="elementor-element elementor-element-596ac2c elementor-widget elementor-widget-text-editor" data-id="596ac2c" data-element_type="widget" data-widget_type="text-editor.default">
<div class="elementor-widget-container">
<div class="elementor-text-editor elementor-clearfix"><p><em>Movie/Web-series Integration</em></p></div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</section>
</div>
</div>
</div>
<div class="elementor-column elementor-col-50 elementor-inner-column elementor-element elementor-element-4127b87" data-id="4127b87" data-element_type="column">
<div class="elementor-column-wrap elementor-element-populated">
<div class="elementor-widget-wrap">
<section class="elementor-section elementor-inner-section elementor-element elementor-element-3728de5 elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="3728de5" data-element_type="section" data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
<div class="elementor-container elementor-column-gap-default">
<div class="elementor-row">
<div class="elementor-column elementor-col-100 elementor-inner-column elementor-element elementor-element-1d2c90d" data-id="1d2c90d" data-element_type="column">
<div class="elementor-column-wrap elementor-element-populated">
<div class="elementor-widget-wrap">
<div class="elementor-element elementor-element-6da0460 elementor-widget elementor-widget-image" data-id="6da0460" data-element_type="widget" data-widget_type="image.default">
<div class="elementor-widget-container">
<div class="elementor-image">
<img width="800" height="534" alt="" loading="lazy" data-srcset="https://letsinfluence.io/wp-content/uploads/2021/01/Meme-marketing-1024x683.jpg 1024w, https://letsinfluence.io/wp-content/uploads/2021/01/Meme-marketing-300x200.jpg 300w, https://letsinfluence.io/wp-content/uploads/2021/01/Meme-marketing-768x512.jpg 768w" data-src="https://letsinfluence.io/wp-content/uploads/2021/01/Meme-marketing-1024x683.jpg" data-sizes="(max-width: 800px) 100vw, 800px" class="attachment-large size-large lazyload" src="data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==" /><noscript><img width="800" height="534" src="../wp-content/uploads/2021/01/Meme-marketing-1024x683.jpg" class="attachment-large size-large" alt="" loading="lazy" srcset="https://letsinfluence.io/wp-content/uploads/2021/01/Meme-marketing-1024x683.jpg 1024w, https://letsinfluence.io/wp-content/uploads/2021/01/Meme-marketing-300x200.jpg 300w, https://letsinfluence.io/wp-content/uploads/2021/01/Meme-marketing-768x512.jpg 768w" sizes="(max-width: 800px) 100vw, 800px"/></noscript> </div>
</div>
</div>
<div class="elementor-element elementor-element-824b622 elementor-widget elementor-widget-text-editor" data-id="824b622" data-element_type="widget" data-widget_type="text-editor.default">
<div class="elementor-widget-container">
<div class="elementor-text-editor elementor-clearfix"><p><em>Meme Marketing</em></p></div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</section>
</div>
</div>
</div>
</div>
</div>
</section>
<section class="elementor-section elementor-inner-section elementor-element elementor-element-88e6f68 elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="88e6f68" data-element_type="section">
<div class="elementor-container elementor-column-gap-default">
<div class="elementor-row">
<div class="elementor-column elementor-col-50 elementor-inner-column elementor-element elementor-element-d1d5fe6" data-id="d1d5fe6" data-element_type="column">
<div class="elementor-column-wrap elementor-element-populated">
<div class="elementor-widget-wrap">
<section class="elementor-section elementor-inner-section elementor-element elementor-element-5663801 elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="5663801" data-element_type="section" data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
<div class="elementor-container elementor-column-gap-default">
<div class="elementor-row">
<div class="elementor-column elementor-col-100 elementor-inner-column elementor-element elementor-element-3b92db7" data-id="3b92db7" data-element_type="column">
<div class="elementor-column-wrap elementor-element-populated">
<div class="elementor-widget-wrap">
<div class="elementor-element elementor-element-4ce0504 elementor-widget elementor-widget-image" data-id="4ce0504" data-element_type="widget" data-widget_type="image.default">
<div class="elementor-widget-container">
<div class="elementor-image">
<img width="800" height="534" alt="" loading="lazy" data-srcset="https://letsinfluence.io/wp-content/uploads/2021/01/Live-celebrity-sessions-1024x683.jpg 1024w, https://letsinfluence.io/wp-content/uploads/2021/01/Live-celebrity-sessions-300x200.jpg 300w, https://letsinfluence.io/wp-content/uploads/2021/01/Live-celebrity-sessions-768x513.jpg 768w" data-src="https://letsinfluence.io/wp-content/uploads/2021/01/Live-celebrity-sessions-1024x683.jpg" data-sizes="(max-width: 800px) 100vw, 800px" class="attachment-large size-large lazyload" src="data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==" /><noscript><img width="800" height="534" src="../wp-content/uploads/2021/01/Live-celebrity-sessions-1024x683.jpg" class="attachment-large size-large" alt="" loading="lazy" srcset="https://letsinfluence.io/wp-content/uploads/2021/01/Live-celebrity-sessions-1024x683.jpg 1024w, https://letsinfluence.io/wp-content/uploads/2021/01/Live-celebrity-sessions-300x200.jpg 300w, https://letsinfluence.io/wp-content/uploads/2021/01/Live-celebrity-sessions-768x513.jpg 768w" sizes="(max-width: 800px) 100vw, 800px"/></noscript> </div>
</div>
</div>
<div class="elementor-element elementor-element-b71f058 elementor-widget elementor-widget-text-editor" data-id="b71f058" data-element_type="widget" data-widget_type="text-editor.default">
<div class="elementor-widget-container">
<div class="elementor-text-editor elementor-clearfix"><p><em>Live Celebrity Sessions</em></p></div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</section>
</div>
</div>
</div>
<div class="elementor-column elementor-col-50 elementor-inner-column elementor-element elementor-element-dfd8c44" data-id="dfd8c44" data-element_type="column">
<div class="elementor-column-wrap elementor-element-populated">
<div class="elementor-widget-wrap">
<section class="elementor-section elementor-inner-section elementor-element elementor-element-d51c537 elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="d51c537" data-element_type="section" data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
<div class="elementor-container elementor-column-gap-default">
<div class="elementor-row">
<div class="elementor-column elementor-col-100 elementor-inner-column elementor-element elementor-element-ce37cb8" data-id="ce37cb8" data-element_type="column">
<div class="elementor-column-wrap elementor-element-populated">
<div class="elementor-widget-wrap">
<div class="elementor-element elementor-element-0e75c62 elementor-widget elementor-widget-image" data-id="0e75c62" data-element_type="widget" data-widget_type="image.default">
<div class="elementor-widget-container">
<div class="elementor-image">
<img width="800" height="523" alt="" loading="lazy" data-srcset="https://letsinfluence.io/wp-content/uploads/2021/01/comedy-show_Music-concertsjghgu-1024x669.jpg 1024w, https://letsinfluence.io/wp-content/uploads/2021/01/comedy-show_Music-concertsjghgu-300x196.jpg 300w, https://letsinfluence.io/wp-content/uploads/2021/01/comedy-show_Music-concertsjghgu-768x502.jpg 768w, https://letsinfluence.io/wp-content/uploads/2021/01/comedy-show_Music-concertsjghgu-1536x1004.jpg 1536w, https://letsinfluence.io/wp-content/uploads/2021/01/comedy-show_Music-concertsjghgu-2048x1338.jpg 2048w" data-src="https://letsinfluence.io/wp-content/uploads/2021/01/comedy-show_Music-concertsjghgu-1024x669.jpg" data-sizes="(max-width: 800px) 100vw, 800px" class="attachment-large size-large lazyload" src="data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==" /><noscript><img width="800" height="523" src="../wp-content/uploads/2021/01/comedy-show_Music-concertsjghgu-1024x669.jpg" class="attachment-large size-large" alt="" loading="lazy" srcset="https://letsinfluence.io/wp-content/uploads/2021/01/comedy-show_Music-concertsjghgu-1024x669.jpg 1024w, https://letsinfluence.io/wp-content/uploads/2021/01/comedy-show_Music-concertsjghgu-300x196.jpg 300w, https://letsinfluence.io/wp-content/uploads/2021/01/comedy-show_Music-concertsjghgu-768x502.jpg 768w, https://letsinfluence.io/wp-content/uploads/2021/01/comedy-show_Music-concertsjghgu-1536x1004.jpg 1536w, https://letsinfluence.io/wp-content/uploads/2021/01/comedy-show_Music-concertsjghgu-2048x1338.jpg 2048w" sizes="(max-width: 800px) 100vw, 800px"/></noscript> </div>
</div>
</div>
<div class="elementor-element elementor-element-15f8ffa elementor-widget elementor-widget-text-editor" data-id="15f8ffa" data-element_type="widget" data-widget_type="text-editor.default">
<div class="elementor-widget-container">
<div class="elementor-text-editor elementor-clearfix"><p><em>Comedy Shows / Music Concerts</em></p></div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</section>
</div>
</div>
</div>
</div>
</div>
</section>
<div class="elementor-element elementor-element-ffad085 elementor-widget elementor-widget-text-editor" data-id="ffad085" data-element_type="widget" data-widget_type="text-editor.default">
<div class="elementor-widget-container">
<div class="elementor-text-editor elementor-clearfix"><h3 dir="auto"><em><strong>Brands trusted us</strong></em></h3></div>
</div>
</div>
<div class="elementor-element elementor-element-5fdef0c elementor-widget elementor-widget-gallery" data-id="5fdef0c" data-element_type="widget" data-settings="{&quot;columns&quot;:7,&quot;columns_mobile&quot;:2,&quot;gap&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:20,&quot;sizes&quot;:[]},&quot;aspect_ratio&quot;:&quot;1:1&quot;,&quot;lazyload&quot;:&quot;yes&quot;,&quot;gallery_layout&quot;:&quot;grid&quot;,&quot;columns_tablet&quot;:2,&quot;gap_tablet&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:10,&quot;sizes&quot;:[]},&quot;gap_mobile&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:10,&quot;sizes&quot;:[]},&quot;link_to&quot;:&quot;file&quot;,&quot;content_hover_animation&quot;:&quot;fade-in&quot;}" data-widget_type="gallery.default">
<div class="elementor-widget-container">
<div class="elementor-gallery__container">
<a class="e-gallery-item elementor-gallery-item elementor-animated-content" href="../wp-content/uploads/2020/12/Titan-1.png" data-elementor-open-lightbox="yes" data-elementor-lightbox-slideshow="all-5fdef0c" data-elementor-lightbox-title="Titan" data-wpel-link="internal">
<div class="e-gallery-image elementor-gallery-item__image" data-thumbnail="https://letsinfluence.io/wp-content/uploads/2020/12/Titan-1.png" data-width="300" data-height="300" alt=""></div>
</a>
<a class="e-gallery-item elementor-gallery-item elementor-animated-content" href="../wp-content/uploads/2020/12/snapdeal-1.png" data-elementor-open-lightbox="yes" data-elementor-lightbox-slideshow="all-5fdef0c" data-elementor-lightbox-title="snapdeal" data-wpel-link="internal">
<div class="e-gallery-image elementor-gallery-item__image" data-thumbnail="https://letsinfluence.io/wp-content/uploads/2020/12/snapdeal-1.png" data-width="300" data-height="300" alt=""></div>
</a>
<a class="e-gallery-item elementor-gallery-item elementor-animated-content" href="../wp-content/uploads/2020/12/bOAt-1.png" data-elementor-open-lightbox="yes" data-elementor-lightbox-slideshow="all-5fdef0c" data-elementor-lightbox-title="bOAt" data-wpel-link="internal">
<div class="e-gallery-image elementor-gallery-item__image" data-thumbnail="https://letsinfluence.io/wp-content/uploads/2020/12/bOAt-1.png" data-width="300" data-height="300" alt=""></div>
</a>
<a class="e-gallery-item elementor-gallery-item elementor-animated-content" href="../wp-content/uploads/2020/12/MPL-1.png" data-elementor-open-lightbox="yes" data-elementor-lightbox-slideshow="all-5fdef0c" data-elementor-lightbox-title="MPL" data-wpel-link="internal">
<div class="e-gallery-image elementor-gallery-item__image" data-thumbnail="https://letsinfluence.io/wp-content/uploads/2020/12/MPL-1.png" data-width="300" data-height="300" alt=""></div>
</a>
<a class="e-gallery-item elementor-gallery-item elementor-animated-content" href="../wp-content/uploads/2020/12/emami-1.png" data-elementor-open-lightbox="yes" data-elementor-lightbox-slideshow="all-5fdef0c" data-elementor-lightbox-title="emami" data-wpel-link="internal">
<div class="e-gallery-image elementor-gallery-item__image" data-thumbnail="https://letsinfluence.io/wp-content/uploads/2020/12/emami-1.png" data-width="300" data-height="300" alt=""></div>
</a>
<a class="e-gallery-item elementor-gallery-item elementor-animated-content" href="../wp-content/uploads/2020/12/COSCO-1.png" data-elementor-open-lightbox="yes" data-elementor-lightbox-slideshow="all-5fdef0c" data-elementor-lightbox-title="COSCO" data-wpel-link="internal">
<div class="e-gallery-image elementor-gallery-item__image" data-thumbnail="https://letsinfluence.io/wp-content/uploads/2020/12/COSCO-1.png" data-width="300" data-height="300" alt=""></div>
</a>
<a class="e-gallery-item elementor-gallery-item elementor-animated-content" href="../wp-content/uploads/2021/01/download.jpg" data-elementor-open-lightbox="yes" data-elementor-lightbox-slideshow="all-5fdef0c" data-elementor-lightbox-title="download" data-wpel-link="internal">
<div class="e-gallery-image elementor-gallery-item__image" data-thumbnail="https://letsinfluence.io/wp-content/uploads/2021/01/download.jpg" data-width="225" data-height="225" alt=""></div>
</a>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</section>
<section class="elementor-section elementor-top-section elementor-element elementor-element-8352c1f elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="8352c1f" data-element_type="section">
<div class="elementor-container elementor-column-gap-default">
<div class="elementor-row">
<div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-6363a47" data-id="6363a47" data-element_type="column">
<div class="elementor-column-wrap elementor-element-populated">
<div class="elementor-widget-wrap">
<div class="elementor-element elementor-element-9a39daf elementor-widget elementor-widget-text-editor" data-id="9a39daf" data-element_type="widget" data-widget_type="text-editor.default">
<div class="elementor-widget-container">
<div class="elementor-text-editor elementor-clearfix"><h3><span style="color: #000000;"><em><strong>Platforms we work on</strong></em></span></h3></div>
</div>
</div>
<section class="elementor-section elementor-inner-section elementor-element elementor-element-649bdf3 elementor-section-boxed elementor-section-height-default elementor-section-height-default elementor-invisible" data-id="649bdf3" data-element_type="section" data-settings="{&quot;animation&quot;:&quot;fadeInUp&quot;}">
<div class="elementor-container elementor-column-gap-default">
<div class="elementor-row">
<div class="elementor-column elementor-col-14 elementor-inner-column elementor-element elementor-element-9e8f32c" data-id="9e8f32c" data-element_type="column" data-settings="{&quot;animation&quot;:&quot;none&quot;}">
<div class="elementor-column-wrap elementor-element-populated">
<div class="elementor-widget-wrap">
<div class="elementor-element elementor-element-c4d7967 elementor-position-top elementor-vertical-align-top elementor-widget elementor-widget-image-box" data-id="c4d7967" data-element_type="widget" data-settings="{&quot;_animation&quot;:&quot;none&quot;}" data-widget_type="image-box.default">
<div class="elementor-widget-container">
<div class="elementor-image-box-wrapper"><figure class="elementor-image-box-img"><img width="600" height="600" alt="" loading="lazy" data-srcset="https://letsinfluence.io/wp-content/uploads/2021/01/Facebook.png 600w, https://letsinfluence.io/wp-content/uploads/2021/01/Facebook-150x150.png 150w, https://letsinfluence.io/wp-content/uploads/2021/01/Facebook-300x300.png 300w, https://letsinfluence.io/wp-content/uploads/2021/01/Facebook-100x100.png 100w" data-src="https://letsinfluence.io/wp-content/uploads/2021/01/Facebook.png" data-sizes="(max-width: 600px) 100vw, 600px" class="attachment-full size-full lazyload" src="data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==" /><noscript><img width="600" height="600" src="../wp-content/uploads/2021/01/Facebook.png" class="attachment-full size-full" alt="" loading="lazy" srcset="https://letsinfluence.io/wp-content/uploads/2021/01/Facebook.png 600w, https://letsinfluence.io/wp-content/uploads/2021/01/Facebook-150x150.png 150w, https://letsinfluence.io/wp-content/uploads/2021/01/Facebook-300x300.png 300w, https://letsinfluence.io/wp-content/uploads/2021/01/Facebook-100x100.png 100w" sizes="(max-width: 600px) 100vw, 600px"/></noscript></figure><div class="elementor-image-box-content"><p class="elementor-image-box-description">Facebook</p></div></div> </div>
</div>
</div>
</div>
</div>
<div class="elementor-column elementor-col-14 elementor-inner-column elementor-element elementor-element-8e50dda" data-id="8e50dda" data-element_type="column">
<div class="elementor-column-wrap elementor-element-populated">
<div class="elementor-widget-wrap">
<div class="elementor-element elementor-element-2de14ac elementor-position-top elementor-vertical-align-top elementor-widget elementor-widget-image-box" data-id="2de14ac" data-element_type="widget" data-settings="{&quot;_animation&quot;:&quot;none&quot;}" data-widget_type="image-box.default">
<div class="elementor-widget-container">
<div class="elementor-image-box-wrapper"><figure class="elementor-image-box-img"><img width="600" height="600" alt="" loading="lazy" data-srcset="https://letsinfluence.io/wp-content/uploads/2021/01/tw.png 600w, https://letsinfluence.io/wp-content/uploads/2021/01/tw-150x150.png 150w, https://letsinfluence.io/wp-content/uploads/2021/01/tw-300x300.png 300w, https://letsinfluence.io/wp-content/uploads/2021/01/tw-100x100.png 100w" data-src="https://letsinfluence.io/wp-content/uploads/2021/01/tw.png" data-sizes="(max-width: 600px) 100vw, 600px" class="attachment-full size-full lazyload" src="data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==" /><noscript><img width="600" height="600" src="../wp-content/uploads/2021/01/tw.png" class="attachment-full size-full" alt="" loading="lazy" srcset="https://letsinfluence.io/wp-content/uploads/2021/01/tw.png 600w, https://letsinfluence.io/wp-content/uploads/2021/01/tw-150x150.png 150w, https://letsinfluence.io/wp-content/uploads/2021/01/tw-300x300.png 300w, https://letsinfluence.io/wp-content/uploads/2021/01/tw-100x100.png 100w" sizes="(max-width: 600px) 100vw, 600px"/></noscript></figure><div class="elementor-image-box-content"><p class="elementor-image-box-description">Twitter</p></div></div> </div>
</div>
</div>
</div>
</div>
<div class="elementor-column elementor-col-14 elementor-inner-column elementor-element elementor-element-c4e1b2c" data-id="c4e1b2c" data-element_type="column">
<div class="elementor-column-wrap elementor-element-populated">
<div class="elementor-widget-wrap">
<div class="elementor-element elementor-element-bf7e06a elementor-position-top elementor-vertical-align-top elementor-widget elementor-widget-image-box" data-id="bf7e06a" data-element_type="widget" data-settings="{&quot;_animation&quot;:&quot;none&quot;}" data-widget_type="image-box.default">
<div class="elementor-widget-container">
<div class="elementor-image-box-wrapper"><figure class="elementor-image-box-img"><img width="600" height="600" alt="" loading="lazy" data-srcset="https://letsinfluence.io/wp-content/uploads/2021/01/li.png 600w, https://letsinfluence.io/wp-content/uploads/2021/01/li-150x150.png 150w, https://letsinfluence.io/wp-content/uploads/2021/01/li-300x300.png 300w, https://letsinfluence.io/wp-content/uploads/2021/01/li-100x100.png 100w" data-src="https://letsinfluence.io/wp-content/uploads/2021/01/li.png" data-sizes="(max-width: 600px) 100vw, 600px" class="attachment-full size-full lazyload" src="data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==" /><noscript><img width="600" height="600" src="../wp-content/uploads/2021/01/li.png" class="attachment-full size-full" alt="" loading="lazy" srcset="https://letsinfluence.io/wp-content/uploads/2021/01/li.png 600w, https://letsinfluence.io/wp-content/uploads/2021/01/li-150x150.png 150w, https://letsinfluence.io/wp-content/uploads/2021/01/li-300x300.png 300w, https://letsinfluence.io/wp-content/uploads/2021/01/li-100x100.png 100w" sizes="(max-width: 600px) 100vw, 600px"/></noscript></figure><div class="elementor-image-box-content"><p class="elementor-image-box-description">LinkdIn</p></div></div> </div>
</div>
</div>
</div>
</div>
<div class="elementor-column elementor-col-14 elementor-inner-column elementor-element elementor-element-aba0d7a" data-id="aba0d7a" data-element_type="column">
<div class="elementor-column-wrap elementor-element-populated">
<div class="elementor-widget-wrap">
<div class="elementor-element elementor-element-f576c7c elementor-position-top elementor-vertical-align-top elementor-widget elementor-widget-image-box" data-id="f576c7c" data-element_type="widget" data-settings="{&quot;_animation&quot;:&quot;none&quot;}" data-widget_type="image-box.default">
<div class="elementor-widget-container">
<div class="elementor-image-box-wrapper"><figure class="elementor-image-box-img"><img width="600" height="600" alt="" loading="lazy" data-srcset="https://letsinfluence.io/wp-content/uploads/2021/01/tele.png 600w, https://letsinfluence.io/wp-content/uploads/2021/01/tele-150x150.png 150w, https://letsinfluence.io/wp-content/uploads/2021/01/tele-300x300.png 300w, https://letsinfluence.io/wp-content/uploads/2021/01/tele-100x100.png 100w" data-src="https://letsinfluence.io/wp-content/uploads/2021/01/tele.png" data-sizes="(max-width: 600px) 100vw, 600px" class="attachment-full size-full lazyload" src="data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==" /><noscript><img width="600" height="600" src="../wp-content/uploads/2021/01/tele.png" class="attachment-full size-full" alt="" loading="lazy" srcset="https://letsinfluence.io/wp-content/uploads/2021/01/tele.png 600w, https://letsinfluence.io/wp-content/uploads/2021/01/tele-150x150.png 150w, https://letsinfluence.io/wp-content/uploads/2021/01/tele-300x300.png 300w, https://letsinfluence.io/wp-content/uploads/2021/01/tele-100x100.png 100w" sizes="(max-width: 600px) 100vw, 600px"/></noscript></figure><div class="elementor-image-box-content"><p class="elementor-image-box-description">Telegram</p></div></div> </div>
</div>
</div>
</div>
</div>
<div class="elementor-column elementor-col-14 elementor-inner-column elementor-element elementor-element-41f7a83" data-id="41f7a83" data-element_type="column">
<div class="elementor-column-wrap elementor-element-populated">
<div class="elementor-widget-wrap">
<div class="elementor-element elementor-element-9fa6a05 elementor-position-top elementor-vertical-align-top elementor-widget elementor-widget-image-box" data-id="9fa6a05" data-element_type="widget" data-settings="{&quot;_animation&quot;:&quot;none&quot;}" data-widget_type="image-box.default">
<div class="elementor-widget-container">
<div class="elementor-image-box-wrapper"><figure class="elementor-image-box-img"><img width="600" height="600" alt="" loading="lazy" data-srcset="https://letsinfluence.io/wp-content/uploads/2021/01/inst.png 600w, https://letsinfluence.io/wp-content/uploads/2021/01/inst-150x150.png 150w, https://letsinfluence.io/wp-content/uploads/2021/01/inst-300x300.png 300w, https://letsinfluence.io/wp-content/uploads/2021/01/inst-100x100.png 100w" data-src="https://letsinfluence.io/wp-content/uploads/2021/01/inst.png" data-sizes="(max-width: 600px) 100vw, 600px" class="attachment-full size-full lazyload" src="data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==" /><noscript><img width="600" height="600" src="../wp-content/uploads/2021/01/inst.png" class="attachment-full size-full" alt="" loading="lazy" srcset="https://letsinfluence.io/wp-content/uploads/2021/01/inst.png 600w, https://letsinfluence.io/wp-content/uploads/2021/01/inst-150x150.png 150w, https://letsinfluence.io/wp-content/uploads/2021/01/inst-300x300.png 300w, https://letsinfluence.io/wp-content/uploads/2021/01/inst-100x100.png 100w" sizes="(max-width: 600px) 100vw, 600px"/></noscript></figure><div class="elementor-image-box-content"><p class="elementor-image-box-description">Instagram</p></div></div> </div>
</div>
</div>
</div>
</div>
<div class="elementor-column elementor-col-14 elementor-inner-column elementor-element elementor-element-fa17284" data-id="fa17284" data-element_type="column">
<div class="elementor-column-wrap elementor-element-populated">
<div class="elementor-widget-wrap">
<div class="elementor-element elementor-element-e4247b0 elementor-position-top elementor-vertical-align-top elementor-widget elementor-widget-image-box" data-id="e4247b0" data-element_type="widget" data-settings="{&quot;_animation&quot;:&quot;none&quot;}" data-widget_type="image-box.default">
<div class="elementor-widget-container">
<div class="elementor-image-box-wrapper"><figure class="elementor-image-box-img"><img width="600" height="600" alt="" loading="lazy" data-srcset="https://letsinfluence.io/wp-content/uploads/2021/01/yt.png 600w, https://letsinfluence.io/wp-content/uploads/2021/01/yt-150x150.png 150w, https://letsinfluence.io/wp-content/uploads/2021/01/yt-300x300.png 300w, https://letsinfluence.io/wp-content/uploads/2021/01/yt-100x100.png 100w" data-src="https://letsinfluence.io/wp-content/uploads/2021/01/yt.png" data-sizes="(max-width: 600px) 100vw, 600px" class="attachment-full size-full lazyload" src="data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==" /><noscript><img width="600" height="600" src="../wp-content/uploads/2021/01/yt.png" class="attachment-full size-full" alt="" loading="lazy" srcset="https://letsinfluence.io/wp-content/uploads/2021/01/yt.png 600w, https://letsinfluence.io/wp-content/uploads/2021/01/yt-150x150.png 150w, https://letsinfluence.io/wp-content/uploads/2021/01/yt-300x300.png 300w, https://letsinfluence.io/wp-content/uploads/2021/01/yt-100x100.png 100w" sizes="(max-width: 600px) 100vw, 600px"/></noscript></figure><div class="elementor-image-box-content"><p class="elementor-image-box-description">Youtube</p></div></div> </div>
</div>
</div>
</div>
</div>
<div class="elementor-column elementor-col-14 elementor-inner-column elementor-element elementor-element-91b2071" data-id="91b2071" data-element_type="column">
<div class="elementor-column-wrap elementor-element-populated">
<div class="elementor-widget-wrap">
<div class="elementor-element elementor-element-56d5a04 elementor-position-top elementor-vertical-align-top elementor-widget elementor-widget-image-box" data-id="56d5a04" data-element_type="widget" data-settings="{&quot;_animation&quot;:&quot;none&quot;}" data-widget_type="image-box.default">
<div class="elementor-widget-container">
<div class="elementor-image-box-wrapper"><figure class="elementor-image-box-img"><img width="600" height="600" alt="" loading="lazy" data-srcset="https://letsinfluence.io/wp-content/uploads/2021/01/tik.png 600w, https://letsinfluence.io/wp-content/uploads/2021/01/tik-150x150.png 150w, https://letsinfluence.io/wp-content/uploads/2021/01/tik-300x300.png 300w, https://letsinfluence.io/wp-content/uploads/2021/01/tik-100x100.png 100w" data-src="https://letsinfluence.io/wp-content/uploads/2021/01/tik.png" data-sizes="(max-width: 600px) 100vw, 600px" class="attachment-full size-full lazyload" src="data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==" /><noscript><img width="600" height="600" src="../wp-content/uploads/2021/01/tik.png" class="attachment-full size-full" alt="" loading="lazy" srcset="https://letsinfluence.io/wp-content/uploads/2021/01/tik.png 600w, https://letsinfluence.io/wp-content/uploads/2021/01/tik-150x150.png 150w, https://letsinfluence.io/wp-content/uploads/2021/01/tik-300x300.png 300w, https://letsinfluence.io/wp-content/uploads/2021/01/tik-100x100.png 100w" sizes="(max-width: 600px) 100vw, 600px"/></noscript></figure><div class="elementor-image-box-content"><p class="elementor-image-box-description">Tiktok</p></div></div> </div>
</div>
</div>
</div>
</div>
</div>
</div>
</section>
</div>
</div>
</div>
</div>
</div>
</section>
<section class="elementor-section elementor-top-section elementor-element elementor-element-8660e87 elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="8660e87" data-element_type="section">
<div class="elementor-container elementor-column-gap-default">
<div class="elementor-row">
<div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-45f1f94" data-id="45f1f94" data-element_type="column">
<div class="elementor-column-wrap elementor-element-populated">
<div class="elementor-widget-wrap">
<div class="elementor-element elementor-element-e1bab54 elementor-widget elementor-widget-image" data-id="e1bab54" data-element_type="widget" data-widget_type="image.default">
<div class="elementor-widget-container">
<div class="elementor-image">
<img width="800" height="136" alt="" loading="lazy" data-srcset="https://letsinfluence.io/wp-content/uploads/2019/09/logotop-1024x174.png 1024w, https://letsinfluence.io/wp-content/uploads/2019/09/logotop-300x51.png 300w, https://letsinfluence.io/wp-content/uploads/2019/09/logotop-768x131.png 768w, https://letsinfluence.io/wp-content/uploads/2019/09/logotop.png 1229w" data-src="https://letsinfluence.io/wp-content/uploads/2019/09/logotop-1024x174.png" data-sizes="(max-width: 800px) 100vw, 800px" class="attachment-large size-large lazyload" src="data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==" /><noscript><img width="800" height="136" src="../wp-content/uploads/2019/09/logotop-1024x174.png" class="attachment-large size-large" alt="" loading="lazy" srcset="https://letsinfluence.io/wp-content/uploads/2019/09/logotop-1024x174.png 1024w, https://letsinfluence.io/wp-content/uploads/2019/09/logotop-300x51.png 300w, https://letsinfluence.io/wp-content/uploads/2019/09/logotop-768x131.png 768w, https://letsinfluence.io/wp-content/uploads/2019/09/logotop.png 1229w" sizes="(max-width: 800px) 100vw, 800px"/></noscript> </div>
</div>
</div>
<div class="elementor-element elementor-element-2efbf64 elementor-widget elementor-widget-heading" data-id="2efbf64" data-element_type="widget" data-widget_type="heading.default">
<div class="elementor-widget-container">
<h2 class="elementor-heading-title elementor-size-default">Please help us with your contact details</h2> </div>
</div>
<div class="elementor-element elementor-element-0bf7167 elementor-widget elementor-widget-spacer" data-id="0bf7167" data-element_type="widget" data-widget_type="spacer.default">
<div class="elementor-widget-container">
<div class="elementor-spacer">
<div class="elementor-spacer-inner"></div>
</div>
</div>
</div>
<div class="elementor-element elementor-element-7405f4a elementor-button-align-stretch elementor-widget elementor-widget-form" data-id="7405f4a" data-element_type="widget" data-settings="{&quot;step_next_label&quot;:&quot;Next&quot;,&quot;step_previous_label&quot;:&quot;Previous&quot;,&quot;button_width&quot;:&quot;100&quot;,&quot;step_type&quot;:&quot;number_text&quot;,&quot;step_icon_shape&quot;:&quot;circle&quot;}" data-widget_type="form.default">
<div class="elementor-widget-container">
<form class="elementor-form" method="post" name="New Form">
<input type="hidden" name="post_id" value="2669" />
<input type="hidden" name="form_id" value="7405f4a" />
<input type="hidden" name="queried_id" value="2669" />
<div class="elementor-form-fields-wrapper elementor-labels-above">
<div class="elementor-field-type-text elementor-field-group elementor-column elementor-field-group-name elementor-col-100 elementor-field-required">
<input size="1" type="text" name="form_fields[name]" id="form-field-name" class="elementor-field elementor-size-sm  elementor-field-textual" placeholder="Brand Name" required="required" aria-required="true"> </div>
<div class="elementor-field-type-text elementor-field-group elementor-column elementor-field-group-field_2 elementor-col-100 elementor-field-required">
<input size="1" type="text" name="form_fields[field_2]" id="form-field-field_2" class="elementor-field elementor-size-sm  elementor-field-textual" placeholder="Name" required="required" aria-required="true"> </div>
<div class="elementor-field-type-email elementor-field-group elementor-column elementor-field-group-field_6 elementor-col-100">
<input size="1" type="email" name="form_fields[field_6]" id="form-field-field_6" class="elementor-field elementor-size-sm  elementor-field-textual" placeholder="Email Id"> </div>
<div class="elementor-field-type-number elementor-field-group elementor-column elementor-field-group-email elementor-col-100 elementor-field-required">
<input type="number" name="form_fields[email]" id="form-field-email" class="elementor-field elementor-size-sm  elementor-field-textual" placeholder="Phone Number" required="required" aria-required="true" min="" max=""> </div>
<div class="elementor-field-type-text elementor-field-group elementor-column elementor-field-group-field_ee12fc0 elementor-col-100 elementor-field-required">
<input size="1" type="text" name="form_fields[field_ee12fc0]" id="form-field-field_ee12fc0" class="elementor-field elementor-size-sm  elementor-field-textual" placeholder="Website Link" required="required" aria-required="true"> </div>
<div class="elementor-field-type-text elementor-field-group elementor-column elementor-field-group-field_fc6a9af elementor-col-100 elementor-field-required">
<input size="1" type="text" name="form_fields[field_fc6a9af]" id="form-field-field_fc6a9af" class="elementor-field elementor-size-sm  elementor-field-textual" placeholder="Additional Information" required="required" aria-required="true"> </div>
<div class="elementor-field-group elementor-column elementor-field-type-submit elementor-col-100 e-form__buttons">
<button type="submit" class="elementor-button elementor-size-sm">
<span>
<span class=" elementor-button-icon">
</span>
<span class="elementor-button-text">Submit</span>
</span>
</button>
</div>
</div>
</form>
</div>
</div>
<div class="elementor-element elementor-element-43b9827 elementor-widget elementor-widget-spacer" data-id="43b9827" data-element_type="widget" data-widget_type="spacer.default">
<div class="elementor-widget-container">
<div class="elementor-spacer">
<div class="elementor-spacer-inner"></div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</section>
<section class="elementor-section elementor-top-section elementor-element elementor-element-d067d5b elementor-section-full_width elementor-section-height-default elementor-section-height-default" data-id="d067d5b" data-element_type="section" data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
<div class="elementor-container elementor-column-gap-default">
<div class="elementor-row">
<div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-d2a94e1" data-id="d2a94e1" data-element_type="column">
<div class="elementor-column-wrap elementor-element-populated">
<div class="elementor-widget-wrap">
<div class="elementor-element elementor-element-eef8589 elementor-pagination-position-outside elementor-widget elementor-widget-image-carousel" data-id="eef8589" data-element_type="widget" data-settings="{&quot;slides_to_show&quot;:&quot;8&quot;,&quot;slides_to_scroll&quot;:&quot;1&quot;,&quot;navigation&quot;:&quot;dots&quot;,&quot;slides_to_show_tablet&quot;:&quot;4&quot;,&quot;slides_to_show_mobile&quot;:&quot;3&quot;,&quot;slides_to_scroll_mobile&quot;:&quot;3&quot;,&quot;autoplay&quot;:&quot;yes&quot;,&quot;pause_on_hover&quot;:&quot;yes&quot;,&quot;pause_on_interaction&quot;:&quot;yes&quot;,&quot;autoplay_speed&quot;:5000,&quot;infinite&quot;:&quot;yes&quot;,&quot;speed&quot;:500,&quot;image_spacing_custom&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:20,&quot;sizes&quot;:[]}}" data-widget_type="image-carousel.default">
<div class="elementor-widget-container">
<div class="elementor-image-carousel-wrapper swiper-container" dir="ltr">
<div class="elementor-image-carousel swiper-wrapper">
<div class="swiper-slide"><figure class="swiper-slide-inner"><img alt="1 MORE" data-src="https://letsinfluence.io/wp-content/uploads/2020/12/1-MORE-1.png" class="swiper-slide-image lazyload" src="data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==" /><noscript><img class="swiper-slide-image" src="../wp-content/uploads/2020/12/1-MORE-1.png" alt="1 MORE"/></noscript></figure></div><div class="swiper-slide"><figure class="swiper-slide-inner"><img alt="Byte Dance" data-src="https://letsinfluence.io/wp-content/uploads/2020/12/Byte-Dance-1.png" class="swiper-slide-image lazyload" src="data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==" /><noscript><img class="swiper-slide-image" src="../wp-content/uploads/2020/12/Byte-Dance-1.png" alt="Byte Dance"/></noscript></figure></div><div class="swiper-slide"><figure class="swiper-slide-inner"><img alt="COSCO" data-src="https://letsinfluence.io/wp-content/uploads/2020/12/COSCO-1.png" class="swiper-slide-image lazyload" src="data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==" /><noscript><img class="swiper-slide-image" src="../wp-content/uploads/2020/12/COSCO-1.png" alt="COSCO"/></noscript></figure></div><div class="swiper-slide"><figure class="swiper-slide-inner"><img alt="mamaearth" data-src="https://letsinfluence.io/wp-content/uploads/2020/12/mamaearth-1.png" class="swiper-slide-image lazyload" src="data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==" /><noscript><img class="swiper-slide-image" src="../wp-content/uploads/2020/12/mamaearth-1.png" alt="mamaearth"/></noscript></figure></div><div class="swiper-slide"><figure class="swiper-slide-inner"><img alt="Times internet" data-src="https://letsinfluence.io/wp-content/uploads/2020/12/Times-internet-1.png" class="swiper-slide-image lazyload" src="data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==" /><noscript><img class="swiper-slide-image" src="../wp-content/uploads/2020/12/Times-internet-1.png" alt="Times internet"/></noscript></figure></div><div class="swiper-slide"><figure class="swiper-slide-inner"><img alt="snapdeal" data-src="https://letsinfluence.io/wp-content/uploads/2020/12/snapdeal-1.png" class="swiper-slide-image lazyload" src="data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==" /><noscript><img class="swiper-slide-image" src="../wp-content/uploads/2020/12/snapdeal-1.png" alt="snapdeal"/></noscript></figure></div><div class="swiper-slide"><figure class="swiper-slide-inner"><img alt="Truebasics" data-src="https://letsinfluence.io/wp-content/uploads/2020/12/Truebasics-1.png" class="swiper-slide-image lazyload" src="data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==" /><noscript><img class="swiper-slide-image" src="../wp-content/uploads/2020/12/Truebasics-1.png" alt="Truebasics"/></noscript></figure></div><div class="swiper-slide"><figure class="swiper-slide-inner"><img alt="Trulymadly" data-src="https://letsinfluence.io/wp-content/uploads/2020/12/Trulymadly-1.png" class="swiper-slide-image lazyload" src="data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==" /><noscript><img class="swiper-slide-image" src="../wp-content/uploads/2020/12/Trulymadly-1.png" alt="Trulymadly"/></noscript></figure></div><div class="swiper-slide"><figure class="swiper-slide-inner"><img alt="Titan" data-src="https://letsinfluence.io/wp-content/uploads/2020/12/Titan-1.png" class="swiper-slide-image lazyload" src="data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==" /><noscript><img class="swiper-slide-image" src="../wp-content/uploads/2020/12/Titan-1.png" alt="Titan"/></noscript></figure></div><div class="swiper-slide"><figure class="swiper-slide-inner"><img alt="Neemans" data-src="https://letsinfluence.io/wp-content/uploads/2020/12/Neemans-1.png" class="swiper-slide-image lazyload" src="data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==" /><noscript><img class="swiper-slide-image" src="../wp-content/uploads/2020/12/Neemans-1.png" alt="Neemans"/></noscript></figure></div><div class="swiper-slide"><figure class="swiper-slide-inner"><img alt="bOAt" data-src="https://letsinfluence.io/wp-content/uploads/2020/12/bOAt-1.png" class="swiper-slide-image lazyload" src="data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==" /><noscript><img class="swiper-slide-image" src="../wp-content/uploads/2020/12/bOAt-1.png" alt="bOAt"/></noscript></figure></div><div class="swiper-slide"><figure class="swiper-slide-inner"><img alt="emami" data-src="https://letsinfluence.io/wp-content/uploads/2020/12/emami-1.png" class="swiper-slide-image lazyload" src="data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==" /><noscript><img class="swiper-slide-image" src="../wp-content/uploads/2020/12/emami-1.png" alt="emami"/></noscript></figure></div><div class="swiper-slide"><figure class="swiper-slide-inner"><img alt="momo" data-src="https://letsinfluence.io/wp-content/uploads/2020/12/momo-1.png" class="swiper-slide-image lazyload" src="data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==" /><noscript><img class="swiper-slide-image" src="../wp-content/uploads/2020/12/momo-1.png" alt="momo"/></noscript></figure></div><div class="swiper-slide"><figure class="swiper-slide-inner"><img alt="MPL" data-src="https://letsinfluence.io/wp-content/uploads/2020/12/MPL-1.png" class="swiper-slide-image lazyload" src="data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==" /><noscript><img class="swiper-slide-image" src="../wp-content/uploads/2020/12/MPL-1.png" alt="MPL"/></noscript></figure></div><div class="swiper-slide"><figure class="swiper-slide-inner"><img alt="meesho" data-src="https://letsinfluence.io/wp-content/uploads/2020/12/meesho-1.png" class="swiper-slide-image lazyload" src="data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==" /><noscript><img class="swiper-slide-image" src="../wp-content/uploads/2020/12/meesho-1.png" alt="meesho"/></noscript></figure></div><div class="swiper-slide"><figure class="swiper-slide-inner"><img alt="purplle 1" data-src="https://letsinfluence.io/wp-content/uploads/2020/12/purplle-1-1.png" class="swiper-slide-image lazyload" src="data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==" /><noscript><img class="swiper-slide-image" src="../wp-content/uploads/2020/12/purplle-1-1.png" alt="purplle 1"/></noscript></figure></div><div class="swiper-slide"><figure class="swiper-slide-inner"><img alt="Pee buddy" data-src="https://letsinfluence.io/wp-content/uploads/2020/12/Pee-buddy-1.png" class="swiper-slide-image lazyload" src="data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==" /><noscript><img class="swiper-slide-image" src="../wp-content/uploads/2020/12/Pee-buddy-1.png" alt="Pee buddy"/></noscript></figure></div><div class="swiper-slide"><figure class="swiper-slide-inner"><img alt="noise" data-src="https://letsinfluence.io/wp-content/uploads/2020/12/noise-1.png" class="swiper-slide-image lazyload" src="data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==" /><noscript><img class="swiper-slide-image" src="../wp-content/uploads/2020/12/noise-1.png" alt="noise"/></noscript></figure></div><div class="swiper-slide"><figure class="swiper-slide-inner"><img alt="OYO" data-src="https://letsinfluence.io/wp-content/uploads/2020/12/OYO-1.png" class="swiper-slide-image lazyload" src="data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==" /><noscript><img class="swiper-slide-image" src="../wp-content/uploads/2020/12/OYO-1.png" alt="OYO"/></noscript></figure></div><div class="swiper-slide"><figure class="swiper-slide-inner"><img alt="happy bar" data-src="https://letsinfluence.io/wp-content/uploads/2020/12/happy-bar-1.png" class="swiper-slide-image lazyload" src="data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==" /><noscript><img class="swiper-slide-image" src="../wp-content/uploads/2020/12/happy-bar-1.png" alt="happy bar"/></noscript></figure></div><div class="swiper-slide"><figure class="swiper-slide-inner"><img alt="nua" data-src="https://letsinfluence.io/wp-content/uploads/2020/12/nua-1.png" class="swiper-slide-image lazyload" src="data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==" /><noscript><img class="swiper-slide-image" src="../wp-content/uploads/2020/12/nua-1.png" alt="nua"/></noscript></figure></div><div class="swiper-slide"><figure class="swiper-slide-inner"><img alt="Wild Stone" data-src="https://letsinfluence.io/wp-content/uploads/2020/12/Wild-Stone-1.png" class="swiper-slide-image lazyload" src="data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==" /><noscript><img class="swiper-slide-image" src="../wp-content/uploads/2020/12/Wild-Stone-1.png" alt="Wild Stone"/></noscript></figure></div><div class="swiper-slide"><figure class="swiper-slide-inner"><img alt="BSC" data-src="https://letsinfluence.io/wp-content/uploads/2021/01/BSC.jpg" class="swiper-slide-image lazyload" src="data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==" /><noscript><img class="swiper-slide-image" src="../wp-content/uploads/2021/01/BSC.jpg" alt="BSC"/></noscript></figure></div> </div>
<div class="swiper-pagination"></div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</section>
</div>
</div>
</div>
@endsection

@section('scripts')
	@parent
	<script type="text/javascript">function wpfront_scroll_top_init(){if(typeof wpfront_scroll_top=="function"&&typeof jQuery!=="undefined"){wpfront_scroll_top({"scroll_offset":100,"button_width":30,"button_height":30,"button_opacity":0.8,"button_fade_duration":200,"scroll_duration":400,"location":1,"marginX":20,"marginY":20,"hide_iframe":false,"auto_hide":false,"auto_hide_after":2,"button_action":"top","button_action_element_selector":"","button_action_container_selector":"html, body","button_action_element_offset":0});}else{setTimeout(wpfront_scroll_top_init,100);}}wpfront_scroll_top_init();</script>
	<link rel='stylesheet' id='elementor-gallery-css' href="{{ asset('front-asset/e-gallery/css/e-gallery.min7359.css?ver=1.2.0') }}" type='text/css' media='all' />
	<script type='text/javascript' src="{{ asset('front-asset/e-gallery/js/e-gallery.min7359.js?ver=1.2.0') }}" id='elementor-gallery-js'></script>
@endsection