@extends('layouts.app')
 
@section('title', $title)

@section('css')
    @parent
    
<link rel='stylesheet' id='elementor-post-2552-css' href="{{ asset('front-asset/css/post-255211a2.css?ver=1615652497') }}" type='text/css' media='all' />
@endsection


 
@section('content')
<main class="site-main post-2552 page type-page status-publish hentry" role="main">
<div class="page-content">
<div data-elementor-type="wp-page" data-elementor-id="2552" class="elementor elementor-2552" data-elementor-settings="[]">
<div class="elementor-inner">
<div class="elementor-section-wrap">
<section class="elementor-section elementor-top-section elementor-element elementor-element-45e08907 elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="45e08907" data-element_type="section" data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
<div class="elementor-container elementor-column-gap-default">
<div class="elementor-row">
<div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-58b8dcc9" data-id="58b8dcc9" data-element_type="column">
<div class="elementor-column-wrap elementor-element-populated">
<div class="elementor-widget-wrap">
<div class="elementor-element elementor-element-939b727 elementor-widget elementor-widget-heading" data-id="939b727" data-element_type="widget" data-widget_type="heading.default">
<div class="elementor-widget-container">
<h2 class="elementor-heading-title elementor-size-default"><i>What We Do?</i></h2> </div>
</div>
<div class="elementor-element elementor-element-3a081cae elementor-widget elementor-widget-text-editor" data-id="3a081cae" data-element_type="widget" data-widget_type="text-editor.default">
<div class="elementor-widget-container">
<div class="elementor-text-editor elementor-clearfix"><div dir="ltr">We are one of the leading Influencer marketing agencies in India that help in ideating brand campaign strategies and backing them with effective advocacy solutions so as to deliver high-quality engagement for the brand. Boasting a base of over 25000+ social media influencers and bloggers, it helps you find the right influencer for your brand. Brands who trust LetsInfluence include giants like Flipkart, Boat, MPL, Oyo, Bytedance, TimesInternet, Snapdeal, Cosco, Meesho, Bombay shaving company among 100+ other top brands.</div><div dir="ltr"> </div><div dir="ltr"><div dir="ltr">We specialize in working with brands for movie integrations, web series integrations, and Influencer Marketing and Celebrity endorsements. We are the voice of new-age influencers and create stunning campaigns.</div><div dir="ltr"> </div></div></div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</section>
<section class="elementor-section elementor-top-section elementor-element elementor-element-1854df3 elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="1854df3" data-element_type="section">
<div class="elementor-container elementor-column-gap-default">
<div class="elementor-row">
<div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-0032920" data-id="0032920" data-element_type="column">
<div class="elementor-column-wrap elementor-element-populated">
<div class="elementor-widget-wrap">
<div class="elementor-element elementor-element-47b43c4 elementor-widget elementor-widget-heading" data-id="47b43c4" data-element_type="widget" data-widget_type="heading.default">
<div class="elementor-widget-container">
<h2 class="elementor-heading-title elementor-size-default"><i>Why Choose Us?</i></h2> </div>
</div>
</div>
</div>
</div>
</div>
</div>
</section>
<section class="elementor-section elementor-top-section elementor-element elementor-element-32ee655e elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="32ee655e" data-element_type="section">
<div class="elementor-container elementor-column-gap-default">
<div class="elementor-row">
<div class="elementor-column elementor-col-33 elementor-top-column elementor-element elementor-element-307e7ffa" data-id="307e7ffa" data-element_type="column">
<div class="elementor-column-wrap elementor-element-populated">
<div class="elementor-widget-wrap">
<section class="elementor-section elementor-inner-section elementor-element elementor-element-50fea66e elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="50fea66e" data-element_type="section" data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
<div class="elementor-container elementor-column-gap-default">
<div class="elementor-row">
<div class="elementor-column elementor-col-100 elementor-inner-column elementor-element elementor-element-773af70e" data-id="773af70e" data-element_type="column">
<div class="elementor-column-wrap elementor-element-populated">
<div class="elementor-widget-wrap">
<div class="elementor-element elementor-element-559c892b elementor-widget elementor-widget-image" data-id="559c892b" data-element_type="widget" data-widget_type="image.default">
<div class="elementor-widget-container">
<div class="elementor-image">
<img width="800" height="518" alt="" loading="lazy" data-srcset="https://letsinfluence.io/wp-content/uploads/2021/01/shutterstock_1438686164156664646464-1024x663.jpg 1024w, https://letsinfluence.io/wp-content/uploads/2021/01/shutterstock_1438686164156664646464-300x194.jpg 300w, https://letsinfluence.io/wp-content/uploads/2021/01/shutterstock_1438686164156664646464-768x497.jpg 768w" data-src="https://letsinfluence.io/wp-content/uploads/2021/01/shutterstock_1438686164156664646464-1024x663.jpg" data-sizes="(max-width: 800px) 100vw, 800px" class="attachment-large size-large lazyload" src="data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==" /><noscript><img width="800" height="518" src="../wp-content/uploads/2021/01/shutterstock_1438686164156664646464-1024x663.jpg" class="attachment-large size-large" alt="" loading="lazy" srcset="https://letsinfluence.io/wp-content/uploads/2021/01/shutterstock_1438686164156664646464-1024x663.jpg 1024w, https://letsinfluence.io/wp-content/uploads/2021/01/shutterstock_1438686164156664646464-300x194.jpg 300w, https://letsinfluence.io/wp-content/uploads/2021/01/shutterstock_1438686164156664646464-768x497.jpg 768w" sizes="(max-width: 800px) 100vw, 800px"/></noscript> </div>
</div>
</div>
<div class="elementor-element elementor-element-1eba3603 elementor-widget elementor-widget-text-editor" data-id="1eba3603" data-element_type="widget" data-widget_type="text-editor.default">
<div class="elementor-widget-container">
<div class="elementor-text-editor elementor-clearfix"><p>Founded in 2018 with a mission to create authentic marketing campaigns on digital platforms, and link your brands and products with digital influencers and their followers, your target groups. </p></div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</section>
</div>
</div>
</div>
<div class="elementor-column elementor-col-33 elementor-top-column elementor-element elementor-element-201ac254" data-id="201ac254" data-element_type="column">
<div class="elementor-column-wrap elementor-element-populated">
<div class="elementor-widget-wrap">
<section class="elementor-section elementor-inner-section elementor-element elementor-element-337a75 elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="337a75" data-element_type="section" data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
<div class="elementor-container elementor-column-gap-default">
<div class="elementor-row">
<div class="elementor-column elementor-col-100 elementor-inner-column elementor-element elementor-element-6ecdd240" data-id="6ecdd240" data-element_type="column">
<div class="elementor-column-wrap elementor-element-populated">
<div class="elementor-widget-wrap">
<div class="elementor-element elementor-element-66f2e110 elementor-widget elementor-widget-image" data-id="66f2e110" data-element_type="widget" data-widget_type="image.default">
<div class="elementor-widget-container">
<div class="elementor-image">
<img width="800" height="531" alt="" loading="lazy" data-srcset="https://letsinfluence.io/wp-content/uploads/2021/01/shutterstock_421316761-1024x680.jpg 1024w, https://letsinfluence.io/wp-content/uploads/2021/01/shutterstock_421316761-300x199.jpg 300w, https://letsinfluence.io/wp-content/uploads/2021/01/shutterstock_421316761-768x510.jpg 768w" data-src="https://letsinfluence.io/wp-content/uploads/2021/01/shutterstock_421316761-1024x680.jpg" data-sizes="(max-width: 800px) 100vw, 800px" class="attachment-large size-large lazyload" src="data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==" /><noscript><img width="800" height="531" src="../wp-content/uploads/2021/01/shutterstock_421316761-1024x680.jpg" class="attachment-large size-large" alt="" loading="lazy" srcset="https://letsinfluence.io/wp-content/uploads/2021/01/shutterstock_421316761-1024x680.jpg 1024w, https://letsinfluence.io/wp-content/uploads/2021/01/shutterstock_421316761-300x199.jpg 300w, https://letsinfluence.io/wp-content/uploads/2021/01/shutterstock_421316761-768x510.jpg 768w" sizes="(max-width: 800px) 100vw, 800px"/></noscript> </div>
</div>
</div>
<div class="elementor-element elementor-element-573f5d65 elementor-widget elementor-widget-text-editor" data-id="573f5d65" data-element_type="widget" data-widget_type="text-editor.default">
<div class="elementor-widget-container">
<div class="elementor-text-editor elementor-clearfix"><div>We believe in a data-driven approach while strategizing a customized influencer marketing campaign execution</div></div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</section>
</div>
</div>
</div>
<div class="elementor-column elementor-col-33 elementor-top-column elementor-element elementor-element-e91dfa4" data-id="e91dfa4" data-element_type="column">
<div class="elementor-column-wrap elementor-element-populated">
<div class="elementor-widget-wrap">
<section class="elementor-section elementor-inner-section elementor-element elementor-element-46aa85e2 elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="46aa85e2" data-element_type="section" data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
<div class="elementor-container elementor-column-gap-default">
<div class="elementor-row">
<div class="elementor-column elementor-col-100 elementor-inner-column elementor-element elementor-element-2ee52a0f" data-id="2ee52a0f" data-element_type="column">
<div class="elementor-column-wrap elementor-element-populated">
<div class="elementor-widget-wrap">
<div class="elementor-element elementor-element-2b8ff32e elementor-widget elementor-widget-image" data-id="2b8ff32e" data-element_type="widget" data-widget_type="image.default">
<div class="elementor-widget-container">
<div class="elementor-image">
<img width="800" height="534" alt="" loading="lazy" data-srcset="https://letsinfluence.io/wp-content/uploads/2021/01/shutterstock_225264403-1024x683.jpg 1024w, https://letsinfluence.io/wp-content/uploads/2021/01/shutterstock_225264403-300x200.jpg 300w, https://letsinfluence.io/wp-content/uploads/2021/01/shutterstock_225264403-768x512.jpg 768w" data-src="https://letsinfluence.io/wp-content/uploads/2021/01/shutterstock_225264403-1024x683.jpg" data-sizes="(max-width: 800px) 100vw, 800px" class="attachment-large size-large lazyload" src="data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==" /><noscript><img width="800" height="534" src="../wp-content/uploads/2021/01/shutterstock_225264403-1024x683.jpg" class="attachment-large size-large" alt="" loading="lazy" srcset="https://letsinfluence.io/wp-content/uploads/2021/01/shutterstock_225264403-1024x683.jpg 1024w, https://letsinfluence.io/wp-content/uploads/2021/01/shutterstock_225264403-300x200.jpg 300w, https://letsinfluence.io/wp-content/uploads/2021/01/shutterstock_225264403-768x512.jpg 768w" sizes="(max-width: 800px) 100vw, 800px"/></noscript> </div>
</div>
</div>
<div class="elementor-element elementor-element-6c0b51b5 elementor-widget elementor-widget-text-editor" data-id="6c0b51b5" data-element_type="widget" data-widget_type="text-editor.default">
<div class="elementor-widget-container">
<div class="elementor-text-editor elementor-clearfix"><div>A network of over 25000+ influencers across social media and generating ROIs for 100+ brands.</div><div> </div></div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</section>
</div>
</div>
</div>
</div>
</div>
</section>
<section class="elementor-section elementor-top-section elementor-element elementor-element-33f6b81 elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="33f6b81" data-element_type="section">
<div class="elementor-container elementor-column-gap-default">
<div class="elementor-row">
<div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-a141d4" data-id="a141d4" data-element_type="column">
<div class="elementor-column-wrap elementor-element-populated">
<div class="elementor-widget-wrap">
<section class="elementor-section elementor-inner-section elementor-element elementor-element-4271451a elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="4271451a" data-element_type="section">
<div class="elementor-container elementor-column-gap-default">
<div class="elementor-row">
<div class="elementor-column elementor-col-33 elementor-inner-column elementor-element elementor-element-72e22834" data-id="72e22834" data-element_type="column">
<div class="elementor-column-wrap elementor-element-populated">
<div class="elementor-widget-wrap">
<div class="elementor-element elementor-element-765bec80 elementor-widget elementor-widget-counter" data-id="765bec80" data-element_type="widget" data-widget_type="counter.default">
<div class="elementor-widget-container">
<div class="elementor-counter">
<div class="elementor-counter-number-wrapper">
<span class="elementor-counter-number-prefix"></span>
<span class="elementor-counter-number" data-duration="2000" data-to-value="25000" data-from-value="0">0</span>
<span class="elementor-counter-number-suffix">+</span>
</div>
<div class="elementor-counter-title">Influencers</div>
</div>
</div>
</div>
</div>
</div>
</div>
<div class="elementor-column elementor-col-33 elementor-inner-column elementor-element elementor-element-6dfa44da" data-id="6dfa44da" data-element_type="column">
<div class="elementor-column-wrap elementor-element-populated">
<div class="elementor-widget-wrap">
<div class="elementor-element elementor-element-7f8b3b81 elementor-widget elementor-widget-counter" data-id="7f8b3b81" data-element_type="widget" data-widget_type="counter.default">
<div class="elementor-widget-container">
<div class="elementor-counter">
<div class="elementor-counter-number-wrapper">
<span class="elementor-counter-number-prefix"></span>
<span class="elementor-counter-number" data-duration="2000" data-to-value="500" data-from-value="0" data-delimiter=".">0</span>
<span class="elementor-counter-number-suffix">+</span>
</div>
<div class="elementor-counter-title">Celebrities</div>
</div>
</div>
</div>
</div>
</div>
</div>
<div class="elementor-column elementor-col-33 elementor-inner-column elementor-element elementor-element-68589766" data-id="68589766" data-element_type="column">
<div class="elementor-column-wrap elementor-element-populated">
<div class="elementor-widget-wrap">
<div class="elementor-element elementor-element-147d8b7a elementor-widget elementor-widget-counter" data-id="147d8b7a" data-element_type="widget" data-widget_type="counter.default">
<div class="elementor-widget-container">
<div class="elementor-counter">
<div class="elementor-counter-number-wrapper">
<span class="elementor-counter-number-prefix"></span>
<span class="elementor-counter-number" data-duration="2000" data-to-value="100" data-from-value="0" data-delimiter=".">0</span>
<span class="elementor-counter-number-suffix">+</span>
</div>
<div class="elementor-counter-title">Brands</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</section>
</div>
</div>
</div>
</div>
</div>
</section>
<section class="elementor-section elementor-top-section elementor-element elementor-element-a47317f elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="a47317f" data-element_type="section">
<div class="elementor-container elementor-column-gap-default">
<div class="elementor-row">
<div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-64e2a16a" data-id="64e2a16a" data-element_type="column">
<div class="elementor-column-wrap elementor-element-populated">
<div class="elementor-widget-wrap">
<div class="elementor-element elementor-element-e35956c elementor-widget elementor-widget-heading" data-id="e35956c" data-element_type="widget" data-widget_type="heading.default">
<div class="elementor-widget-container">
<h2 class="elementor-heading-title elementor-size-default"><i>Meet Our Team</i></h2> </div>
</div>
<div class="elementor-element elementor-element-ccd7386 elementor-widget elementor-widget-text-editor" data-id="ccd7386" data-element_type="widget" data-widget_type="text-editor.default">
<div class="elementor-widget-container">
<div class="elementor-text-editor elementor-clearfix"><p>We are team of experienced product, design, sales &amp;<br />marketing professionals who are experts at what<br />they do.</p></div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</section>
<section class="elementor-section elementor-top-section elementor-element elementor-element-e171905 elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="e171905" data-element_type="section">
<div class="elementor-container elementor-column-gap-default">
<div class="elementor-row">
<div class="elementor-column elementor-col-25 elementor-top-column elementor-element elementor-element-b08e574" data-id="b08e574" data-element_type="column">
<div class="elementor-column-wrap elementor-element-populated">
<div class="elementor-widget-wrap">
<div class="elementor-element elementor-element-cffa1b3 elementor-widget elementor-widget-image" data-id="cffa1b3" data-element_type="widget" data-widget_type="image.default">
<div class="elementor-widget-container">
<div class="elementor-image">
<img title="Bhawna Sethi &#8211; Founder" alt="Bhawna Sethi - Founder" data-src="https://letsinfluence.io/wp-content/uploads/elementor/thumbs/FF8AD6AE-91F6-4412-8815-4E8296B12F6F-1-p0wyq87243wxxbrg55d7t5psn54gevlpaag8ck43i0.jpg" class="lazyload" src="data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==" /><noscript><img src="../wp-content/uploads/elementor/thumbs/FF8AD6AE-91F6-4412-8815-4E8296B12F6F-1-p0wyq87243wxxbrg55d7t5psn54gevlpaag8ck43i0.jpg" title="Bhawna Sethi &#8211; Founder" alt="Bhawna Sethi - Founder"/></noscript> </div>
</div>
</div>
<div class="elementor-element elementor-element-36fc769 elementor-widget elementor-widget-heading" data-id="36fc769" data-element_type="widget" data-widget_type="heading.default">
<div class="elementor-widget-container">
<h5 class="elementor-heading-title elementor-size-default">BHAWNA SETHI</h5> </div>
</div>
<div class="elementor-element elementor-element-38dd794 elementor-widget elementor-widget-text-editor" data-id="38dd794" data-element_type="widget" data-widget_type="text-editor.default">
<div class="elementor-widget-container">
<div class="elementor-text-editor elementor-clearfix"><p>Founder</p></div>
</div>
</div>
</div>
</div>
</div>
<div class="elementor-column elementor-col-25 elementor-top-column elementor-element elementor-element-f92f660" data-id="f92f660" data-element_type="column">
<div class="elementor-column-wrap elementor-element-populated">
<div class="elementor-widget-wrap">
<div class="elementor-element elementor-element-b9a478e elementor-widget elementor-widget-image" data-id="b9a478e" data-element_type="widget" data-widget_type="image.default">
<div class="elementor-widget-container">
<div class="elementor-image">
<img title="Shikha Singh &#8211; Influencer Relationship Manager" alt="Shikha Singh - Influencer Relationship Manager" data-src="https://letsinfluence.io/wp-content/uploads/elementor/thumbs/Shikha-Singh-Influencer-Relationship-Manager-1-p0v69hm6cozz0krimhwc5aekw9qwxnfkjp9tnf3fzs.jpg" class="lazyload" src="data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==" /><noscript><img src="../wp-content/uploads/elementor/thumbs/Shikha-Singh-Influencer-Relationship-Manager-1-p0v69hm6cozz0krimhwc5aekw9qwxnfkjp9tnf3fzs.jpg" title="Shikha Singh &#8211; Influencer Relationship Manager" alt="Shikha Singh - Influencer Relationship Manager"/></noscript> </div>
</div>
</div>
<div class="elementor-element elementor-element-206428c elementor-widget elementor-widget-heading" data-id="206428c" data-element_type="widget" data-widget_type="heading.default">
<div class="elementor-widget-container">
<h5 class="elementor-heading-title elementor-size-default">SHIKHA SINGH</h5> </div>
</div>
<div class="elementor-element elementor-element-13da34c elementor-widget elementor-widget-text-editor" data-id="13da34c" data-element_type="widget" data-widget_type="text-editor.default">
<div class="elementor-widget-container">
<div class="elementor-text-editor elementor-clearfix"><p>Influencer Relationship Manager</p></div>
</div>
</div>
</div>
</div>
</div>
<div class="elementor-column elementor-col-25 elementor-top-column elementor-element elementor-element-a8d9ef0" data-id="a8d9ef0" data-element_type="column">
<div class="elementor-column-wrap elementor-element-populated">
<div class="elementor-widget-wrap">
<div class="elementor-element elementor-element-76850be elementor-widget elementor-widget-image" data-id="76850be" data-element_type="widget" data-widget_type="image.default">
<div class="elementor-widget-container">
<div class="elementor-image">
<img title="Bhanvi Malhotra &#8211; Influencer Relation specialist" alt="Bhanvi Malhotra - Influencer Relation specialist" data-src="https://letsinfluence.io/wp-content/uploads/elementor/thumbs/Bhanvi-Malhotra-Influencer-Relation-specialist-p0v69kfox73tzenf6147uroyofd0kqqrk38a38z9h4.jpg" class="lazyload" src="data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==" /><noscript><img src="../wp-content/uploads/elementor/thumbs/Bhanvi-Malhotra-Influencer-Relation-specialist-p0v69kfox73tzenf6147uroyofd0kqqrk38a38z9h4.jpg" title="Bhanvi Malhotra &#8211; Influencer Relation specialist" alt="Bhanvi Malhotra - Influencer Relation specialist"/></noscript> </div>
</div>
</div>
<div class="elementor-element elementor-element-6e6a3f6 elementor-widget elementor-widget-heading" data-id="6e6a3f6" data-element_type="widget" data-widget_type="heading.default">
<div class="elementor-widget-container">
<h5 class="elementor-heading-title elementor-size-default">BHANVI MALHOTRA</h5> </div>
</div>
<div class="elementor-element elementor-element-b9e39f4 elementor-widget elementor-widget-text-editor" data-id="b9e39f4" data-element_type="widget" data-widget_type="text-editor.default">
<div class="elementor-widget-container">
<div class="elementor-text-editor elementor-clearfix"><p>Influencer Relation specialist</p></div>
</div>
</div>
</div>
</div>
</div>
<div class="elementor-column elementor-col-25 elementor-top-column elementor-element elementor-element-24c1317" data-id="24c1317" data-element_type="column">
<div class="elementor-column-wrap elementor-element-populated">
<div class="elementor-widget-wrap">
<div class="elementor-element elementor-element-13d47e2 elementor-widget elementor-widget-image" data-id="13d47e2" data-element_type="widget" data-widget_type="image.default">
<div class="elementor-widget-container">
<div class="elementor-image">
<img title="Kanika Mangal &#8211; Business Development Head" alt="Kanika Mangal - Business Development Head" data-src="https://letsinfluence.io/wp-content/uploads/elementor/thumbs/Kanika-Mangal-Business-Development-Head-1-p0v69urx0dhzj48ehnl447317ny1xevt9iemdajxko.jpg" class="lazyload" src="data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==" /><noscript><img src="../wp-content/uploads/elementor/thumbs/Kanika-Mangal-Business-Development-Head-1-p0v69urx0dhzj48ehnl447317ny1xevt9iemdajxko.jpg" title="Kanika Mangal &#8211; Business Development Head" alt="Kanika Mangal - Business Development Head"/></noscript> </div>
</div>
</div>
<div class="elementor-element elementor-element-d78be5c elementor-widget elementor-widget-heading" data-id="d78be5c" data-element_type="widget" data-widget_type="heading.default">
<div class="elementor-widget-container">
<h5 class="elementor-heading-title elementor-size-default">KANIKA MANGAL</h5> </div>
</div>
<div class="elementor-element elementor-element-7ca4f2b elementor-widget elementor-widget-text-editor" data-id="7ca4f2b" data-element_type="widget" data-widget_type="text-editor.default">
<div class="elementor-widget-container">
<div class="elementor-text-editor elementor-clearfix"><p>Business Development Head</p></div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</section>
<section class="elementor-section elementor-top-section elementor-element elementor-element-628a7d3 elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="628a7d3" data-element_type="section">
<div class="elementor-container elementor-column-gap-default">
<div class="elementor-row">
<div class="elementor-column elementor-col-33 elementor-top-column elementor-element elementor-element-947e6fa" data-id="947e6fa" data-element_type="column">
<div class="elementor-column-wrap elementor-element-populated">
<div class="elementor-widget-wrap">
<div class="elementor-element elementor-element-d6deb84 elementor-widget elementor-widget-image" data-id="d6deb84" data-element_type="widget" data-widget_type="image.default">
<div class="elementor-widget-container">
<div class="elementor-image">
<img title="Shruti Kashyap &#8211; Influencer Relation specialist" alt="Shruti Kashyap - Influencer Relation specialist" data-src="https://letsinfluence.io/wp-content/uploads/elementor/thumbs/Shruti-Kashyap-Influencer-Relation-specialist-1-p0v69mbdav6emmkov1xgzr7vv73r04y88cj91swh4o.jpg" class="lazyload" src="data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==" /><noscript><img src="../wp-content/uploads/elementor/thumbs/Shruti-Kashyap-Influencer-Relation-specialist-1-p0v69mbdav6emmkov1xgzr7vv73r04y88cj91swh4o.jpg" title="Shruti Kashyap &#8211; Influencer Relation specialist" alt="Shruti Kashyap - Influencer Relation specialist"/></noscript> </div>
</div>
</div>
<div class="elementor-element elementor-element-4d0e0c1 elementor-widget elementor-widget-heading" data-id="4d0e0c1" data-element_type="widget" data-widget_type="heading.default">
<div class="elementor-widget-container">
<h5 class="elementor-heading-title elementor-size-default">SHRUTI KASHYAP</h5> </div>
</div>
<div class="elementor-element elementor-element-85337a3 elementor-widget elementor-widget-text-editor" data-id="85337a3" data-element_type="widget" data-widget_type="text-editor.default">
<div class="elementor-widget-container">
<div class="elementor-text-editor elementor-clearfix"><p>Influencer Relation specialist</p></div>
</div>
</div>
</div>
</div>
</div>
<div class="elementor-column elementor-col-33 elementor-top-column elementor-element elementor-element-4a35c30" data-id="4a35c30" data-element_type="column">
<div class="elementor-column-wrap elementor-element-populated">
<div class="elementor-widget-wrap">
<div class="elementor-element elementor-element-ed92de4 elementor-widget elementor-widget-image" data-id="ed92de4" data-element_type="widget" data-widget_type="image.default">
<div class="elementor-widget-container">
<div class="elementor-image">
<img title="Aditi Jain &#8211; Senior Influencer Manager" alt="Aditi Jain - Senior Influencer Manager" data-src="https://letsinfluence.io/wp-content/uploads/elementor/thumbs/Aditi-Jain-Senior-Influencer-Manager-1-p0v69r0k91cu8odv3lylu816u4gl2mgvwzsog6pi9k.jpg" class="lazyload" src="data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==" /><noscript><img src="../wp-content/uploads/elementor/thumbs/Aditi-Jain-Senior-Influencer-Manager-1-p0v69r0k91cu8odv3lylu816u4gl2mgvwzsog6pi9k.jpg" title="Aditi Jain &#8211; Senior Influencer Manager" alt="Aditi Jain - Senior Influencer Manager"/></noscript> </div>
</div>
</div>
<div class="elementor-element elementor-element-d269eee elementor-widget elementor-widget-heading" data-id="d269eee" data-element_type="widget" data-widget_type="heading.default">
<div class="elementor-widget-container">
<h5 class="elementor-heading-title elementor-size-default">ADITI JAIN</h5> </div>
</div>
<div class="elementor-element elementor-element-c2326bf elementor-widget elementor-widget-text-editor" data-id="c2326bf" data-element_type="widget" data-widget_type="text-editor.default">
<div class="elementor-widget-container">
<div class="elementor-text-editor elementor-clearfix"><p>Senior Influencer Manager</p></div>
</div>
</div>
</div>
</div>
</div>
<div class="elementor-column elementor-col-33 elementor-top-column elementor-element elementor-element-eedc67f" data-id="eedc67f" data-element_type="column">
<div class="elementor-column-wrap elementor-element-populated">
<div class="elementor-widget-wrap">
<div class="elementor-element elementor-element-04f16a5 elementor-widget elementor-widget-image" data-id="04f16a5" data-element_type="widget" data-widget_type="image.default">
<div class="elementor-widget-container">
<div class="elementor-image">
<img title="Ishaani &#8211; Brand strategist" alt="Ishaani - Brand strategist" data-src="https://letsinfluence.io/wp-content/uploads/elementor/thumbs/Ishaani-Brand-strategist-1-p0v69sw8mpfevwb4smruz7k40w7bi0ocl93neqmpx4.jpg" class="lazyload" src="data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==" /><noscript><img src="../wp-content/uploads/elementor/thumbs/Ishaani-Brand-strategist-1-p0v69sw8mpfevwb4smruz7k40w7bi0ocl93neqmpx4.jpg" title="Ishaani &#8211; Brand strategist" alt="Ishaani - Brand strategist"/></noscript> </div>
</div>
</div>
<div class="elementor-element elementor-element-3179a1b elementor-widget elementor-widget-heading" data-id="3179a1b" data-element_type="widget" data-widget_type="heading.default">
<div class="elementor-widget-container">
<h5 class="elementor-heading-title elementor-size-default">ISHAANI</h5> </div>
</div>
<div class="elementor-element elementor-element-e68787a elementor-widget elementor-widget-text-editor" data-id="e68787a" data-element_type="widget" data-widget_type="text-editor.default">
<div class="elementor-widget-container">
<div class="elementor-text-editor elementor-clearfix"><p>Brand strategist</p></div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</section>
<section class="elementor-section elementor-top-section elementor-element elementor-element-464ad65 elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="464ad65" data-element_type="section">
<div class="elementor-container elementor-column-gap-default">
<div class="elementor-row">
<div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-ab03553" data-id="ab03553" data-element_type="column">
<div class="elementor-column-wrap elementor-element-populated">
<div class="elementor-widget-wrap">
<div class="elementor-element elementor-element-a201f15 elementor-widget elementor-widget-heading" data-id="a201f15" data-element_type="widget" data-widget_type="heading.default">
<div class="elementor-widget-container">
<h2 class="elementor-heading-title elementor-size-default"><i>Our Vision</i></h2> </div>
</div>
<div class="elementor-element elementor-element-0ed94a2 elementor-widget elementor-widget-text-editor" data-id="0ed94a2" data-element_type="widget" data-widget_type="text-editor.default">
<div class="elementor-widget-container">
<div class="elementor-text-editor elementor-clearfix"><p>We strongly believe that anyone with strong social connection is an influencer, the offerings of an individual owned social profile varies depending upon the number of following or support the profile has from the people who follow them.</p><p>To be an Influencer you don’t have to be a labeled TikTok, Facebook, youtube, Instagram recognized profile. You just need to have a strong community as your followers, no matter what the count of your followers is.</p><p>We are driven by the passion to create an equal work distributed community with wages similar from top to bottom level. We plan to achieve so by bridging the gap between influencers, micro-influencers &amp; niche/starter influencers and we believe that each of these profiles has some core offerings which the other level of the community can’t offer, thus it provides us a chance to create a standardized and more structured community.</p></div>
</div>
</div>
<div class="elementor-element elementor-element-bc178b3 elementor-widget elementor-widget-spacer" data-id="bc178b3" data-element_type="widget" data-widget_type="spacer.default">
<div class="elementor-widget-container">
<div class="elementor-spacer">
<div class="elementor-spacer-inner"></div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</section>
<section class="elementor-section elementor-top-section elementor-element elementor-element-e894789 elementor-section-full_width elementor-section-height-default elementor-section-height-default" data-id="e894789" data-element_type="section" data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
<div class="elementor-container elementor-column-gap-default">
<div class="elementor-row">
<div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-9ec8f0d" data-id="9ec8f0d" data-element_type="column">
<div class="elementor-column-wrap elementor-element-populated">
<div class="elementor-widget-wrap">
<div class="elementor-element elementor-element-170a200 elementor-pagination-position-outside elementor-widget elementor-widget-image-carousel" data-id="170a200" data-element_type="widget" data-settings="{&quot;slides_to_show&quot;:&quot;8&quot;,&quot;slides_to_scroll&quot;:&quot;1&quot;,&quot;navigation&quot;:&quot;dots&quot;,&quot;slides_to_show_tablet&quot;:&quot;4&quot;,&quot;slides_to_show_mobile&quot;:&quot;3&quot;,&quot;slides_to_scroll_mobile&quot;:&quot;3&quot;,&quot;autoplay&quot;:&quot;yes&quot;,&quot;pause_on_hover&quot;:&quot;yes&quot;,&quot;pause_on_interaction&quot;:&quot;yes&quot;,&quot;autoplay_speed&quot;:5000,&quot;infinite&quot;:&quot;yes&quot;,&quot;speed&quot;:500,&quot;image_spacing_custom&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:20,&quot;sizes&quot;:[]}}" data-widget_type="image-carousel.default">
<div class="elementor-widget-container">
<div class="elementor-image-carousel-wrapper swiper-container" dir="ltr">
<div class="elementor-image-carousel swiper-wrapper">
<div class="swiper-slide"><figure class="swiper-slide-inner"><img alt="1 MORE" data-src="https://letsinfluence.io/wp-content/uploads/2020/12/1-MORE-1.png" class="swiper-slide-image lazyload" src="data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==" /><noscript><img class="swiper-slide-image" src="../wp-content/uploads/2020/12/1-MORE-1.png" alt="1 MORE"/></noscript></figure></div><div class="swiper-slide"><figure class="swiper-slide-inner"><img alt="Byte Dance" data-src="https://letsinfluence.io/wp-content/uploads/2020/12/Byte-Dance-1.png" class="swiper-slide-image lazyload" src="data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==" /><noscript><img class="swiper-slide-image" src="../wp-content/uploads/2020/12/Byte-Dance-1.png" alt="Byte Dance"/></noscript></figure></div><div class="swiper-slide"><figure class="swiper-slide-inner"><img alt="COSCO" data-src="https://letsinfluence.io/wp-content/uploads/2020/12/COSCO-1.png" class="swiper-slide-image lazyload" src="data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==" /><noscript><img class="swiper-slide-image" src="../wp-content/uploads/2020/12/COSCO-1.png" alt="COSCO"/></noscript></figure></div><div class="swiper-slide"><figure class="swiper-slide-inner"><img alt="mamaearth" data-src="https://letsinfluence.io/wp-content/uploads/2020/12/mamaearth-1.png" class="swiper-slide-image lazyload" src="data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==" /><noscript><img class="swiper-slide-image" src="../wp-content/uploads/2020/12/mamaearth-1.png" alt="mamaearth"/></noscript></figure></div><div class="swiper-slide"><figure class="swiper-slide-inner"><img alt="Times internet" data-src="https://letsinfluence.io/wp-content/uploads/2020/12/Times-internet-1.png" class="swiper-slide-image lazyload" src="data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==" /><noscript><img class="swiper-slide-image" src="../wp-content/uploads/2020/12/Times-internet-1.png" alt="Times internet"/></noscript></figure></div><div class="swiper-slide"><figure class="swiper-slide-inner"><img alt="snapdeal" data-src="https://letsinfluence.io/wp-content/uploads/2020/12/snapdeal-1.png" class="swiper-slide-image lazyload" src="data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==" /><noscript><img class="swiper-slide-image" src="../wp-content/uploads/2020/12/snapdeal-1.png" alt="snapdeal"/></noscript></figure></div><div class="swiper-slide"><figure class="swiper-slide-inner"><img alt="Truebasics" data-src="https://letsinfluence.io/wp-content/uploads/2020/12/Truebasics-1.png" class="swiper-slide-image lazyload" src="data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==" /><noscript><img class="swiper-slide-image" src="../wp-content/uploads/2020/12/Truebasics-1.png" alt="Truebasics"/></noscript></figure></div><div class="swiper-slide"><figure class="swiper-slide-inner"><img alt="Trulymadly" data-src="https://letsinfluence.io/wp-content/uploads/2020/12/Trulymadly-1.png" class="swiper-slide-image lazyload" src="data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==" /><noscript><img class="swiper-slide-image" src="../wp-content/uploads/2020/12/Trulymadly-1.png" alt="Trulymadly"/></noscript></figure></div><div class="swiper-slide"><figure class="swiper-slide-inner"><img alt="Titan" data-src="https://letsinfluence.io/wp-content/uploads/2020/12/Titan-1.png" class="swiper-slide-image lazyload" src="data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==" /><noscript><img class="swiper-slide-image" src="../wp-content/uploads/2020/12/Titan-1.png" alt="Titan"/></noscript></figure></div><div class="swiper-slide"><figure class="swiper-slide-inner"><img alt="Neemans" data-src="https://letsinfluence.io/wp-content/uploads/2020/12/Neemans-1.png" class="swiper-slide-image lazyload" src="data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==" /><noscript><img class="swiper-slide-image" src="../wp-content/uploads/2020/12/Neemans-1.png" alt="Neemans"/></noscript></figure></div><div class="swiper-slide"><figure class="swiper-slide-inner"><img alt="bOAt" data-src="https://letsinfluence.io/wp-content/uploads/2020/12/bOAt-1.png" class="swiper-slide-image lazyload" src="data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==" /><noscript><img class="swiper-slide-image" src="../wp-content/uploads/2020/12/bOAt-1.png" alt="bOAt"/></noscript></figure></div><div class="swiper-slide"><figure class="swiper-slide-inner"><img alt="emami" data-src="https://letsinfluence.io/wp-content/uploads/2020/12/emami-1.png" class="swiper-slide-image lazyload" src="data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==" /><noscript><img class="swiper-slide-image" src="../wp-content/uploads/2020/12/emami-1.png" alt="emami"/></noscript></figure></div><div class="swiper-slide"><figure class="swiper-slide-inner"><img alt="momo" data-src="https://letsinfluence.io/wp-content/uploads/2020/12/momo-1.png" class="swiper-slide-image lazyload" src="data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==" /><noscript><img class="swiper-slide-image" src="../wp-content/uploads/2020/12/momo-1.png" alt="momo"/></noscript></figure></div><div class="swiper-slide"><figure class="swiper-slide-inner"><img alt="MPL" data-src="https://letsinfluence.io/wp-content/uploads/2020/12/MPL-1.png" class="swiper-slide-image lazyload" src="data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==" /><noscript><img class="swiper-slide-image" src="../wp-content/uploads/2020/12/MPL-1.png" alt="MPL"/></noscript></figure></div><div class="swiper-slide"><figure class="swiper-slide-inner"><img alt="meesho" data-src="https://letsinfluence.io/wp-content/uploads/2020/12/meesho-1.png" class="swiper-slide-image lazyload" src="data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==" /><noscript><img class="swiper-slide-image" src="../wp-content/uploads/2020/12/meesho-1.png" alt="meesho"/></noscript></figure></div><div class="swiper-slide"><figure class="swiper-slide-inner"><img alt="purplle 1" data-src="https://letsinfluence.io/wp-content/uploads/2020/12/purplle-1-1.png" class="swiper-slide-image lazyload" src="data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==" /><noscript><img class="swiper-slide-image" src="../wp-content/uploads/2020/12/purplle-1-1.png" alt="purplle 1"/></noscript></figure></div><div class="swiper-slide"><figure class="swiper-slide-inner"><img alt="Pee buddy" data-src="https://letsinfluence.io/wp-content/uploads/2020/12/Pee-buddy-1.png" class="swiper-slide-image lazyload" src="data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==" /><noscript><img class="swiper-slide-image" src="../wp-content/uploads/2020/12/Pee-buddy-1.png" alt="Pee buddy"/></noscript></figure></div><div class="swiper-slide"><figure class="swiper-slide-inner"><img alt="noise" data-src="https://letsinfluence.io/wp-content/uploads/2020/12/noise-1.png" class="swiper-slide-image lazyload" src="data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==" /><noscript><img class="swiper-slide-image" src="../wp-content/uploads/2020/12/noise-1.png" alt="noise"/></noscript></figure></div><div class="swiper-slide"><figure class="swiper-slide-inner"><img alt="OYO" data-src="https://letsinfluence.io/wp-content/uploads/2020/12/OYO-1.png" class="swiper-slide-image lazyload" src="data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==" /><noscript><img class="swiper-slide-image" src="../wp-content/uploads/2020/12/OYO-1.png" alt="OYO"/></noscript></figure></div><div class="swiper-slide"><figure class="swiper-slide-inner"><img alt="happy bar" data-src="https://letsinfluence.io/wp-content/uploads/2020/12/happy-bar-1.png" class="swiper-slide-image lazyload" src="data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==" /><noscript><img class="swiper-slide-image" src="../wp-content/uploads/2020/12/happy-bar-1.png" alt="happy bar"/></noscript></figure></div><div class="swiper-slide"><figure class="swiper-slide-inner"><img alt="nua" data-src="https://letsinfluence.io/wp-content/uploads/2020/12/nua-1.png" class="swiper-slide-image lazyload" src="data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==" /><noscript><img class="swiper-slide-image" src="../wp-content/uploads/2020/12/nua-1.png" alt="nua"/></noscript></figure></div><div class="swiper-slide"><figure class="swiper-slide-inner"><img alt="Wild Stone" data-src="https://letsinfluence.io/wp-content/uploads/2020/12/Wild-Stone-1.png" class="swiper-slide-image lazyload" src="data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==" /><noscript><img class="swiper-slide-image" src="../wp-content/uploads/2020/12/Wild-Stone-1.png" alt="Wild Stone"/></noscript></figure></div><div class="swiper-slide"><figure class="swiper-slide-inner"><img alt="BSC" data-src="https://letsinfluence.io/wp-content/uploads/2021/01/BSC.jpg" class="swiper-slide-image lazyload" src="data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==" /><noscript><img class="swiper-slide-image" src="../wp-content/uploads/2021/01/BSC.jpg" alt="BSC"/></noscript></figure></div> </div>
<div class="swiper-pagination"></div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</section>
</div>
</div>
</div>
<div class="post-tags">
</div>
</div>
<section id="comments" class="comments-area">
</section>
</main>
@endsection

@section('scripts')
	@parent
	<script type="text/javascript">function wpfront_scroll_top_init(){if(typeof wpfront_scroll_top=="function"&&typeof jQuery!=="undefined"){wpfront_scroll_top({"scroll_offset":100,"button_width":30,"button_height":30,"button_opacity":0.8,"button_fade_duration":200,"scroll_duration":400,"location":1,"marginX":20,"marginY":20,"hide_iframe":false,"auto_hide":false,"auto_hide_after":2,"button_action":"top","button_action_element_selector":"","button_action_container_selector":"html, body","button_action_element_offset":0});}else{setTimeout(wpfront_scroll_top_init,100);}}wpfront_scroll_top_init();</script>
	<link rel='stylesheet' id='elementor-gallery-css' href="{{ asset('front-asset/e-gallery/css/e-gallery.min7359.css?ver=1.2.0') }}" type='text/css' media='all' />
	<script type='text/javascript' src="{{ asset('front-asset/e-gallery/js/e-gallery.min7359.js?ver=1.2.0') }}" id='elementor-gallery-js'></script>
    <script type='text/javascript' src="{{ asset('front-asset/js/jquery-numerator/jquery-numerator.min3958.js?ver=0.2.1') }}" id='jquery-numerator-js'></script>
@endsection