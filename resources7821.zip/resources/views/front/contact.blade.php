@extends('layouts.app')
 
@section('title', $title)

@section('css')
    @parent
    
<link rel='stylesheet' id='elementor-post-2506-css' href="{{ asset('front-asset/css/post-2506d89e.css?ver=1615652496') }}" type='text/css' media='all' />
@endsection
 
@section('content')
<main class="site-main post-2506 page type-page status-publish hentry" role="main">
<div class="page-content">
<div data-elementor-type="wp-page" data-elementor-id="2506" class="elementor elementor-2506" data-elementor-settings="[]">
<div class="elementor-inner">
<div class="elementor-section-wrap">
<section class="elementor-section elementor-top-section elementor-element elementor-element-4f95717a elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="4f95717a" data-element_type="section" data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
<div class="elementor-container elementor-column-gap-default">
<div class="elementor-row">
<div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-71417b85" data-id="71417b85" data-element_type="column">
<div class="elementor-column-wrap elementor-element-populated">
<div class="elementor-widget-wrap">
<div class="elementor-element elementor-element-4742b34 elementor-widget elementor-widget-heading" data-id="4742b34" data-element_type="widget" data-widget_type="heading.default">
<div class="elementor-widget-container">
<h2 class="elementor-heading-title elementor-size-default"><i>Contact Us</i></h2> </div>
</div>
<div class="elementor-element elementor-element-7544631d elementor-widget elementor-widget-text-editor" data-id="7544631d" data-element_type="widget" data-widget_type="text-editor.default">
<div class="elementor-widget-container">
<div class="elementor-text-editor elementor-clearfix"><p>Got any Questions for us?<br />Please send us your query,<br />Our team will get in touch with you shortly.</p></div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</section>
<section class="elementor-section elementor-top-section elementor-element elementor-element-535c0c90 elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="535c0c90" data-element_type="section">
<div class="elementor-background-overlay"></div>
<div class="elementor-container elementor-column-gap-default">
<div class="elementor-row">
<div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-5d9b011b" data-id="5d9b011b" data-element_type="column">
<div class="elementor-column-wrap elementor-element-populated">
<div class="elementor-widget-wrap">
<section class="elementor-section elementor-inner-section elementor-element elementor-element-3393b0cb elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="3393b0cb" data-element_type="section">
<div class="elementor-container elementor-column-gap-default">
<div class="elementor-row">
<div class="elementor-column elementor-col-50 elementor-inner-column elementor-element elementor-element-4b476348" data-id="4b476348" data-element_type="column">
<div class="elementor-column-wrap elementor-element-populated">
<div class="elementor-widget-wrap">
<div class="elementor-element elementor-element-46f24ff5 elementor-button-align-stretch elementor-widget elementor-widget-form" data-id="46f24ff5" data-element_type="widget" data-settings="{&quot;step_next_label&quot;:&quot;Next&quot;,&quot;step_previous_label&quot;:&quot;Previous&quot;,&quot;button_width&quot;:&quot;100&quot;,&quot;step_type&quot;:&quot;number_text&quot;,&quot;step_icon_shape&quot;:&quot;circle&quot;}" data-widget_type="form.default">
<div class="elementor-widget-container">
<form class="elementor-form" method="post" name="New Form">
<input type="hidden" name="post_id" value="2506" />
<input type="hidden" name="form_id" value="46f24ff5" />
<input type="hidden" name="queried_id" value="2506" />
<div class="elementor-form-fields-wrapper elementor-labels-">
<div class="elementor-field-type-text elementor-field-group elementor-column elementor-field-group-name elementor-col-50 elementor-field-required">
<label for="form-field-name" class="elementor-field-label elementor-screen-only">Name *</label><input size="1" type="text" name="form_fields[name]" id="form-field-name" class="elementor-field elementor-size-sm  elementor-field-textual" placeholder="Name *" required="required" aria-required="true"> </div>
<div class="elementor-field-type-email elementor-field-group elementor-column elementor-field-group-email elementor-col-50 elementor-field-required">
<label for="form-field-email" class="elementor-field-label elementor-screen-only">Email</label><input size="1" type="email" name="form_fields[email]" id="form-field-email" class="elementor-field elementor-size-sm  elementor-field-textual" placeholder="Email *" required="required" aria-required="true"> </div>
<div class="elementor-field-type-text elementor-field-group elementor-column elementor-field-group-field_1 elementor-col-100 elementor-field-required">
<label for="form-field-field_1" class="elementor-field-label elementor-screen-only">Subject *</label><input size="1" type="text" name="form_fields[field_1]" id="form-field-field_1" class="elementor-field elementor-size-sm  elementor-field-textual" placeholder="Subject *" required="required" aria-required="true"> </div>
<div class="elementor-field-type-textarea elementor-field-group elementor-column elementor-field-group-message elementor-col-100">
<label for="form-field-message" class="elementor-field-label elementor-screen-only">Message</label><textarea class="elementor-field-textual elementor-field  elementor-size-sm" name="form_fields[message]" id="form-field-message" rows="4" placeholder="Please describe what you need."></textarea> </div>
<div class="elementor-field-group elementor-column elementor-field-type-submit elementor-col-100 e-form__buttons">
<button type="submit" class="elementor-button elementor-size-sm">
<span>
<span class=" elementor-button-icon">
</span>
<span class="elementor-button-text">Send Message</span>
</span>
</button>
</div>
</div>
</form>
</div>
</div>
</div>
</div>
</div>
<div class="elementor-column elementor-col-50 elementor-inner-column elementor-element elementor-element-7ccc62d5" data-id="7ccc62d5" data-element_type="column">
<div class="elementor-column-wrap elementor-element-populated">
<div class="elementor-widget-wrap">
<div class="elementor-element elementor-element-34034be5 elementor-widget elementor-widget-heading" data-id="34034be5" data-element_type="widget" data-widget_type="heading.default">
<div class="elementor-widget-container">
<h4 class="elementor-heading-title elementor-size-default">To make requests for further information, contact us via our social channels.</h4> </div>
</div>
<div class="elementor-element elementor-element-3f780df2 elementor-widget elementor-widget-text-editor" data-id="3f780df2" data-element_type="widget" data-widget_type="text-editor.default">
<div class="elementor-widget-container">
<div class="elementor-text-editor elementor-clearfix"><p>We just need a couple of hours!<br />No more than 2 working days since receiving your issue ticket.</p></div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</section>
<div class="elementor-element elementor-element-352d782 elementor-widget elementor-widget-spacer" data-id="352d782" data-element_type="widget" data-widget_type="spacer.default">
<div class="elementor-widget-container">
<div class="elementor-spacer">
<div class="elementor-spacer-inner"></div>
</div>
</div>
</div>
<section class="elementor-section elementor-inner-section elementor-element elementor-element-5d5023c3 elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="5d5023c3" data-element_type="section">
<div class="elementor-container elementor-column-gap-default">
<div class="elementor-row">
<div class="elementor-column elementor-col-100 elementor-inner-column elementor-element elementor-element-5db9a136" data-id="5db9a136" data-element_type="column">
<div class="elementor-column-wrap elementor-element-populated">
<div class="elementor-widget-wrap">
<div class="elementor-element elementor-element-3da8701e elementor-widget elementor-widget-heading" data-id="3da8701e" data-element_type="widget" data-widget_type="heading.default">
<div class="elementor-widget-container">
<h5 class="elementor-heading-title elementor-size-default"><i>INDIA</i></h5> </div>
</div>
<div class="elementor-element elementor-element-2ed2fc71 elementor-widget elementor-widget-heading" data-id="2ed2fc71" data-element_type="widget" data-widget_type="heading.default">
<div class="elementor-widget-container">
<h6 class="elementor-heading-title elementor-size-default">Unit 462-463, Tower B1, Spaze iTech Park, Sohna Rd, <BR>Sector 49, Gurugram, Haryana 122018</h6> </div>
</div>
<div class="elementor-element elementor-element-50c244b4 elementor-widget elementor-widget-heading" data-id="50c244b4" data-element_type="widget" data-widget_type="heading.default">
<div class="elementor-widget-container">
<h6 class="elementor-heading-title elementor-size-default">+91-9818946640​</h6> </div>
</div>
<div class="elementor-element elementor-element-4b955689 elementor-widget elementor-widget-text-editor" data-id="4b955689" data-element_type="widget" data-widget_type="text-editor.default">
<div class="elementor-widget-container">
<div class="elementor-text-editor elementor-clearfix"><p><a href="../cdn-cgi/l/email-protection.html" class="__cf_email__" data-cfemail="c9a0a7afa689a5acbdbaa0a7afa5bcaca7aaace7a0a6">[email&#160;protected]</a></p></div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</section>
</div>
</div>
</div>
</div>
</div>
</section>
<section class="elementor-section elementor-top-section elementor-element elementor-element-300ecb3 elementor-section-full_width elementor-section-height-default elementor-section-height-default" data-id="300ecb3" data-element_type="section" data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
<div class="elementor-container elementor-column-gap-default">
<div class="elementor-row">
<div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-d5b1d2c" data-id="d5b1d2c" data-element_type="column">
<div class="elementor-column-wrap elementor-element-populated">
<div class="elementor-widget-wrap">
<div class="elementor-element elementor-element-7a640f4 elementor-pagination-position-outside elementor-widget elementor-widget-image-carousel" data-id="7a640f4" data-element_type="widget" data-settings="{&quot;slides_to_show&quot;:&quot;8&quot;,&quot;slides_to_scroll&quot;:&quot;1&quot;,&quot;navigation&quot;:&quot;dots&quot;,&quot;slides_to_show_tablet&quot;:&quot;4&quot;,&quot;slides_to_show_mobile&quot;:&quot;3&quot;,&quot;slides_to_scroll_mobile&quot;:&quot;3&quot;,&quot;autoplay&quot;:&quot;yes&quot;,&quot;pause_on_hover&quot;:&quot;yes&quot;,&quot;pause_on_interaction&quot;:&quot;yes&quot;,&quot;autoplay_speed&quot;:5000,&quot;infinite&quot;:&quot;yes&quot;,&quot;speed&quot;:500,&quot;image_spacing_custom&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:20,&quot;sizes&quot;:[]}}" data-widget_type="image-carousel.default">
<div class="elementor-widget-container">
<div class="elementor-image-carousel-wrapper swiper-container" dir="ltr">
<div class="elementor-image-carousel swiper-wrapper">
<div class="swiper-slide"><figure class="swiper-slide-inner"><img alt="1 MORE" data-src="https://letsinfluence.io/wp-content/uploads/2020/12/1-MORE-1.png" class="swiper-slide-image lazyload" src="data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==" /><noscript><img class="swiper-slide-image" src="../wp-content/uploads/2020/12/1-MORE-1.png" alt="1 MORE"/></noscript></figure></div><div class="swiper-slide"><figure class="swiper-slide-inner"><img alt="Byte Dance" data-src="https://letsinfluence.io/wp-content/uploads/2020/12/Byte-Dance-1.png" class="swiper-slide-image lazyload" src="data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==" /><noscript><img class="swiper-slide-image" src="../wp-content/uploads/2020/12/Byte-Dance-1.png" alt="Byte Dance"/></noscript></figure></div><div class="swiper-slide"><figure class="swiper-slide-inner"><img alt="COSCO" data-src="https://letsinfluence.io/wp-content/uploads/2020/12/COSCO-1.png" class="swiper-slide-image lazyload" src="data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==" /><noscript><img class="swiper-slide-image" src="../wp-content/uploads/2020/12/COSCO-1.png" alt="COSCO"/></noscript></figure></div><div class="swiper-slide"><figure class="swiper-slide-inner"><img alt="mamaearth" data-src="https://letsinfluence.io/wp-content/uploads/2020/12/mamaearth-1.png" class="swiper-slide-image lazyload" src="data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==" /><noscript><img class="swiper-slide-image" src="../wp-content/uploads/2020/12/mamaearth-1.png" alt="mamaearth"/></noscript></figure></div><div class="swiper-slide"><figure class="swiper-slide-inner"><img alt="Times internet" data-src="https://letsinfluence.io/wp-content/uploads/2020/12/Times-internet-1.png" class="swiper-slide-image lazyload" src="data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==" /><noscript><img class="swiper-slide-image" src="../wp-content/uploads/2020/12/Times-internet-1.png" alt="Times internet"/></noscript></figure></div><div class="swiper-slide"><figure class="swiper-slide-inner"><img alt="snapdeal" data-src="https://letsinfluence.io/wp-content/uploads/2020/12/snapdeal-1.png" class="swiper-slide-image lazyload" src="data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==" /><noscript><img class="swiper-slide-image" src="../wp-content/uploads/2020/12/snapdeal-1.png" alt="snapdeal"/></noscript></figure></div><div class="swiper-slide"><figure class="swiper-slide-inner"><img alt="Truebasics" data-src="https://letsinfluence.io/wp-content/uploads/2020/12/Truebasics-1.png" class="swiper-slide-image lazyload" src="data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==" /><noscript><img class="swiper-slide-image" src="../wp-content/uploads/2020/12/Truebasics-1.png" alt="Truebasics"/></noscript></figure></div><div class="swiper-slide"><figure class="swiper-slide-inner"><img alt="Trulymadly" data-src="https://letsinfluence.io/wp-content/uploads/2020/12/Trulymadly-1.png" class="swiper-slide-image lazyload" src="data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==" /><noscript><img class="swiper-slide-image" src="../wp-content/uploads/2020/12/Trulymadly-1.png" alt="Trulymadly"/></noscript></figure></div><div class="swiper-slide"><figure class="swiper-slide-inner"><img alt="Titan" data-src="https://letsinfluence.io/wp-content/uploads/2020/12/Titan-1.png" class="swiper-slide-image lazyload" src="data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==" /><noscript><img class="swiper-slide-image" src="../wp-content/uploads/2020/12/Titan-1.png" alt="Titan"/></noscript></figure></div><div class="swiper-slide"><figure class="swiper-slide-inner"><img alt="Neemans" data-src="https://letsinfluence.io/wp-content/uploads/2020/12/Neemans-1.png" class="swiper-slide-image lazyload" src="data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==" /><noscript><img class="swiper-slide-image" src="../wp-content/uploads/2020/12/Neemans-1.png" alt="Neemans"/></noscript></figure></div><div class="swiper-slide"><figure class="swiper-slide-inner"><img alt="bOAt" data-src="https://letsinfluence.io/wp-content/uploads/2020/12/bOAt-1.png" class="swiper-slide-image lazyload" src="data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==" /><noscript><img class="swiper-slide-image" src="../wp-content/uploads/2020/12/bOAt-1.png" alt="bOAt"/></noscript></figure></div><div class="swiper-slide"><figure class="swiper-slide-inner"><img alt="emami" data-src="https://letsinfluence.io/wp-content/uploads/2020/12/emami-1.png" class="swiper-slide-image lazyload" src="data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==" /><noscript><img class="swiper-slide-image" src="../wp-content/uploads/2020/12/emami-1.png" alt="emami"/></noscript></figure></div><div class="swiper-slide"><figure class="swiper-slide-inner"><img alt="momo" data-src="https://letsinfluence.io/wp-content/uploads/2020/12/momo-1.png" class="swiper-slide-image lazyload" src="data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==" /><noscript><img class="swiper-slide-image" src="../wp-content/uploads/2020/12/momo-1.png" alt="momo"/></noscript></figure></div><div class="swiper-slide"><figure class="swiper-slide-inner"><img alt="MPL" data-src="https://letsinfluence.io/wp-content/uploads/2020/12/MPL-1.png" class="swiper-slide-image lazyload" src="data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==" /><noscript><img class="swiper-slide-image" src="../wp-content/uploads/2020/12/MPL-1.png" alt="MPL"/></noscript></figure></div><div class="swiper-slide"><figure class="swiper-slide-inner"><img alt="meesho" data-src="https://letsinfluence.io/wp-content/uploads/2020/12/meesho-1.png" class="swiper-slide-image lazyload" src="data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==" /><noscript><img class="swiper-slide-image" src="../wp-content/uploads/2020/12/meesho-1.png" alt="meesho"/></noscript></figure></div><div class="swiper-slide"><figure class="swiper-slide-inner"><img alt="purplle 1" data-src="https://letsinfluence.io/wp-content/uploads/2020/12/purplle-1-1.png" class="swiper-slide-image lazyload" src="data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==" /><noscript><img class="swiper-slide-image" src="../wp-content/uploads/2020/12/purplle-1-1.png" alt="purplle 1"/></noscript></figure></div><div class="swiper-slide"><figure class="swiper-slide-inner"><img alt="Pee buddy" data-src="https://letsinfluence.io/wp-content/uploads/2020/12/Pee-buddy-1.png" class="swiper-slide-image lazyload" src="data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==" /><noscript><img class="swiper-slide-image" src="../wp-content/uploads/2020/12/Pee-buddy-1.png" alt="Pee buddy"/></noscript></figure></div><div class="swiper-slide"><figure class="swiper-slide-inner"><img alt="noise" data-src="https://letsinfluence.io/wp-content/uploads/2020/12/noise-1.png" class="swiper-slide-image lazyload" src="data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==" /><noscript><img class="swiper-slide-image" src="../wp-content/uploads/2020/12/noise-1.png" alt="noise"/></noscript></figure></div><div class="swiper-slide"><figure class="swiper-slide-inner"><img alt="OYO" data-src="https://letsinfluence.io/wp-content/uploads/2020/12/OYO-1.png" class="swiper-slide-image lazyload" src="data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==" /><noscript><img class="swiper-slide-image" src="../wp-content/uploads/2020/12/OYO-1.png" alt="OYO"/></noscript></figure></div><div class="swiper-slide"><figure class="swiper-slide-inner"><img alt="happy bar" data-src="https://letsinfluence.io/wp-content/uploads/2020/12/happy-bar-1.png" class="swiper-slide-image lazyload" src="data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==" /><noscript><img class="swiper-slide-image" src="../wp-content/uploads/2020/12/happy-bar-1.png" alt="happy bar"/></noscript></figure></div><div class="swiper-slide"><figure class="swiper-slide-inner"><img alt="nua" data-src="https://letsinfluence.io/wp-content/uploads/2020/12/nua-1.png" class="swiper-slide-image lazyload" src="data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==" /><noscript><img class="swiper-slide-image" src="../wp-content/uploads/2020/12/nua-1.png" alt="nua"/></noscript></figure></div><div class="swiper-slide"><figure class="swiper-slide-inner"><img alt="Wild Stone" data-src="https://letsinfluence.io/wp-content/uploads/2020/12/Wild-Stone-1.png" class="swiper-slide-image lazyload" src="data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==" /><noscript><img class="swiper-slide-image" src="../wp-content/uploads/2020/12/Wild-Stone-1.png" alt="Wild Stone"/></noscript></figure></div><div class="swiper-slide"><figure class="swiper-slide-inner"><img alt="BSC" data-src="https://letsinfluence.io/wp-content/uploads/2021/01/BSC.jpg" class="swiper-slide-image lazyload" src="data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==" /><noscript><img class="swiper-slide-image" src="../wp-content/uploads/2021/01/BSC.jpg" alt="BSC"/></noscript></figure></div> </div>
<div class="swiper-pagination"></div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
 </div>
</section>
</div>
</div>
</div>
<div class="post-tags">
</div>
</div>
<section id="comments" class="comments-area">
</section>
</main>
@endsection

@section('scripts')
	@parent
	<script type="text/javascript">function wpfront_scroll_top_init(){if(typeof wpfront_scroll_top=="function"&&typeof jQuery!=="undefined"){wpfront_scroll_top({"scroll_offset":100,"button_width":30,"button_height":30,"button_opacity":0.8,"button_fade_duration":200,"scroll_duration":400,"location":1,"marginX":20,"marginY":20,"hide_iframe":false,"auto_hide":false,"auto_hide_after":2,"button_action":"top","button_action_element_selector":"","button_action_container_selector":"html, body","button_action_element_offset":0});}else{setTimeout(wpfront_scroll_top_init,100);}}wpfront_scroll_top_init();</script>
	<link rel='stylesheet' id='elementor-gallery-css' href="{{ asset('front-asset/e-gallery/css/e-gallery.min7359.css?ver=1.2.0') }}" type='text/css' media='all' />
	<script type='text/javascript' src="{{ asset('front-asset/e-gallery/js/e-gallery.min7359.js?ver=1.2.0') }}" id='elementor-gallery-js'></script>
@endsection