@extends('layouts.app')
 
@section('title', $title)

@section('css')
    @parent
    
@endsection
 
@section('content')
<section class="blog-list-area section-bg-padding">
        <div class="container">
            <div class="row">
                <div class="col-lg-8">
                    <div class="blog-single-content get-bottom animate">
                        <div class="animate">
                            <img src="{{asset(env('APP_FILE_URL').'uploads/blog/post/'.$blog->image)}}" alt="">
                        </div>
                        <ul class="inline-with-icon get-bottom animate">
                            <li class="animate"><a href="#"><span><i class="icofont-calendar"></i></span>{{ date('F d, Y', strtotime($blog->updated_at)) }}</a></li>
                        </ul>
                        <h2 class="animate">{{ $blog->title}}</h2>
                        {!! $blog->long_desc  !!}
                    </div>
                    <!-- <ul class="d-flex flex-wrap align-items-center justify-content-center py-50 py-md-30 get-bottom animate">
                        <li><a class="text-20 text-content social-round mr-15 bg-gray icon-animation" href="#"><i class="icofont-facebook"></i></a></li>
                        <li><a class="text-20 text-content social-round mr-15 bg-gray icon-animation" href="#"><i class="icofont-twitter"></i></a></li>
                        <li><a class="text-20 text-content social-round mr-15 bg-gray icon-animation" href="#"><i class="icofont-instagram"></i></a></li>
                        <li><a class="text-20 text-content social-round bg-gray mr-15 icon-animation" href="#"><i class="icofont-linkedin"></i></a></li>
                        <li><a class="text-20 text-content social-round bg-gray mr-15 icon-animation" href="#"><i class="icofont-google-plus"></i></a></li>
                        <li><a class="text-20 text-content social-round bg-gray icon-animation" href="#"><i class="icofont-pinterest"></i></a></li>
                    </ul> -->
                    
                </div>
                <div class="col-lg-4 mt-md-50">
                    <div class="blog-list-sidebar">
                        <!-- <div class="siderbar-search mb-50 mb-md-30 get-bottom animate">
                            <div class="subscribe-input d-flex align-items-center justify-content-between btn-radious">
                                <div class="animation-form include-btn">
                                    <span></span>
                                    <input type="text" class="form-control" placeholder="enter your keywords">
                                </div>
                                <div class="search-icon">
                                    <i class="icofont-search"></i>
                                </div>
                            </div>
                        </div> -->
                        <div class="recent-post px-30 py-35 bdr-10 mb-50 mb-md-30 get-bottom animate">
                            <div class="card-title animate">
                                <h3 class="pb-20">Recent post</h3>
                            </div>
                            @foreach($recent_blogs as $one)
                            <div class="resent-post-single pb-25 d-flex align-items-center animate">
                                <a href="{{ route('blog.details', $one->slug)}}" class="recent-post-img">
                                    <img class="bdr-6" src="{{asset(env('APP_FILE_URL').'uploads/blog/post/'.$one->image)}}" alt="">
                                </a>
                                <div class="recent-post-cont pl-15 post-title">
                                    <h4><a href="{{ route('blog.details', $one->slug)}}">{{ substr($blog->title,0,40) }}...</a></h4>
                                </div>
                            </div>
                            @endforeach
                            
                        </div> 
                        <div class="sbar-category-area px-30 py-35 bdr-10 mb-50 mb-md-30 get-bottom animate">
                            <div class="card-title animate">
                                <h3 class="pb-30">Category</h3>
                            </div>
                            <ul class="get-bottom animate">
                                @foreach($categories as $cat)
                                <li class="animate"><a href="#">{{$cat->name}}</a></li>
                                @endforeach
                               <!--  <li class="animate"><a href="#">Food</a></li>
                                <li class="animate"><a href="#">Mom</a></li>
                                <li class="animate"><a href="#">Education</a></li>
                                <li class="animate"><a href="#">Pet</a></li> -->
                            </ul>
                        </div>                 
                    </div>
                </div>
            </div>
        </div>
    </section>
@endsection

@section('scripts')
	@parent
	
@endsection