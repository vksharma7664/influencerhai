<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Front\FrontController;
use App\Http\Controllers\admin\DashboardController;
use App\Http\Controllers\admin\PostCategoryController;
use App\Http\Controllers\admin\CategoryController;
use App\Http\Controllers\admin\PostController;
use App\Http\Controllers\admin\PlatformController;
use App\Http\Controllers\admin\InfluencerController;
use App\Http\Controllers\admin\CmsController;
use App\Http\Controllers\admin\UsersController;
use App\Http\Controllers\admin\RolesController;
use App\Http\Controllers\admin\PermissionsController;
use App\Http\Controllers\admin\CareerController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/


Route::get('/', [FrontController::class, 'index'])->name('home');
Route::get('/i-am-brand', [FrontController::class, 'ForBrand'])->name('brand');
Route::post('/i-am-brand', [FrontController::class, 'ForBrandStore'])->name('brand.store');
Route::post('/i-am-an-influencer', [FrontController::class, 'ForInfluencerStore'])->name('influencer.form.store');
Route::get('/i-am-an-influencer', [FrontController::class, 'ForInfluencer'])->name('influencer');
Route::get('/about', [FrontController::class, 'About'])->name('about');
Route::get('/contact', [FrontController::class, 'Contact'])->name('contact');
Route::post('/contact', [FrontController::class, 'submitContact'])->name('contact.submit');
Route::get('/careers', [FrontController::class, 'Careers'])->name('careers');
Route::get('/careers/{title}/apply/{id}', [FrontController::class, 'CareersApply'])->name('careers.apply');
Route::post('/careers/apply/{id}', [FrontController::class, 'CareersApplyStore'])->name('careers.apply.store');
Route::get('/terms', [FrontController::class, 'Terms'])->name('terms');
Route::get('/privacy', [FrontController::class, 'Privacy'])->name('privacy');
Route::get('/blog', [FrontController::class, 'Blog'])->name('blog');
Route::get('/blog/{title}', [FrontController::class, 'BlogDetails'])->name('blog.details');
Route::get('/press-release', [FrontController::class, 'Blog'])->name('press');
Route::get('/start-campaign-here', [FrontController::class, 'startCampaign'])->name('campaign');
Route::post('/start-campaign-here', [FrontController::class, 'postCampaign'])->name('campaign.submit');
Route::get('/influencers', [FrontController::class, 'InfluencerCategory'])->name('influencers.category');
Route::get('/influencers/list', [FrontController::class, 'InfluencerList'])->name('influencers.list');

Auth::routes();
Route::get('/admin', function(){
    return redirect()->route('login');      
})->name('admin.home');
// Route::get('/home', [App\Http\Controllers\HomeController::class, 'index'])->name('home');

Route::group(['middleware'=>['auth', 'permission'],'prefix' => 'admin'],function()
{
    Route::get('/dashboard',[DashboardController::class, 'index'])->name('admin.dashboard');


    /**
     * User Routes
     */
    Route::group(['prefix' => 'users'], function() {
        Route::get('/', [UsersController::class, 'index'])->name('users.index');
        Route::get('/create', [UsersController::class, 'create'])->name('users.create');
        Route::post('/create', [UsersController::class, 'store'])->name('users.store');
        Route::get('/{user}/show', [UsersController::class, 'show'])->name('users.show');
        Route::get('/{user}/edit', [UsersController::class, 'edit'])->name('users.edit');
        Route::patch('/{user}/update', [UsersController::class, 'update'])->name('users.update');
        Route::delete('/{user}/delete', [UsersController::class, 'destroy'])->name('users.destroy');
    });

    Route::resource('/roles', RolesController::class);
    Route::resource('/permissions', PermissionsController::class);


   Route::get('/post/list',[PostController::class, 'listing'])->name('post.index');
    Route::get('/post/add',[PostController::class, 'add'])->name('post.create');
    Route::post('/post/submit',[PostController::class, 'submit'])->name('post.store');
    Route::get('/post/delete/{id}',[PostController::class, 'delete'])->name('post.delete');
    Route::get('/post/edit/{id}',[PostController::class, 'edit'])->name('post.edit');
    Route::post('/post/update/{id}',[PostController::class, 'update'])->name('post.update');

    Route::get('/post/add-new-category',[PostCategoryController::class, 'listing'])->name('post.cat.create');
    Route::post('/post/category-submit',[PostCategoryController::class, 'submit'])->name('post.cat.store');
    Route::get('/post/category-edit/{id}',[PostCategoryController::class, 'edit'])->name('post.cat.edit');
    Route::post('/post/category-update/{id}',[PostCategoryController::class, 'Update'])->name('post.cat.update');
    Route::get('/post/category-delete/{id}',[PostCategoryController::class, 'delete'])->name('post.cat.delete');

    // Influencers Platforms //
    Route::get('/influencers/add-new-platform',[PlatformController::class, 'listing'])->name('influencer.platform.create');
    Route::post('/influencers/platform-submit',[PlatformController::class, 'submit'])->name('influencer.platform.store');
    Route::get('/influencers/platform-edit/{id}',[PlatformController::class, 'edit'])->name('influencer.platform.edit');
    Route::post('/influencers/platform-update/{id}',[PlatformController::class, 'Update'])->name('influencer.platform.update');
    Route::get('/influencers/platform-delete/{id}',[PlatformController::class, 'delete'])->name('influencer.platform.delete');

    // Influencers Categories //
    Route::get('/influencers/add-new-category',[CategoryController::class, 'listing'])->name('influencer.cat.index');
    Route::post('/influencers/category-submit',[CategoryController::class, 'submit'])->name('influencer.cat.store');
    Route::get('/influencers/category-edit/{id}',[CategoryController::class, 'edit'])->name('influencer.cat.edit');
    Route::post('/influencers/category-update/{id}',[CategoryController::class, 'Update'])->name('influencer.cat.update');
    Route::get('/influencers/category-delete/{id}',[CategoryController::class, 'delete'])->name('influencer.cat.delete');


    // Influencers //
    Route::get('/influencers/list',[InfluencerController::class, 'listing'])->name('influencer.index');
    Route::get('/influencers/add',[InfluencerController::class, 'add'])->name('influencer.create');
    Route::post('/influencers/submit',[InfluencerController::class, 'submit'])->name('influencer.store');
    Route::get('/influencers/delete/{id}',[InfluencerController::class, 'delete'])->name('influencer.delete');
    Route::get('/influencers/edit/{id}',[InfluencerController::class, 'edit'])->name('influencer.edit');
    Route::post('/influencers/update/{id}',[InfluencerController::class, 'update'])->name('influencer.update');

    // Careers JOBS //
    Route::get('/jobs/list',[CareerController::class, 'listing'])->name('jobs.index');
    Route::get('/jobs/add',[CareerController::class, 'add'])->name('jobs.create');
    Route::post('/jobs/submit',[CareerController::class, 'submit'])->name('jobs.store');
    Route::get('/jobs/delete/{id}',[CareerController::class, 'delete'])->name('jobs.delete');
    Route::get('/jobs/edit/{id}',[CareerController::class, 'edit'])->name('jobs.edit');
    Route::post('/jobs/update/{id}',[CareerController::class, 'update'])->name('jobs.update');
    Route::get('/jobs/application/list',[CareerController::class, 'jobApplylisting'])->name('jobs.application.list');


    // Queries
    Route::get('/contactqueries/list',[CmsController::class, 'contactQuerieslisting'])->name('query.contact.show');
    Route::get('/brandsqueries/list',[CmsController::class, 'brandsQuerieslisting'])->name('query.brands.show');
    Route::get('/influencersqueries/list',[CmsController::class, 'influencersQuerieslisting'])->name('query.influencers.show');
    // Route::get('/contactqueries/list',[CmsController::class, 'contactQuerieslisting'])->name('query.jobs.show');

});
Route::post('ckeditor/image_upload', 'CKEditorController@upload')->name('upload');